# ⚽ Football Transfer Simulator

"What if" simulator: move any player, or any manager, to any club in any season and see what happens over 1–20 seasons.

- **Players:** about 500 current players and legends from Europe, Asia (Japan, Korea, China, Malaysia), Saudi Arabia and MLS. Every player starts at age 18 at his age-18 level.
- **Managers:** 70+ current and legendary managers, each with a rating, style and youth development. They can be sacked, poached or retire.
- **Results:** season-by-season player stats, about 50 detailed per-position stats, club tables, cups, continental competitions and international tournaments. Also realistic transfers and loans, Ballon d'Or rankings and manager records.
- **Odds:** 150 simulated careers comparing the club with and without the move.

## No AI needed
The simulation runs entirely in the browser with plain JavaScript, using random numbers and football rules. There's no AI, no server and no internet connection needed apart from the Google font.

## Run it
- **Locally:** download the folder and open `index.html` in any browser.
- **Online (GitHub Pages):** Settings → Pages → Source: *Deploy from a branch* → Branch: `main`, folder `/ (root)`.

## Files
| File | What it does |
|---|---|
| `index.html` | Page layout |
| `css/style.css` | Styling (light and dark mode) |
| `js/data.js` | Players, legends, managers, leagues, clubs, historical line-ups (edit here to add players or clubs) |
| `js/engine.js` | The simulation engine: league matches, cups, transfers, development, awards, managers |
| `js/ui.js` | Search, forms, tables and charts |

## Adding a player
Add a line to `P_RAW` in `js/data.js`:
```
Name|NAT|POS|BirthYear|Club|Rating|Potential
```
`POS` is one of GK, CB, FB, DM, CM, AM, W or ST. The club must match a club name in `LEAGUES`.

## Disclaimer
Fan-made game. Ratings, squads and club strengths are estimates and may be out of date. Not affiliated with any league, club or player.
