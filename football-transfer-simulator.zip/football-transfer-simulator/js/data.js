// Football Transfer Simulator — data (players, managers, leagues, clubs, history)
// Ratings and squads are estimates as of mid-2026. Edit freely.
// ---------- DATA (ratings are estimates, squads approx. as of mid-2026) ----------
const NATIONS={
ARG:['Argentina',87,'CONMEBOL'],FRA:['France',87,'UEFA'],ESP:['Spain',88,'UEFA'],ENG:['England',86,'UEFA'],BRA:['Brazil',85,'CONMEBOL'],
POR:['Portugal',85,'UEFA'],GER:['Germany',84,'UEFA'],NED:['Netherlands',84,'UEFA'],BEL:['Belgium',81,'UEFA'],ITA:['Italy',82,'UEFA'],
CRO:['Croatia',81,'UEFA'],URU:['Uruguay',80,'CONMEBOL'],COL:['Colombia',80,'CONMEBOL'],MAR:['Morocco',80,'CAF'],NOR:['Norway',79,'UEFA'],
DEN:['Denmark',79,'UEFA'],SUI:['Switzerland',79,'UEFA'],USA:['USA',77,'CONCACAF'],MEX:['Mexico',77,'CONCACAF'],JPN:['Japan',78,'AFC'],
SEN:['Senegal',78,'CAF'],TUR:['Türkiye',79,'UEFA'],AUT:['Austria',79,'UEFA'],ECU:['Ecuador',78,'CONMEBOL'],SWE:['Sweden',78,'UEFA'],
POL:['Poland',77,'UEFA'],SRB:['Serbia',77,'UEFA'],UKR:['Ukraine',77,'UEFA'],CZE:['Czechia',75,'UEFA'],HUN:['Hungary',76,'UEFA'],
SCO:['Scotland',75,'UEFA'],WAL:['Wales',73,'UEFA'],IRL:['Rep. of Ireland',73,'UEFA'],NIR:['Northern Ireland',70,'UEFA'],SVK:['Slovakia',75,'UEFA'],
SVN:['Slovenia',74,'UEFA'],GEO:['Georgia',75,'UEFA'],GRE:['Greece',75,'UEFA'],KOS:['Kosovo',71,'UEFA'],BIH:['Bosnia & Herz.',72,'UEFA'],
MNE:['Montenegro',70,'UEFA'],ISL:['Iceland',70,'UEFA'],ROU:['Romania',75,'UEFA'],BUL:['Bulgaria',70,'UEFA'],RUS:['Russia',76,'UEFA'],
KOR:['South Korea',77,'AFC'],AUS:['Australia',74,'AFC'],IRN:['Iran',75,'AFC'],KSA:['Saudi Arabia',70,'AFC'],JOR:['Jordan',68,'AFC'],
MAS:['Malaysia',56,'AFC'],CHN:['China',62,'AFC'],NGA:['Nigeria',77,'CAF'],CIV:["Côte d'Ivoire",77,'CAF'],EGY:['Egypt',76,'CAF'],ALG:['Algeria',77,'CAF'],
CMR:['Cameroon',75,'CAF'],GHA:['Ghana',74,'CAF'],GUI:['Guinea',70,'CAF'],GAB:['Gabon',69,'CAF'],COD:['DR Congo',74,'CAF'],LBR:['Liberia',60,'CAF'],
CAN:['Canada',75,'CONCACAF'],JAM:['Jamaica',69,'CONCACAF'],PAR:['Paraguay',76,'CONMEBOL'],CHI:['Chile',72,'CONMEBOL'],NZL:['New Zealand',66,'OFC']
};

const LEAGUES=[
{id:'EPL',name:'Premier League',country:'England',coef:1,conf:'UEFA',slots:[4,2,1],cups:['FA Cup','EFL Cup'],rel:3,
c:"Arsenal:87,Liverpool:87,Manchester City:86,Chelsea:84,Newcastle:81,Aston Villa:81,Tottenham:80,Manchester United:80,Nottingham Forest:78,Brighton:78,Crystal Palace:78,Bournemouth:77,Brentford:77,Fulham:76,Everton:76,West Ham:76,Wolves:74,Sunderland:74,Leeds:74,Burnley:72"},
{id:'LAL',name:'La Liga',country:'Spain',coef:.97,conf:'UEFA',slots:[4,2,1],cups:['Copa del Rey'],rel:3,
c:"Real Madrid:88,Barcelona:88,Atlético Madrid:84,Athletic Club:80,Villarreal:80,Real Betis:79,Real Sociedad:78,Celta Vigo:76,Girona:76,Sevilla:76,Valencia:75,Osasuna:75,Rayo Vallecano:75,Mallorca:74,Getafe:74,Espanyol:74,Alavés:73,Elche:72,Levante:71,Real Oviedo:70"},
{id:'SA',name:'Serie A',country:'Italy',coef:.94,conf:'UEFA',slots:[4,2,1],cups:['Coppa Italia'],rel:3,
c:"Inter:86,Napoli:85,Juventus:83,Milan:83,Atalanta:81,Roma:81,Como:79,Lazio:79,Bologna:79,Fiorentina:77,Torino:75,Udinese:74,Genoa:73,Sassuolo:73,Cagliari:73,Parma:73,Lecce:71,Hellas Verona:71,Cremonese:70,Pisa:70"},
{id:'BL',name:'Bundesliga',country:'Germany',coef:.94,conf:'UEFA',slots:[4,2,1],cups:['DFB-Pokal'],rel:2,
c:"Bayern Munich:89,Borussia Dortmund:83,Bayer Leverkusen:82,RB Leipzig:81,Eintracht Frankfurt:79,VfB Stuttgart:79,SC Freiburg:77,Hoffenheim:77,Borussia Mönchengladbach:75,Wolfsburg:75,Werder Bremen:75,Mainz 05:75,Union Berlin:74,Augsburg:73,Hamburger SV:73,1. FC Köln:73,St. Pauli:71,Heidenheim:70"},
{id:'L1',name:'Ligue 1',country:'France',coef:.9,conf:'UEFA',slots:[3,2,1],cups:['Coupe de France'],rel:2,
c:"Paris Saint-Germain:88,Marseille:81,Monaco:80,Lille:79,Lyon:79,Lens:78,Nice:77,Strasbourg:77,Rennes:77,Toulouse:74,Brest:74,Nantes:73,Auxerre:72,Angers:71,Le Havre:71,Lorient:71,Paris FC:71,Metz:70"},
{id:'POR',name:'Primeira Liga',country:'Portugal',coef:.82,conf:'UEFA',slots:[2,1,2],cups:['Taça de Portugal'],rel:2,
c:"Benfica:81,Porto:81,Sporting CP:81,Braga:77,Vitória SC:73,Famalicão:72,Gil Vicente:71,Moreirense:70,Rio Ave:70,Estoril:70,Casa Pia:69,Arouca:69,Santa Clara:69,Nacional:68,Estrela Amadora:68,AVS:67,Tondela:67,Alverca:67"},
{id:'NED',name:'Eredivisie',country:'Netherlands',coef:.8,conf:'UEFA',slots:[2,1,2],cups:['KNVB Cup'],rel:2,
c:"PSV:80,Feyenoord:79,Ajax:79,AZ Alkmaar:76,FC Twente:75,FC Utrecht:74,NEC Nijmegen:72,Go Ahead Eagles:71,Heerenveen:71,Sparta Rotterdam:70,Groningen:70,Fortuna Sittard:69,PEC Zwolle:69,Heracles:68,NAC Breda:68,Excelsior:67,Telstar:67,Volendam:67"},
{id:'TUR',name:'Süper Lig',country:'Türkiye',coef:.78,conf:'UEFA',slots:[1,2,1],cups:['Turkish Cup'],rel:3,
c:"Galatasaray:81,Fenerbahçe:80,Beşiktaş:77,Trabzonspor:75,Başakşehir:74,Samsunspor:73,Göztepe:72,Kasımpaşa:71,Rizespor:70,Konyaspor:70,Alanyaspor:70,Antalyaspor:69,Kayserispor:69,Gaziantep:69,Eyüpspor:69,Kocaelispor:68,Gençlerbirliği:68,Karagümrük:68"},
{id:'BEL',name:'Belgian Pro League',country:'Belgium',coef:.76,conf:'UEFA',slots:[1,1,2],cups:['Belgian Cup'],rel:2,
c:"Club Brugge:78,Union Saint-Gilloise:77,Anderlecht:75,Genk:75,Gent:73,Antwerp:73,Standard Liège:72,Mechelen:71,Charleroi:71,Westerlo:70,Cercle Brugge:70,OH Leuven:69,Sint-Truiden:69,Zulte Waregem:67,Dender:67,La Louvière:66"},
{id:'SCO',name:'Scottish Premiership',country:'Scotland',coef:.7,conf:'UEFA',slots:[1,1,2],cups:['Scottish Cup','League Cup'],rel:1,
c:"Celtic:77,Rangers:75,Hearts:71,Aberdeen:69,Hibernian:69,Motherwell:67,Dundee United:67,St Mirren:66,Kilmarnock:66,Falkirk:65,Dundee:65,Livingston:64"},
{id:'SAU',name:'Saudi Pro League',country:'Saudi Arabia',coef:.75,conf:'AFC',slots:[3,1,0],cups:["King's Cup"],rel:3,
c:"Al Hilal:80,Al Nassr:80,Al Ittihad:79,Al Ahli:79,Al Qadsiah:76,Al Ettifaq:73,Al Shabab:73,Al Taawoun:72,Al Fateh:70,Al Khaleej:70,Damac:69,Al Fayha:69,Al Hazem:68,Al Kholood:68,Neom:68,Al Okhdood:67,Al Riyadh:67,Al Najma:66"},
{id:'MLS',name:'MLS (selected clubs)',country:'USA/Canada',coef:.7,conf:'CONCACAF',slots:[4,0,0],cups:['US Open Cup'],rel:0,
c:"Inter Miami:73,LAFC:73,LA Galaxy:71,Columbus Crew:71,FC Cincinnati:71,Philadelphia Union:71,Vancouver Whitecaps:71,Seattle Sounders:70,San Diego FC:70,Orlando City:70,Nashville SC:69,Charlotte FC:69,New York Red Bulls:68,Atlanta United:68"},
{id:'J1',name:'J1 League',country:'Japan',coef:.66,conf:'AFC',slots:[3,1,0],cups:["Emperor's Cup",'J.League Cup'],rel:3,
c:"Kashima Antlers:70,Sanfrecce Hiroshima:69,Vissel Kobe:69,Kashiwa Reysol:69,Kyoto Sanga:68,Machida Zelvia:68,Urawa Red Diamonds:67,Kawasaki Frontale:67,Gamba Osaka:66,Yokohama F. Marinos:66,Cerezo Osaka:65,FC Tokyo:65,Avispa Fukuoka:64,Nagoya Grampus:64,Shimizu S-Pulse:64,Tokyo Verdy:63,Fagiano Okayama:63,V-Varen Nagasaki:62,Mito HollyHock:61,JEF United Chiba:61"},
{id:'KL1',name:'K League 1',country:'South Korea',coef:.62,conf:'AFC',slots:[3,1,0],cups:['Korea Cup'],rel:1,
c:"Jeonbuk Hyundai Motors:68,Ulsan HD:66,Daejeon Hana Citizen:65,Pohang Steelers:65,FC Seoul:65,Gangwon FC:64,Gimcheon Sangmu:64,Gwangju FC:62,Jeju SK:62,FC Anyang:61,Incheon United:61,Suwon FC:60"},
{id:'CSL',name:'Chinese Super League',country:'China',coef:.58,conf:'AFC',slots:[2,1,0],cups:['Chinese FA Cup'],rel:2,
c:"Shanghai Port:67,Shanghai Shenhua:66,Chengdu Rongcheng:66,Beijing Guoan:65,Shandong Taishan:64,Tianjin Jinmen Tiger:62,Zhejiang FC:62,Henan FC:61,Qingdao West Coast:60,Wuhan Three Towns:60,Yunnan Yukun:60,Dalian Yingbo:60,Qingdao Hainiu:59,Shenzhen Peng City:59,Liaoning Tieren:59,Meizhou Hakka:58"},
{id:'MSL',name:'Malaysia Super League',country:'Malaysia',coef:.45,conf:'AFC',slots:[1,1,0],cups:['FA Cup','Malaysia Cup'],rel:0,
c:"Johor Darul Ta'zim:67,Selangor:59,Sabah:56,Kuala Lumpur City:56,Terengganu:56,Sri Pahang:54,Kuching City:54,Negeri Sembilan:53,Penang:52,DPMM:52,PDRM:51,Immigration:51,Melaka:50"}
];

// Historical strength overrides: [club, fromSeason, toSeason, rating]
const ERA=[['Milan',1988,1995,91],['Milan',2002,2007,88],['Juventus',1994,1998,89],['Juventus',2014,2019,88],['Manchester United',1993,2001,90],['Manchester United',2006,2011,89],['Manchester United',2013,2022,83],['Barcelona',2008,2012,94],['Barcelona',2014,2016,91],['Real Madrid',1998,2003,89],['Real Madrid',2013,2018,91],['Arsenal',1997,2005,88],['Arsenal',2006,2016,84],['Chelsea',2004,2012,88],['Liverpool',2004,2008,86],['Liverpool',2018,2021,91],['Bayern Munich',2012,2015,92],['Bayern Munich',2019,2021,92],['Inter',2005,2011,88],['Porto',2002,2004,85],['Borussia Dortmund',2010,2013,87],['Ajax',1994,1997,88],['Valencia',1999,2004,85],['Lazio',1998,2001,87],['Leeds',1999,2002,84],['Monaco',2016,2017,85],['Atlético Madrid',2013,2017,87],['Manchester City',2011,2016,87],['Manchester City',2017,2024,92],['Paris Saint-Germain',2012,2023,88],['Napoli',2022,2023,87],['Bayer Leverkusen',2023,2024,88],['Tottenham',2015,2019,85],['Fiorentina',1995,2001,83],['Galatasaray',1999,2000,84],['Celtic',2001,2004,80],['Rangers',1990,1997,80],['Selangor',1972,1990,66]];

// Current players: Name|NAT|POS|BirthYear|Club|OVR|POT
const P_RAW=`Bukayo Saka|ENG|W|2001|Arsenal|88|91
Martin Ødegaard|NOR|AM|1998|Arsenal|86|86
Declan Rice|ENG|CM|1999|Arsenal|88|89
William Saliba|FRA|CB|2001|Arsenal|88|90
Gabriel Magalhães|BRA|CB|1997|Arsenal|87|87
David Raya|ESP|GK|1995|Arsenal|86|86
Viktor Gyökeres|SWE|ST|1998|Arsenal|86|86
Martín Zubimendi|ESP|DM|1999|Arsenal|86|87
Eberechi Eze|ENG|AM|1998|Arsenal|84|85
Jurriën Timber|NED|FB|2001|Arsenal|84|86
Gabriel Martinelli|BRA|W|2001|Arsenal|82|84
Leandro Trossard|BEL|W|1994|Arsenal|81|81
Noni Madueke|ENG|W|2002|Arsenal|81|84
Riccardo Calafiori|ITA|FB|2002|Arsenal|82|85
Ethan Nwaneri|ENG|AM|2007|Arsenal|76|88
Myles Lewis-Skelly|ENG|FB|2006|Arsenal|77|87
Kai Havertz|GER|ST|1999|Arsenal|83|84
Piero Hincapié|ECU|CB|2002|Arsenal|83|86
Mohamed Salah|EGY|W|1992|Liverpool|88|88
Virgil van Dijk|NED|CB|1991|Liverpool|88|88
Alisson Becker|BRA|GK|1992|Liverpool|88|88
Florian Wirtz|GER|AM|2003|Liverpool|87|92
Alexander Isak|SWE|ST|1999|Liverpool|87|88
Hugo Ekitike|FRA|ST|2002|Liverpool|84|87
Dominik Szoboszlai|HUN|CM|2000|Liverpool|85|86
Alexis Mac Allister|ARG|CM|1998|Liverpool|86|86
Ryan Gravenberch|NED|DM|2002|Liverpool|86|88
Ibrahima Konaté|FRA|CB|1999|Liverpool|85|86
Jeremie Frimpong|NED|FB|2000|Liverpool|83|84
Milos Kerkez|HUN|FB|2003|Liverpool|81|84
Cody Gakpo|NED|W|1999|Liverpool|83|84
Federico Chiesa|ITA|W|1997|Liverpool|78|78
Giorgi Mamardashvili|GEO|GK|2000|Liverpool|83|86
Rio Ngumoha|ENG|W|2008|Liverpool|70|86
Erling Haaland|NOR|ST|2000|Manchester City|91|92
Phil Foden|ENG|AM|2000|Manchester City|85|87
Rodri|ESP|DM|1996|Manchester City|87|87
Rúben Dias|POR|CB|1997|Manchester City|86|86
Joško Gvardiol|CRO|CB|2002|Manchester City|85|87
Bernardo Silva|POR|CM|1994|Manchester City|84|84
Tijjani Reijnders|NED|CM|1998|Manchester City|85|86
Rayan Cherki|FRA|AM|2003|Manchester City|83|88
Omar Marmoush|EGY|ST|1999|Manchester City|83|84
Jérémy Doku|BEL|W|2002|Manchester City|83|85
Gianluigi Donnarumma|ITA|GK|1999|Manchester City|88|89
Antoine Semenyo|GHA|W|2000|Manchester City|83|84
Rayan Aït-Nouri|ALG|FB|2001|Manchester City|82|84
Nico O'Reilly|ENG|FB|2005|Manchester City|78|85
Matheus Nunes|POR|FB|1998|Manchester City|81|81
Cole Palmer|ENG|AM|2002|Chelsea|87|90
Enzo Fernández|ARG|CM|2001|Chelsea|86|87
Moisés Caicedo|ECU|DM|2001|Chelsea|87|88
Reece James|ENG|FB|1999|Chelsea|84|84
Marc Cucurella|ESP|FB|1998|Chelsea|83|83
Levi Colwill|ENG|CB|2003|Chelsea|82|86
João Pedro|BRA|ST|2001|Chelsea|83|85
Liam Delap|ENG|ST|2003|Chelsea|78|84
Pedro Neto|POR|W|2000|Chelsea|82|83
Estêvão|BRA|W|2007|Chelsea|80|91
Jamie Gittens|ENG|W|2004|Chelsea|78|85
Alejandro Garnacho|ARG|W|2004|Chelsea|79|84
Jorrel Hato|NED|FB|2006|Chelsea|78|86
Robert Sánchez|ESP|GK|1997|Chelsea|80|80
Wesley Fofana|FRA|CB|2000|Chelsea|80|81
Trevoh Chalobah|ENG|CB|1999|Chelsea|80|80
Bruno Fernandes|POR|AM|1994|Manchester United|86|86
Bryan Mbeumo|CMR|W|1999|Manchester United|84|84
Matheus Cunha|BRA|AM|1999|Manchester United|83|84
Benjamin Šeško|SVN|ST|2003|Manchester United|80|86
Kobbie Mainoo|ENG|CM|2005|Manchester United|78|86
Diogo Dalot|POR|FB|1999|Manchester United|79|79
Matthijs de Ligt|NED|CB|1999|Manchester United|81|82
Leny Yoro|FRA|CB|2005|Manchester United|78|86
Senne Lammens|BEL|GK|2002|Manchester United|79|84
Amad Diallo|CIV|W|2002|Manchester United|80|83
Lisandro Martínez|ARG|CB|1998|Manchester United|81|81
Casemiro|BRA|DM|1992|Manchester United|79|79
Bruno Guimarães|BRA|CM|1997|Newcastle|86|86
Sandro Tonali|ITA|DM|2000|Newcastle|84|85
Anthony Gordon|ENG|W|2001|Newcastle|82|83
Nick Woltemade|GER|ST|2002|Newcastle|81|85
Sven Botman|NED|CB|2000|Newcastle|80|82
Nick Pope|ENG|GK|1992|Newcastle|81|81
Tino Livramento|ENG|FB|2002|Newcastle|80|83
Anthony Elanga|SWE|W|2002|Newcastle|79|81
Yoane Wissa|COD|ST|1996|Newcastle|79|79
Joelinton|BRA|CM|1996|Newcastle|80|80
Ollie Watkins|ENG|ST|1995|Aston Villa|83|83
Morgan Rogers|ENG|AM|2002|Aston Villa|83|86
Youri Tielemans|BEL|CM|1997|Aston Villa|82|82
John McGinn|SCO|CM|1994|Aston Villa|80|80
Emiliano Martínez|ARG|GK|1992|Aston Villa|84|84
Ezri Konsa|ENG|CB|1997|Aston Villa|81|81
Amadou Onana|BEL|DM|2001|Aston Villa|80|82
Boubacar Kamara|FRA|DM|1999|Aston Villa|81|81
Pau Torres|ESP|CB|1997|Aston Villa|81|81
Cristian Romero|ARG|CB|1998|Tottenham|85|85
Micky van de Ven|NED|CB|2001|Tottenham|84|85
Guglielmo Vicario|ITA|GK|1996|Tottenham|82|82
Xavi Simons|NED|AM|2003|Tottenham|82|87
Mohammed Kudus|GHA|W|2000|Tottenham|82|83
Dominic Solanke|ENG|ST|1997|Tottenham|80|80
James Maddison|ENG|AM|1996|Tottenham|81|81
Dejan Kulusevski|SWE|W|2000|Tottenham|81|82
Pedro Porro|ESP|FB|1999|Tottenham|81|81
Lucas Bergvall|SWE|CM|2006|Tottenham|76|86
Archie Gray|ENG|CM|2006|Tottenham|75|85
Richarlison|BRA|ST|1997|Tottenham|78|78
Kaoru Mitoma|JPN|W|1997|Brighton|81|81
Carlos Baleba|CMR|DM|2004|Brighton|80|86
Danny Welbeck|ENG|ST|1990|Brighton|76|76
Georginio Rutter|FRA|AM|2002|Brighton|79|82
Jan Paul van Hecke|NED|CB|2000|Brighton|79|80
Jean-Philippe Mateta|FRA|ST|1997|Crystal Palace|81|81
Adam Wharton|ENG|CM|2004|Crystal Palace|81|86
Marc Guéhi|ENG|CB|2000|Crystal Palace|84|85
Dean Henderson|ENG|GK|1997|Crystal Palace|81|81
Ismaïla Sarr|SEN|W|1998|Crystal Palace|80|80
Daniel Muñoz|COL|FB|1996|Crystal Palace|80|80
Morgan Gibbs-White|ENG|AM|2000|Nottingham Forest|82|82
Chris Wood|NZL|ST|1991|Nottingham Forest|78|78
Elliot Anderson|ENG|CM|2002|Nottingham Forest|83|86
Murillo|BRA|CB|2002|Nottingham Forest|81|84
Callum Hudson-Odoi|ENG|W|2000|Nottingham Forest|78|78
Justin Kluivert|NED|AM|1999|Bournemouth|79|79
Evanilson|BRA|ST|1999|Bournemouth|78|79
Tyler Adams|USA|DM|1999|Bournemouth|78|78
Igor Thiago|BRA|ST|2001|Brentford|80|82
Kevin Schade|GER|W|2001|Brentford|77|79
Mikkel Damsgaard|DEN|AM|2000|Brentford|78|79
Alex Iwobi|NGA|AM|1996|Fulham|79|79
Raúl Jiménez|MEX|ST|1991|Fulham|76|76
Antonee Robinson|USA|FB|1997|Fulham|79|79
Bernd Leno|GER|GK|1992|Fulham|80|80
Jordan Pickford|ENG|GK|1994|Everton|83|83
Iliman Ndiaye|SEN|W|2000|Everton|80|82
Jack Grealish|ENG|AM|1995|Everton|80|80
James Tarkowski|ENG|CB|1992|Everton|78|78
Jarrod Bowen|ENG|W|1996|West Ham|81|81
Mads Hermansen|DEN|GK|2000|West Ham|77|80
Granit Xhaka|SUI|CM|1992|Sunderland|81|81
Enzo Le Fée|FRA|CM|2000|Sunderland|76|78
Noah Sadiki|COD|DM|2004|Sunderland|76|82
Jørgen Strand Larsen|NOR|ST|2000|Wolves|77|78
João Gomes|BRA|DM|2001|Wolves|79|81
Dominic Calvert-Lewin|ENG|ST|1997|Leeds|75|75
Ethan Ampadu|WAL|DM|2000|Leeds|75|76
Zian Flemming|NED|AM|1998|Burnley|73|73
Kylian Mbappé|FRA|ST|1998|Real Madrid|91|92
Vinícius Júnior|BRA|W|2000|Real Madrid|89|90
Jude Bellingham|ENG|AM|2003|Real Madrid|89|92
Federico Valverde|URU|CM|1998|Real Madrid|88|88
Aurélien Tchouaméni|FRA|DM|2000|Real Madrid|85|86
Thibaut Courtois|BEL|GK|1992|Real Madrid|89|89
Rodrygo|BRA|W|2001|Real Madrid|83|85
Éder Militão|BRA|CB|1998|Real Madrid|84|84
Antonio Rüdiger|GER|CB|1993|Real Madrid|83|83
Dean Huijsen|ESP|CB|2005|Real Madrid|83|89
Trent Alexander-Arnold|ENG|FB|1998|Real Madrid|85|85
Arda Güler|TUR|AM|2005|Real Madrid|84|90
Franco Mastantuono|ARG|AM|2007|Real Madrid|77|89
Eduardo Camavinga|FRA|CM|2002|Real Madrid|83|86
Álvaro Carreras|ESP|FB|2003|Real Madrid|82|85
Gonzalo García|ESP|ST|2004|Real Madrid|76|82
Dani Carvajal|ESP|FB|1992|Real Madrid|81|81
Lamine Yamal|ESP|W|2007|Barcelona|90|97
Pedri|ESP|CM|2002|Barcelona|89|91
Raphinha|BRA|W|1996|Barcelona|88|88
Robert Lewandowski|POL|ST|1988|Barcelona|84|84
Frenkie de Jong|NED|CM|1997|Barcelona|86|86
Pau Cubarsí|ESP|CB|2007|Barcelona|84|91
Jules Koundé|FRA|FB|1998|Barcelona|85|85
Alejandro Balde|ESP|FB|2003|Barcelona|82|85
Joan García|ESP|GK|2001|Barcelona|85|88
Gavi|ESP|CM|2004|Barcelona|81|87
Dani Olmo|ESP|AM|1998|Barcelona|83|83
Fermín López|ESP|AM|2003|Barcelona|83|86
Marcus Rashford|ENG|W|1997|Barcelona|81|81
Ferran Torres|ESP|ST|2000|Barcelona|80|80
Eric García|ESP|CB|2001|Barcelona|80|81
Marc Casadó|ESP|DM|2003|Barcelona|78|82
Ronald Araújo|URU|CB|1999|Barcelona|81|81
Julián Álvarez|ARG|ST|2000|Atlético Madrid|87|89
Antoine Griezmann|FRA|AM|1991|Atlético Madrid|83|83
Jan Oblak|SVN|GK|1993|Atlético Madrid|86|86
Koke|ESP|CM|1992|Atlético Madrid|79|79
Marcos Llorente|ESP|FB|1995|Atlético Madrid|81|81
Álex Baena|ESP|AM|2001|Atlético Madrid|83|84
Alexander Sørloth|NOR|ST|1995|Atlético Madrid|81|81
Pablo Barrios|ESP|CM|2003|Atlético Madrid|81|86
Giuliano Simeone|ARG|W|2002|Atlético Madrid|79|82
Thiago Almada|ARG|AM|2001|Atlético Madrid|80|82
Robin Le Normand|ESP|CB|1996|Atlético Madrid|81|81
Dávid Hancko|SVK|CB|1997|Atlético Madrid|81|81
Conor Gallagher|ENG|CM|2000|Atlético Madrid|80|80
Nico Williams|ESP|W|2002|Athletic Club|85|88
Iñaki Williams|GHA|ST|1994|Athletic Club|79|79
Oihan Sancet|ESP|AM|2000|Athletic Club|81|82
Unai Simón|ESP|GK|1997|Athletic Club|83|83
Dani Vivian|ESP|CB|1999|Athletic Club|80|80
Mikel Oyarzabal|ESP|ST|1997|Real Sociedad|82|82
Takefusa Kubo|JPN|W|2001|Real Sociedad|81|83
Brais Méndez|ESP|AM|1997|Real Sociedad|78|78
Nicolas Pépé|CIV|W|1995|Villarreal|79|79
Gerard Moreno|ESP|ST|1992|Villarreal|78|78
Dani Parejo|ESP|CM|1989|Villarreal|78|78
Georges Mikautadze|GEO|ST|2000|Villarreal|79|80
Santi Comesaña|ESP|CM|1996|Villarreal|78|78
Alberto Moleiro|ESP|AM|2003|Villarreal|80|85
Isco|ESP|AM|1992|Real Betis|81|81
Antony|BRA|W|2000|Real Betis|80|81
Pablo Fornals|ESP|CM|1996|Real Betis|79|79
Giovani Lo Celso|ARG|CM|1996|Real Betis|79|79
Cucho Hernández|COL|ST|1999|Real Betis|79|79
Iago Aspas|ESP|ST|1987|Celta Vigo|76|76
Borja Iglesias|ESP|ST|1993|Celta Vigo|76|76
Viktor Tsygankov|UKR|W|1997|Girona|78|78
Javi Guerra|ESP|CM|2003|Valencia|78|82
Hugo Duro|ESP|ST|1999|Valencia|76|76
Isaac Romero|ESP|ST|2000|Sevilla|75|77
Rubén Vargas|SUI|W|1998|Sevilla|76|76
Ante Budimir|CRO|ST|1991|Osasuna|78|78
Isi Palazón|ESP|AM|1994|Rayo Vallecano|77|77
Vedat Muriqi|KOS|ST|1994|Mallorca|77|77
Mauro Arambarri|URU|DM|1995|Getafe|76|76
Javi Puado|ESP|ST|1998|Espanyol|75|75
Lautaro Martínez|ARG|ST|1997|Inter|88|88
Marcus Thuram|FRA|ST|1997|Inter|85|85
Nicolò Barella|ITA|CM|1997|Inter|87|87
Hakan Çalhanoğlu|TUR|DM|1994|Inter|85|85
Alessandro Bastoni|ITA|CB|1999|Inter|86|87
Federico Dimarco|ITA|FB|1997|Inter|85|85
Yann Sommer|SUI|GK|1988|Inter|83|83
Denzel Dumfries|NED|FB|1996|Inter|83|83
Davide Frattesi|ITA|CM|1999|Inter|81|81
Francesco Pio Esposito|ITA|ST|2005|Inter|77|85
Ange-Yoan Bonny|FRA|ST|2003|Inter|77|82
Kevin De Bruyne|BEL|AM|1991|Napoli|85|85
Scott McTominay|SCO|CM|1996|Napoli|86|86
Stanislav Lobotka|SVK|DM|1994|Napoli|84|84
André-Frank Zambo Anguissa|CMR|CM|1995|Napoli|83|83
Rasmus Højlund|DEN|ST|2003|Napoli|81|85
Romelu Lukaku|BEL|ST|1993|Napoli|80|80
Giovanni Di Lorenzo|ITA|FB|1993|Napoli|82|82
Alessandro Buongiorno|ITA|CB|1999|Napoli|82|83
Vanja Milinković-Savić|SRB|GK|1997|Napoli|81|81
Matteo Politano|ITA|W|1993|Napoli|80|80
Amir Rrahmani|KOS|CB|1994|Napoli|81|81
Kenan Yıldız|TUR|W|2005|Juventus|85|90
Dušan Vlahović|SRB|ST|2000|Juventus|81|81
Teun Koopmeiners|NED|CM|1998|Juventus|80|80
Manuel Locatelli|ITA|DM|1998|Juventus|81|81
Gleison Bremer|BRA|CB|1997|Juventus|84|84
Francisco Conceição|POR|W|2002|Juventus|81|84
Jonathan David|CAN|ST|2000|Juventus|81|82
Michele Di Gregorio|ITA|GK|1997|Juventus|81|81
Andrea Cambiaso|ITA|FB|2000|Juventus|81|82
Khéphren Thuram|FRA|CM|2001|Juventus|82|84
Loïs Openda|BEL|ST|2000|Juventus|79|80
Rafael Leão|POR|W|1999|Milan|84|85
Christian Pulisic|USA|W|1998|Milan|84|84
Luka Modrić|CRO|CM|1985|Milan|82|82
Mike Maignan|FRA|GK|1995|Milan|87|87
Adrien Rabiot|FRA|CM|1995|Milan|82|82
Youssouf Fofana|FRA|DM|1999|Milan|80|80
Santiago Giménez|MEX|ST|2001|Milan|78|80
Christopher Nkunku|FRA|AM|1997|Milan|79|79
Strahinja Pavlović|SRB|CB|2001|Milan|79|81
Samuele Ricci|ITA|DM|2001|Milan|79|81
Alexis Saelemaekers|BEL|W|1999|Milan|79|79
Ademola Lookman|NGA|W|1997|Atalanta|84|84
Charles De Ketelaere|BEL|AM|2001|Atalanta|83|84
Gianluca Scamacca|ITA|ST|1999|Atalanta|79|79
Éderson|BRA|CM|1999|Atalanta|83|83
Marco Carnesecchi|ITA|GK|2000|Atalanta|82|84
Nikola Krstović|MNE|ST|2000|Atalanta|78|79
Paulo Dybala|ARG|AM|1993|Roma|80|80
Manu Koné|FRA|CM|2001|Roma|83|84
Lorenzo Pellegrini|ITA|AM|1996|Roma|78|78
Mile Svilar|SRB|GK|1999|Roma|84|85
Evan Ndicka|CIV|CB|1999|Roma|81|81
Matías Soulé|ARG|W|2003|Roma|80|83
Evan Ferguson|IRL|ST|2004|Roma|76|81
Mattia Zaccagni|ITA|W|1995|Lazio|80|80
Nicolò Rovella|ITA|DM|2001|Lazio|80|82
Mattéo Guendouzi|FRA|CM|1999|Lazio|79|79
Nico Paz|ARG|AM|2004|Como|83|89
Máximo Perrone|ARG|DM|2003|Como|79|82
Álvaro Morata|ESP|ST|1992|Como|76|76
Assane Diao|SEN|W|2005|Como|77|83
Jesús Rodríguez|ESP|W|2005|Como|76|83
Riccardo Orsolini|ITA|W|1997|Bologna|80|80
Santiago Castro|ARG|ST|2004|Bologna|78|83
Moise Kean|ITA|ST|2000|Fiorentina|81|82
David de Gea|ESP|GK|1990|Fiorentina|82|82
Albert Guðmundsson|ISL|AM|1997|Fiorentina|78|78
Duván Zapata|COL|ST|1991|Torino|74|74
Keinan Davis|ENG|ST|1998|Udinese|74|74
Harry Kane|ENG|ST|1993|Bayern Munich|90|90
Jamal Musiala|GER|AM|2003|Bayern Munich|88|92
Michael Olise|FRA|W|2001|Bayern Munich|88|90
Joshua Kimmich|GER|DM|1995|Bayern Munich|87|87
Manuel Neuer|GER|GK|1986|Bayern Munich|84|84
Dayot Upamecano|FRA|CB|1998|Bayern Munich|84|84
Jonathan Tah|GER|CB|1996|Bayern Munich|84|84
Luis Díaz|COL|W|1997|Bayern Munich|86|86
Serge Gnabry|GER|W|1995|Bayern Munich|81|81
Alphonso Davies|CAN|FB|2000|Bayern Munich|83|84
Konrad Laimer|AUT|FB|1997|Bayern Munich|81|81
Aleksandar Pavlović|GER|DM|2004|Bayern Munich|82|87
Lennart Karl|GER|AM|2008|Bayern Munich|74|88
Leon Goretzka|GER|CM|1995|Bayern Munich|80|80
Serhou Guirassy|GUI|ST|1996|Borussia Dortmund|84|84
Karim Adeyemi|GER|W|2002|Borussia Dortmund|80|82
Julian Brandt|GER|AM|1996|Borussia Dortmund|80|80
Gregor Kobel|SUI|GK|1997|Borussia Dortmund|85|85
Nico Schlotterbeck|GER|CB|1999|Borussia Dortmund|84|85
Maximilian Beier|GER|ST|2002|Borussia Dortmund|79|82
Jobe Bellingham|ENG|CM|2005|Borussia Dortmund|76|84
Waldemar Anton|GER|CB|1996|Borussia Dortmund|80|80
Patrik Schick|CZE|ST|1996|Bayer Leverkusen|81|81
Alejandro Grimaldo|ESP|FB|1995|Bayer Leverkusen|83|83
Robert Andrich|GER|DM|1994|Bayer Leverkusen|79|79
Malik Tillman|USA|AM|2002|Bayer Leverkusen|80|83
Jarell Quansah|ENG|CB|2003|Bayer Leverkusen|79|83
Mark Flekken|NED|GK|1993|Bayer Leverkusen|80|80
David Raum|GER|FB|1998|RB Leipzig|81|81
Christoph Baumgartner|AUT|AM|1999|RB Leipzig|80|80
Yan Diomande|CIV|W|2006|RB Leipzig|76|86
Willi Orbán|HUN|CB|1992|RB Leipzig|80|80
Jonathan Burkardt|GER|ST|2000|Eintracht Frankfurt|80|81
Can Uzun|TUR|AM|2005|Eintracht Frankfurt|78|85
Mario Götze|GER|AM|1992|Eintracht Frankfurt|76|76
Ritsu Doan|JPN|W|1998|Eintracht Frankfurt|79|79
Deniz Undav|GER|ST|1996|VfB Stuttgart|80|80
Ermedin Demirović|BIH|ST|1998|VfB Stuttgart|79|79
Chris Führich|GER|W|1998|VfB Stuttgart|78|78
Maximilian Mittelstädt|GER|FB|1997|VfB Stuttgart|79|79
Angelo Stiller|GER|DM|2001|VfB Stuttgart|81|83
Vincenzo Grifo|ITA|W|1993|SC Freiburg|77|77
Andrej Kramarić|CRO|ST|1991|Hoffenheim|77|77
Said El Mala|GER|W|2006|1. FC Köln|74|85
Mohamed Amoura|ALG|ST|2000|Wolfsburg|79|80
Lee Jae-sung|KOR|AM|1992|Mainz 05|75|75
Tim Kleindienst|GER|ST|1995|Borussia Mönchengladbach|77|77
Ousmane Dembélé|FRA|ST|1997|Paris Saint-Germain|89|89
Khvicha Kvaratskhelia|GEO|W|2001|Paris Saint-Germain|88|89
Désiré Doué|FRA|W|2005|Paris Saint-Germain|85|91
Achraf Hakimi|MAR|FB|1998|Paris Saint-Germain|88|88
Marquinhos|BRA|CB|1994|Paris Saint-Germain|84|84
Vitinha|POR|CM|2000|Paris Saint-Germain|89|90
João Neves|POR|CM|2004|Paris Saint-Germain|86|90
Warren Zaïre-Emery|FRA|CM|2006|Paris Saint-Germain|81|87
Willian Pacho|ECU|CB|2001|Paris Saint-Germain|85|87
Nuno Mendes|POR|FB|2002|Paris Saint-Germain|87|89
Bradley Barcola|FRA|W|2002|Paris Saint-Germain|83|85
Gonçalo Ramos|POR|ST|2001|Paris Saint-Germain|80|81
Lucas Chevalier|FRA|GK|2001|Paris Saint-Germain|83|86
Fabián Ruiz|ESP|CM|1996|Paris Saint-Germain|84|84
Lee Kang-in|KOR|AM|2001|Paris Saint-Germain|79|80
Senny Mayulu|FRA|AM|2006|Paris Saint-Germain|74|84
Mason Greenwood|JAM|W|2001|Marseille|83|84
Pierre-Emerick Aubameyang|GAB|ST|1989|Marseille|78|78
Pierre-Emile Højbjerg|DEN|DM|1995|Marseille|81|81
Gerónimo Rulli|ARG|GK|1992|Marseille|81|81
Nayef Aguerd|MAR|CB|1996|Marseille|80|80
Matt O'Riley|DEN|CM|2000|Marseille|79|80
Igor Paixão|BRA|W|2000|Marseille|79|80
Aleksandr Golovin|RUS|AM|1996|Monaco|80|80
Maghnes Akliouche|FRA|AM|2002|Monaco|81|84
Paul Pogba|FRA|CM|1993|Monaco|76|76
Takumi Minamino|JPN|AM|1995|Monaco|78|78
Folarin Balogun|USA|ST|2001|Monaco|79|81
Ansu Fati|ESP|W|2002|Monaco|76|78
Denis Zakaria|SUI|DM|1996|Monaco|80|80
Lamine Camara|SEN|CM|2004|Monaco|79|84
Hákon Arnar Haraldsson|ISL|AM|2003|Lille|79|82
Olivier Giroud|FRA|ST|1986|Lille|74|74
Malick Fofana|BEL|W|2005|Lyon|79|85
Corentin Tolisso|FRA|CM|1994|Lyon|78|78
Endrick|BRA|ST|2006|Lyon|77|88
Florian Thauvin|FRA|W|1993|Lens|78|78
Joaquín Panichelli|ARG|ST|2002|Strasbourg|78|82
Julio Enciso|PAR|AM|2004|Strasbourg|78|83
Esteban Lepaul|FRA|ST|2000|Rennes|77|78
Terem Moffi|NGA|ST|1999|Nice|76|77
Vangelis Pavlidis|GRE|ST|1998|Benfica|81|81
Nicolás Otamendi|ARG|CB|1988|Benfica|78|78
Anatoliy Trubin|UKR|GK|2001|Benfica|81|83
Fredrik Aursnes|NOR|CM|1995|Benfica|79|79
Heorhiy Sudakov|UKR|AM|2002|Benfica|79|82
Richard Ríos|COL|CM|2000|Benfica|80|82
Samu Aghehowa|ESP|ST|2004|Porto|80|86
Diogo Costa|POR|GK|1999|Porto|84|85
Victor Froholdt|DEN|CM|2006|Porto|76|85
Alan Varela|ARG|DM|2001|Porto|79|81
Rodrigo Mora|POR|AM|2007|Porto|77|87
Morten Hjulmand|DEN|DM|1999|Sporting CP|82|82
Francisco Trincão|POR|W|1999|Sporting CP|82|82
Luis Javier Suárez|COL|ST|1997|Sporting CP|79|79
Pedro Gonçalves|POR|AM|1998|Sporting CP|80|80
Geovany Quenda|POR|W|2007|Sporting CP|77|87
Gonçalo Inácio|POR|CB|2001|Sporting CP|81|83
Ricardo Horta|POR|W|1994|Braga|77|77
Ismael Saibari|MAR|AM|2001|PSV|79|81
Guus Til|NED|AM|1997|PSV|78|78
Joey Veerman|NED|CM|1998|PSV|79|79
Ricardo Pepi|USA|ST|2003|PSV|76|80
Ivan Perišić|CRO|W|1989|PSV|76|76
Mika Godts|BEL|W|2005|Ajax|77|83
Kenneth Taylor|NED|CM|2002|Ajax|78|81
Wout Weghorst|NED|ST|1992|Ajax|75|75
Ayase Ueda|JPN|ST|1998|Feyenoord|77|77
Anis Hadj Moussa|ALG|W|2002|Feyenoord|78|81
Quinten Timber|NED|CM|2001|Feyenoord|79|80
Troy Parrott|IRL|ST|2002|AZ Alkmaar|77|79
Sven Mijnans|NED|AM|2000|AZ Alkmaar|77|78
Victor Osimhen|NGA|ST|1998|Galatasaray|86|86
Leroy Sané|GER|W|1996|Galatasaray|81|81
Barış Alper Yılmaz|TUR|W|2000|Galatasaray|79|80
Lucas Torreira|URU|DM|1996|Galatasaray|79|79
Mauro Icardi|ARG|ST|1993|Galatasaray|77|77
Gabriel Sara|BRA|CM|1999|Galatasaray|79|80
Uğurcan Çakır|TUR|GK|1996|Galatasaray|80|80
Marco Asensio|ESP|AM|1996|Fenerbahçe|80|80
Youssef En-Nesyri|MAR|ST|1997|Fenerbahçe|79|79
N'Golo Kanté|FRA|DM|1991|Fenerbahçe|79|79
Milan Škriniar|SVK|CB|1995|Fenerbahçe|80|80
Ederson|BRA|GK|1993|Fenerbahçe|83|83
Kerem Aktürkoğlu|TUR|W|1998|Fenerbahçe|79|79
Rafa Silva|POR|AM|1993|Beşiktaş|78|78
Orkun Kökçü|TUR|CM|2000|Beşiktaş|80|81
Paul Onuachu|NGA|ST|1994|Trabzonspor|76|76
Hans Vanaken|BEL|AM|1992|Club Brugge|78|78
Christos Tzolis|GRE|W|2002|Club Brugge|79|81
Raphael Onyedika|NGA|DM|2001|Club Brugge|78|80
Yari Verschaeren|BEL|AM|2001|Anderlecht|75|77
Promise David|CAN|ST|2001|Union Saint-Gilloise|74|76
Daizen Maeda|JPN|W|1997|Celtic|79|79
Callum McGregor|SCO|CM|1993|Celtic|77|77
Kasper Schmeichel|DEN|GK|1986|Celtic|77|77
Arne Engels|BEL|CM|2003|Celtic|76|80
Reo Hatate|JPN|CM|1997|Celtic|78|78
James Tavernier|ENG|FB|1991|Rangers|74|74
Mohamed Diomandé|CIV|CM|2001|Rangers|77|80
Nicolas Raskin|BEL|CM|2001|Rangers|75|77
Lawrence Shankland|SCO|ST|1995|Hearts|72|72
Cristiano Ronaldo|POR|ST|1985|Al Nassr|82|82
Sadio Mané|SEN|W|1992|Al Nassr|80|80
João Félix|POR|AM|1999|Al Nassr|80|80
Kingsley Coman|FRA|W|1996|Al Nassr|80|80
Iñigo Martínez|ESP|CB|1991|Al Nassr|79|79
Marcelo Brozović|CRO|DM|1992|Al Nassr|79|79
Theo Hernández|FRA|FB|1997|Al Hilal|83|83
Rúben Neves|POR|CM|1997|Al Hilal|81|81
Sergej Milinković-Savić|SRB|CM|1995|Al Hilal|81|81
Darwin Núñez|URU|ST|1999|Al Hilal|79|80
Kalidou Koulibaly|SEN|CB|1991|Al Hilal|78|78
Yassine Bounou|MAR|GK|1991|Al Hilal|81|81
Malcom|BRA|W|1997|Al Hilal|79|79
Salem Al-Dawsari|KSA|W|1991|Al Hilal|76|76
Karim Benzema|FRA|ST|1987|Al Ittihad|82|82
Moussa Diaby|FRA|W|1999|Al Ittihad|80|80
Fabinho|BRA|DM|1993|Al Ittihad|78|78
Houssem Aouar|ALG|CM|1998|Al Ittihad|78|78
Riyad Mahrez|ALG|W|1991|Al Ahli|79|79
Ivan Toney|ENG|ST|1996|Al Ahli|81|81
Franck Kessié|CIV|CM|1996|Al Ahli|79|79
Édouard Mendy|SEN|GK|1992|Al Ahli|80|80
Merih Demiral|TUR|CB|1998|Al Ahli|80|80
Julián Quiñones|MEX|ST|1997|Al Qadsiah|78|78
Nacho Fernández|ESP|CB|1990|Al Qadsiah|76|76
Lionel Messi|ARG|AM|1987|Inter Miami|86|86
Luis Suárez|URU|ST|1987|Inter Miami|74|74
Rodrigo De Paul|ARG|CM|1994|Inter Miami|80|80
Son Heung-min|KOR|W|1992|LAFC|82|82
Denis Bouanga|GAB|W|1994|LAFC|77|77
Thomas Müller|GER|AM|1989|Vancouver Whitecaps|76|76
Marco Reus|GER|AM|1989|LA Galaxy|73|73
Riqui Puig|ESP|CM|1999|LA Galaxy|75|75
Hirving Lozano|MEX|W|1995|San Diego FC|76|76
Arif Aiman Hanapi|MAS|W|2002|Johor Darul Ta'zim|68|74
Safawi Rasid|MAS|W|1997|Johor Darul Ta'zim|64|64
Syihan Hazmi|MAS|GK|1996|Johor Darul Ta'zim|64|65
Dion Cools|MAS|CB|1996|Johor Darul Ta'zim|65|65
La'Vere Corbin-Ong|MAS|FB|1991|Johor Darul Ta'zim|64|64
Matthew Davies|MAS|FB|1995|Johor Darul Ta'zim|63|63
Feroz Baharudin|MAS|CB|2000|Johor Darul Ta'zim|62|64
Afiq Fazail|MAS|CM|1994|Johor Darul Ta'zim|61|61
Shahrul Saad|MAS|CB|1993|Johor Darul Ta'zim|60|60
Natxo Insa|MAS|DM|1986|Johor Darul Ta'zim|60|60
Bergson da Silva|BRA|ST|1991|Johor Darul Ta'zim|70|70
Juan Muñiz|ESP|AM|1992|Johor Darul Ta'zim|67|67
Óscar Arribas|ESP|CM|1998|Johor Darul Ta'zim|66|66
Faisal Halim|MAS|W|1998|Selangor|63|64
Mukhairi Ajmal|MAS|AM|2001|Selangor|60|64
Quentin Cheng|MAS|FB|1999|Selangor|61|62
Harith Haiqal|MAS|CM|2002|Selangor|58|63
Ali Olwan|JOR|ST|2000|Selangor|66|67
Paulo Josué|BRA|AM|1989|Kuala Lumpur City|64|64
Kenny Pallraj|MAS|CB|1998|Kuala Lumpur City|58|59
Syafiq Ahmad|MAS|ST|1995|Kuala Lumpur City|59|59
Luqman Hakim Shamsudin|MAS|ST|2002|Kuala Lumpur City|60|65
Stuart Wilkin|MAS|CM|1998|Sabah|62|63
Daniel Ting|MAS|CB|1999|Sabah|58|59
Akhyar Rashid|MAS|W|1999|Terengganu|61|62
Azam Azmi|MAS|FB|2001|Terengganu|58|61
Yuma Suzuki|JPN|ST|1996|Kashima Antlers|70|70
Léo Ceará|BRA|ST|1995|Kashima Antlers|71|71
Yuya Osako|JPN|ST|1990|Vissel Kobe|69|69
Yoshinori Muto|JPN|W|1992|Vissel Kobe|69|69
Tolgay Arslan|GER|AM|1990|Sanfrecce Hiroshima|68|68
Mao Hosoya|JPN|ST|2001|Kashiwa Reysol|68|71
Na Sang-ho|KOR|W|1996|Machida Zelvia|67|67
Genki Haraguchi|JPN|AM|1991|Urawa Red Diamonds|66|66
Yasuto Wakizaka|JPN|AM|1995|Kawasaki Frontale|68|68
Marcinho|BRA|W|1995|Kawasaki Frontale|68|68
Takashi Usami|JPN|AM|1992|Gamba Osaka|67|67
Anderson Lopes|BRA|ST|1993|Yokohama F. Marinos|69|69
Takashi Inui|JPN|W|1988|Shimizu S-Pulse|65|65
Jesse Lingard|ENG|AM|1992|FC Seoul|70|70
Lee Seung-woo|KOR|W|1998|Jeonbuk Hyundai Motors|67|67
Song Min-kyu|KOR|W|1999|Jeonbuk Hyundai Motors|67|68
Andrea Compagno|ITA|ST|1996|Jeonbuk Hyundai Motors|68|68
Jo Hyeon-woo|KOR|GK|1991|Ulsan HD|69|69
Kim Young-gwon|KOR|CB|1990|Ulsan HD|66|66
Joo Min-kyu|KOR|ST|1990|Daejeon Hana Citizen|66|66
Ki Sung-yueng|KOR|CM|1989|Pohang Steelers|66|66
Kim Jin-su|KOR|FB|1992|FC Seoul|65|65
Wu Lei|CHN|ST|1991|Shanghai Port|66|66
Yan Junling|CHN|GK|1991|Shanghai Port|63|63
Zhang Linpeng|CHN|CB|1989|Shanghai Port|61|61
Wei Shihao|CHN|W|1995|Chengdu Rongcheng|64|64
Felipe Silva|BRA|ST|1990|Chengdu Rongcheng|67|67
Zhang Yuning|CHN|ST|1997|Beijing Guoan|63|64
Wu Xi|CHN|CM|1989|Shanghai Shenhua|61|61
Wang Shangyuan|CHN|CM|1993|Henan FC|61|61`;

// Legends at their prime: Name|NAT|POS|PrimeAge|Prime era|OVR
const L_RAW=`Lionel Messi (Prime)|ARG|W|25|Barcelona 2011/12|97
Cristiano Ronaldo (Prime)|POR|ST|28|Real Madrid 2013/14|96
Pelé|BRA|ST|26|Santos 1960s|97
Diego Maradona|ARG|AM|26|Napoli 1986/87|97
Johan Cruyff|NED|AM|26|Ajax 1972/73|96
Ronaldo Nazário|BRA|ST|21|Inter 1997/98|96
Franz Beckenbauer|GER|CB|28|Bayern 1973/74|95
Zinedine Zidane|FRA|AM|28|Juventus 2000/01|95
Marco van Basten|NED|ST|25|Milan 1988/89|95
Michel Platini|FRA|AM|28|Juventus 1984/85|95
Ferenc Puskás|HUN|ST|27|Honvéd 1953/54|95
Alfredo Di Stéfano|ARG|ST|29|Real Madrid 1956/57|95
Ronaldinho|BRA|AM|25|Barcelona 2004/05|94
Thierry Henry|FRA|ST|26|Arsenal 2003/04|94
Paolo Maldini|ITA|FB|26|Milan 1993/94|94
Eusébio|POR|ST|25|Benfica 1965/66|94
Gerd Müller|GER|ST|26|Bayern 1971/72|94
Lev Yashin|RUS|GK|30|Dynamo Moscow 1963|94
Zico|BRA|AM|28|Flamengo 1981|94
Franco Baresi|ITA|CB|29|Milan 1989/90|93
Ruud Gullit|NED|AM|26|Milan 1988/89|93
Roberto Baggio|ITA|AM|26|Juventus 1993/94|93
Kaká|BRA|AM|25|Milan 2006/07|93
Andrés Iniesta|ESP|CM|26|Barcelona 2010/11|93
Xavi Hernández|ESP|CM|29|Barcelona 2009/10|93
Gianluigi Buffon|ITA|GK|28|Juventus 2005/06|93
Bobby Charlton|ENG|AM|28|Man Utd 1965/66|93
George Best|NIR|W|22|Man Utd 1967/68|93
Lothar Matthäus|GER|CM|29|Inter 1989/90|93
Romário|BRA|ST|28|Barcelona 1993/94|93
Robert Lewandowski (Prime)|POL|ST|32|Bayern 2020/21|93
Oliver Kahn|GER|GK|31|Bayern 2000/01|92
Iker Casillas|ESP|GK|27|Real Madrid 2008/09|92
Neymar (Prime)|BRA|W|25|Barcelona 2014/15|92
Andriy Shevchenko|UKR|ST|27|Milan 2003/04|92
Rivaldo|BRA|AM|27|Barcelona 1998/99|92
Luís Figo|POR|W|27|Real Madrid 2000/01|92
Fabio Cannavaro|ITA|CB|32|Juventus 2005/06|92
Alessandro Nesta|ITA|CB|26|Milan 2002/03|92
Luis Suárez (Prime)|URU|ST|28|Barcelona 2015/16|92
Kevin De Bruyne (Prime)|BEL|AM|29|Man City 2019/20|92
Andrea Pirlo|ITA|DM|27|Milan 2005/06|91
Francesco Totti|ITA|AM|29|Roma 2006/07|91
Alessandro Del Piero|ITA|AM|24|Juventus 1997/98|91
Gabriel Batistuta|ARG|ST|27|Fiorentina 1995/96|91
Raúl|ESP|ST|24|Real Madrid 2001/02|91
Steven Gerrard|ENG|CM|25|Liverpool 2004/05|91
Wayne Rooney|ENG|ST|25|Man Utd 2009/10|91
Samuel Eto'o|CMR|ST|28|Inter 2009/10|91
Zlatan Ibrahimović|SWE|ST|30|Milan 2011/12|91
Kenny Dalglish|SCO|ST|27|Liverpool 1978/79|91
Eric Cantona|FRA|AM|27|Man Utd 1993/94|91
Roberto Carlos|BRA|FB|28|Real Madrid 2001/02|91
Michael Laudrup|DEN|AM|28|Barcelona 1991/92|91
Hristo Stoichkov|BUL|W|28|Barcelona 1993/94|91
George Weah|LBR|ST|29|Milan 1995/96|91
Alan Shearer|ENG|ST|25|Newcastle 1996/97|91
Dennis Bergkamp|NED|AM|28|Arsenal 1997/98|91
Arjen Robben|NED|W|28|Bayern 2012/13|91
Franck Ribéry|FRA|W|30|Bayern 2012/13|91
Frank Rijkaard|NED|DM|27|Milan 1989/90|91
Sócrates|BRA|CM|28|Corinthians 1982|91
Sergio Ramos (Prime)|ESP|CB|30|Real Madrid 2016/17|91
Luka Modrić (Prime)|CRO|CM|32|Real Madrid 2017/18|91
Karim Benzema (Prime)|FRA|ST|33|Real Madrid 2021/22|91
Frank Lampard|ENG|CM|27|Chelsea 2004/05|90
Carles Puyol|ESP|CB|30|Barcelona 2008/09|90
Didier Drogba|CIV|ST|31|Chelsea 2009/10|90
Bastian Schweinsteiger|GER|CM|28|Bayern 2012/13|90
Philipp Lahm|GER|FB|29|Bayern 2012/13|90
Cafu|BRA|FB|30|Roma 2000/01|90
Gheorghe Hagi|ROU|AM|29|Galatasaray 1999/00|90
Patrick Vieira|FRA|DM|26|Arsenal 2001/02|90
Wesley Sneijder|NED|AM|26|Inter 2009/10|90
Paolo Rossi|ITA|ST|26|Juventus 1982|90
Paul Scholes|ENG|CM|27|Man Utd 2001/02|89
David Beckham|ENG|W|24|Man Utd 1998/99|89
Ryan Giggs|WAL|W|25|Man Utd 1998/99|89
Clarence Seedorf|NED|CM|30|Milan 2006/07|89
Son Heung-min (Prime)|KOR|W|29|Tottenham 2021/22|89
Claude Makélélé|FRA|DM|30|Chelsea 2004/05|88
Cha Bum-kun|KOR|ST|29|Leverkusen 1985/86|88
Hidetoshi Nakata|JPN|AM|24|Roma 2000/01|85
Park Ji-sung|KOR|W|28|Man Utd 2008/09|84
Ali Daei|IRN|ST|27|Bayern 1996/97|84
Mokhtar Dahari|MAS|ST|23|Selangor 1976|78
Soh Chin Ann|MAS|CB|26|Selangor 1976|74
R. Arumugam|MAS|GK|26|Selangor 1979|73
Safee Sali|MAS|ST|26|Selangor 2010|70
Safiq Rahim|MAS|CM|26|Johor Darul Ta'zim 2013|69
Norshahrul Idlan Talaha|MAS|W|26|Kelantan 2012|68
Khairul Fahmi Che Mat|MAS|GK|24|Kelantan 2013|67
Aidil Zafuan|MAS|CB|26|Johor Darul Ta'zim 2013|66
Shunsuke Nakamura|JPN|AM|28|Celtic 2006/07|84
Shinji Kagawa|JPN|AM|23|Dortmund 2011/12|84
Keisuke Honda|JPN|AM|25|CSKA Moscow 2010/11|82
Kazuyoshi Miura|JPN|ST|26|Verdy Kawasaki 1993|80
Hong Myung-bo|KOR|CB|33|Korea 2002|82
Lee Young-pyo|KOR|FB|27|PSV 2004/05|80
Ahn Jung-hwan|KOR|ST|26|Perugia 2001/02|79
Sun Jihai|CHN|FB|27|Man City 2004/05|74
Fan Zhiyi|CHN|CB|28|Crystal Palace 1998/99|74
Hao Haidong|CHN|ST|26|Dalian Wanda 1996|74
Zheng Zhi|CHN|CM|33|Guangzhou Evergrande 2013|74`;

// ---- history: which clubs existed / were in the top flight in a given season ----
// Malaysian top flight changed a lot: JDT only exists under that name from 2013.
const HIST_RAW={
J1:[[1993,2004,"Júbilo Iwata:69,Kashima Antlers:68,Verdy Kawasaki:68,Yokohama F. Marinos:67,Yokohama Flügels:65,Shimizu S-Pulse:65,Nagoya Grampus:65,Kashiwa Reysol:64,Sanfrecce Hiroshima:64,Urawa Red Diamonds:64,Gamba Osaka:64,Bellmare Hiratsuka:63,JEF United Ichihara:63,Cerezo Osaka:63,FC Tokyo:63,Vissel Kobe:61,Kyoto Purple Sanga:61,Avispa Fukuoka:60"],
    [2005,2019,"Kawasaki Frontale:68,Kashima Antlers:68,Urawa Red Diamonds:67,Gamba Osaka:67,Sanfrecce Hiroshima:67,Yokohama F. Marinos:66,Kashiwa Reysol:65,FC Tokyo:65,Nagoya Grampus:65,Júbilo Iwata:64,Cerezo Osaka:64,Vissel Kobe:64,Shimizu S-Pulse:64,Sagan Tosu:62,Vegalta Sendai:62,Albirex Niigata:62,Shonan Bellmare:61,Omiya Ardija:61"]],
KL1:[[1983,2012,"Seongnam Ilhwa Chunma:68,Suwon Samsung Bluewings:68,Pohang Steelers:67,Ulsan Hyundai:67,Jeonbuk Hyundai Motors:66,FC Seoul:66,Busan IPark:63,Jeonnam Dragons:63,Bucheon SK:63,Daejeon Citizen:61,Incheon United:61,Gyeongnam FC:61,Daegu FC:60"],
     [2013,2020,"Jeonbuk Hyundai Motors:69,Ulsan Hyundai:68,FC Seoul:66,Suwon Samsung Bluewings:66,Pohang Steelers:66,Jeju United:64,Seongnam FC:62,Sangju Sangmu:62,Gangwon FC:62,Daegu FC:62,Incheon United:61,Gyeongnam FC:61"]],
CSL:[[1994,2003,"Dalian Wanda:66,Dalian Shide:66,Shandong Luneng:64,Shanghai Shenhua:64,Beijing Guoan:63,Shenzhen Ping'an:62,Sichuan Quanxing:61,Tianjin Teda:61,Liaoning FC:61,Guangzhou Apollo:60,Chongqing Lifan:60,Qingdao Hainiu:59,Yunnan Hongta:59"],
     [2004,2010,"Shandong Luneng:66,Dalian Shide:65,Beijing Guoan:65,Changchun Yatai:64,Shanghai Shenhua:64,Tianjin Teda:63,Henan Jianye:62,Hangzhou Greentown:61,Shaanxi Chanba:61,Liaoning FC:61,Shenzhen FC:61,Jiangsu Sainty:61,Guangzhou Pharmaceutical:61,Changsha Ginde:60,Qingdao Jonoon:60,Chongqing Lifan:60"],
     [2011,2019,"Guangzhou Evergrande:74,Shanghai SIPG:71,Shandong Luneng:69,Beijing Guoan:69,Jiangsu Suning:68,Shanghai Shenhua:67,Hebei China Fortune:66,Tianjin Quanjian:66,Guangzhou R&F:65,Changchun Yatai:63,Henan Jianye:63,Chongqing Lifan:63,Dalian Yifang:63,Tianjin Teda:62,Wuhan Zall:62,Shenzhen FC:62"]],
MSL:[
 [1990,2003,"Selangor:60,Pahang:58,Kedah:58,Perak:58,Negeri Sembilan:57,Kuala Lumpur:57,Sarawak:56,Sabah:56,Terengganu:56,Johor:55,Penang:55,Kelantan:54,Perlis:54,Melaka:53,Brunei:53"],
 [2004,2012,"Kedah:60,Selangor:60,Kelantan:59,Perak:58,Terengganu:57,Negeri Sembilan:57,Perlis:56,Pahang:55,DPMM:55,Johor FC:54,Penang:53,Kuala Lumpur:53,PDRM:52,Sabah:53"],
 [2013,2019,"Johor Darul Ta'zim:65,Selangor:59,Pahang:59,Kedah:59,Kelantan:58,Perak:58,Terengganu:57,Felda United:57,PKNS:55,Melaka United:55,Negeri Sembilan:55,Sarawak:55,Penang:54,PDRM:53,T-Team:53,Kuala Lumpur:53"]]};
// first season a club existed (under this name)
const FOUNDED={"Dalian Shide":2000,"Gimcheon Sangmu":2021,"Daejeon Hana Citizen":2020,"Jeju SK":2025,"FC Anyang":2013,"Suwon FC":2003,"Gangwon FC":2008,"Gwangju FC":2010,"Incheon United":2003,"Gyeongnam FC":2006,"Daegu FC":2003,"Daejeon Citizen":1997,"Ulsan HD":2024,"Shanghai Port":2005,"Chengdu Rongcheng":2018,"Tianjin Jinmen Tiger":2021,"Zhejiang FC":2021,"Henan FC":2023,"Qingdao West Coast":2013,"Wuhan Three Towns":2013,"Shenzhen Peng City":2023,"Yunnan Yukun":2021,"Dalian Yingbo":2018,"Meizhou Hakka":2013,"Liaoning Tieren":2020,"Machida Zelvia":1989,"V-Varen Nagasaki":2005,"Fagiano Okayama":2004,"Vissel Kobe":1995,"Avispa Fukuoka":1996,"Kyoto Purple Sanga":1996,"FC Tokyo":1999,"Shonan Bellmare":2000,"Sagan Tosu":1997,"Inter Miami":2020,"LAFC":2018,"San Diego FC":2025,"Charlotte FC":2022,"Nashville SC":2020,"Atlanta United":2017,"Orlando City":2015,"FC Cincinnati":2019,"Vancouver Whitecaps":2011,"Seattle Sounders":2009,"Philadelphia Union":2010,"RB Leipzig":2009,"AVS":2023,"Neom":2023,"Kuching City":2021,"Immigration":2020,"Johor Darul Ta'zim":2013};
// first season a league existed
const LEAGUE_FROM={MLS:1996,J1:1993,CSL:1994};
const DISSOLVED={'Yokohama Flügels':1998,'Bellmare Hiratsuka':1999,'Verdy Kawasaki':2000,'Dalian Wanda':1999,'Guangzhou Evergrande':2025,'Jiangsu Suning':2020,'Tianjin Quanjian':2018};
ERA.push(['Vissel Kobe',2018,2020,66],['Kashima Antlers',2016,2018,69],['Jeonbuk Hyundai Motors',2014,2021,70],['Ulsan HD',2022,2024,68],['Shanghai Port',2023,2025,68],['Kawasaki Frontale',2017,2021,70],['Kedah',2006,2008,63],['Kelantan',2010,2012,63],['Selangor',2009,2010,62],["Johor Darul Ta'zim",2014,2019,66],['Selangor',1990,1997,62],['Pahang',1992,1999,61]);

// ---- managers ----  Name|NAT|Style|BirthYear|Known for|Rating|Youth development (0-1)
const M_RAW=`Pep Guardiola|ESP|Possession|1971|Barcelona, Bayern, Man City|94|.7
Carlo Ancelotti|ITA|Balanced|1959|Milan, Real Madrid, Brazil|92|.5
Luis Enrique|ESP|Possession|1970|Barcelona, Spain, PSG|92|.85
Jürgen Klopp|GER|Gegenpress|1967|Dortmund, Liverpool|92|.75
Mikel Arteta|ESP|Possession|1982|Arsenal|88|.75
Arne Slot|NED|Possession|1978|Feyenoord, Liverpool|87|.6
Xabi Alonso|ESP|Possession|1981|Leverkusen, Real Madrid|88|.7
Hansi Flick|GER|Gegenpress|1965|Bayern, Germany, Barcelona|89|.85
Diego Simeone|ARG|Defensive|1970|Atlético Madrid|88|.4
Simone Inzaghi|ITA|Counter|1976|Lazio, Inter, Al Hilal|87|.4
Antonio Conte|ITA|Counter|1969|Juventus, Chelsea, Inter, Napoli|89|.3
Thomas Tuchel|GER|Possession|1973|PSG, Chelsea, Bayern, England|88|.5
José Mourinho|POR|Defensive|1963|Porto, Chelsea, Inter, Real Madrid|86|.3
Zinedine Zidane|FRA|Balanced|1972|Real Madrid|88|.5
Unai Emery|ESP|Counter|1971|Sevilla, Villarreal, Aston Villa|87|.5
Vincent Kompany|BEL|Attacking|1986|Burnley, Bayern|86|.7
Julian Nagelsmann|GER|Possession|1987|Hoffenheim, Leipzig, Germany|86|.75
Didier Deschamps|FRA|Defensive|1968|Monaco, Juventus, France|87|.4
Lionel Scaloni|ARG|Balanced|1978|Argentina|87|.5
Gian Piero Gasperini|ITA|Gegenpress|1958|Atalanta, Roma|86|.8
Massimiliano Allegri|ITA|Defensive|1967|Milan, Juventus|85|.35
Luciano Spalletti|ITA|Possession|1959|Roma, Napoli, Juventus|85|.5
Roberto De Zerbi|ITA|Possession|1979|Sassuolo, Brighton, Marseille|85|.75
Mauricio Pochettino|ARG|Gegenpress|1972|Southampton, Tottenham, USA|84|.85
Eddie Howe|ENG|Gegenpress|1977|Bournemouth, Newcastle|83|.6
Andoni Iraola|ESP|Gegenpress|1982|Rayo Vallecano, Bournemouth|83|.65
Oliver Glasner|AUT|Counter|1974|Frankfurt, Crystal Palace|83|.5
Thomas Frank|DEN|Balanced|1973|Brentford, Tottenham|82|.65
Marco Silva|POR|Balanced|1977|Fulham|81|.5
Ruben Amorim|POR|Attacking|1985|Sporting CP, Man Utd|82|.75
Erik ten Hag|NED|Possession|1970|Ajax, Man Utd|80|.75
Niko Kovač|CRO|Counter|1971|Frankfurt, Bayern, Dortmund|82|.5
Sebastian Hoeneß|GER|Possession|1982|Stuttgart|81|.7
Cesc Fàbregas|ESP|Possession|1987|Como|80|.75
Francesco Farioli|ITA|Possession|1989|Nice, Ajax, Porto|82|.7
Sérgio Conceição|POR|Gegenpress|1974|Porto, Milan|82|.55
Jorge Jesus|POR|Attacking|1954|Benfica, Flamengo, Al Hilal|82|.5
Brendan Rodgers|NIR|Possession|1973|Liverpool, Leicester, Celtic|81|.6
Okan Buruk|TUR|Attacking|1973|Galatasaray|80|.45
Ole Gunnar Solskjær|NOR|Counter|1973|Man Utd|78|.65
Ange Postecoglou|AUS|Attacking|1965|Celtic, Tottenham|80|.6
Javier Mascherano|ARG|Balanced|1984|Inter Miami|74|.6
Hajime Moriyasu|JPN|Counter|1968|Sanfrecce Hiroshima, Japan|80|.6
Hong Myung-bo|KOR|Defensive|1969|Ulsan, South Korea|76|.5
Kim Pan-gon|KOR|Counter|1969|Malaysia, Ulsan|72|.55
Peter Cklamovski|AUS|Attacking|1978|Malaysia|70|.6`;
// Legend managers at their peak: Name|NAT|Style|PeakAge|Peak era|Rating|Youth
const ML_RAW=`Sir Alex Ferguson|SCO|Attacking|58|Man Utd 1998/99|97|.85
Arrigo Sacchi|ITA|Gegenpress|43|Milan 1988/89|95|.6
Johan Cruyff|NED|Possession|45|Barcelona 1991/92|94|.9
Rinus Michels|NED|Possession|43|Ajax 1970/71|94|.8
Bob Paisley|ENG|Balanced|58|Liverpool 1976/77|93|.6
Helenio Herrera|ARG|Defensive|50|Inter 1964/65|93|.4
Brian Clough|ENG|Counter|44|Nottingham Forest 1978/79|92|.6
Jupp Heynckes|GER|Gegenpress|68|Bayern 2012/13|92|.6
Arsène Wenger|FRA|Attacking|54|Arsenal 2003/04|92|.9
Valeriy Lobanovskyi|UKR|Gegenpress|47|Dynamo Kyiv 1985/86|91|.85
Matt Busby|SCO|Attacking|59|Man Utd 1967/68|91|.95
Marcello Lippi|ITA|Balanced|58|Juventus 1996, Italy 2006|91|.45
Fabio Capello|ITA|Defensive|48|Milan 1993/94|91|.4
Vicente del Bosque|ESP|Possession|59|Real Madrid, Spain 2010|90|.55
Ottmar Hitzfeld|GER|Balanced|52|Dortmund, Bayern 2000/01|90|.5
Bill Shankly|SCO|Attacking|51|Liverpool 1964/65|90|.7
Ernst Happel|AUT|Gegenpress|57|Hamburg 1982/83|91|.6
Louis van Gaal|NED|Possession|44|Ajax 1994/95|89|.9
Telê Santana|BRA|Attacking|51|São Paulo 1992|89|.7
César Luis Menotti|ARG|Attacking|40|Argentina 1978|88|.6
Guus Hiddink|NED|Gegenpress|55|PSV, South Korea 2002|87|.6
Rafael Benítez|ESP|Counter|45|Valencia, Liverpool 2004/05|86|.45
Otto Rehhagel|GER|Defensive|66|Greece 2004|85|.4
K. Rajagobal|MAS|Counter|54|Malaysia AFF 2010|72|.6
Ong Kim Swee|MAS|Balanced|46|Harimau Muda, Malaysia|70|.85`;
