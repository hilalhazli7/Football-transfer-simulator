// Football Transfer Simulator — user interface
// ENABLE_AI is false: the optional AI extras (scout, AI player finder, pundit) only work inside Claude,
// so they are switched off here. Every result comes from js/engine.js.
const ENABLE_AI=false;
// ---------- UI ----------
let sample=null;const aiCache={};let mode='p',msel=null,mfilt='ALL';
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const norm=s=>s.normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase();
const natName=c=>NATIONS[c]?NATIONS[c][0]:c;
const money=v=>v>=1?'€'+(v>=10?Math.round(v):v.toFixed(1))+'m':'€'+Math.max(10,Math.round(v*1000/10)*10)+'k';
const ord=n=>{n=Math.round(n);const s=['th','st','nd','rd'],v=n%100;return n+(s[(v-20)%10]||s[v]||s[0])};
const pct=x=>(x*100).toFixed(x<.1&&x>0?1:0)+'%';
PLAYERS.forEach(p=>p._s=norm(p.name+' '+p.club+' '+natName(p.nat)));

let filt='ALL',sel=null,lastSeed=0,customN=0;
const FILTERS=[['ALL','All players'],['LEG','⭐ Legends'],['MAS','🇲🇾 Malaysian'],['ASIA','🌏 Asian players'],...LEAGUES.map(l=>[l.id,l.name])];
$('#chips').innerHTML=FILTERS.map(([k,v])=>`<button class="chip${k==='ALL'?' on':''}" data-f="${k}">${esc(v)}</button>`).join('');
$('#chips').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;filt=b.dataset.f;document.querySelectorAll('#chips .chip').forEach(c=>c.classList.toggle('on',c===b));renderList()};
$('#q').oninput=renderList;

function pSub(p){return `${p.pos} · ${esc(natName(p.nat))} · ${p.legend?esc(p.club):esc(p.club)+' · now '+(DATA_YEAR-p.birth)} · <b>at 18: ${Math.round(level18(p).ovr)}</b>`}
function renderList(){
  const q=norm($('#q').value.trim());const ws=q?q.split(/\s+/):[];
  const arr=PLAYERS.filter(p=>{if(filt==='LEG'&&!p.legend)return false;if(filt==='MAS'&&p.nat!=='MAS')return false;if(filt==='ASIA'&&!(NATIONS[p.nat]&&NATIONS[p.nat][2]==='AFC'))return false;if(LEAGUE_BY_ID[filt]&&p.league!==filt)return false;return ws.every(w=>p._s.includes(w))}).sort((a,b)=>b.ovr-a.ovr);
  $('#count').textContent=arr.length+' player'+(arr.length===1?'':'s');
  $('#list').innerHTML=arr.slice(0,150).map(p=>`<div class="row${sel&&sel.id===p.id?' sel':''}" data-id="${p.id}"><div class="ovr${p.legend?' leg':''}">${p.ovr}</div><div class="grow"><div class="nm">${esc(p.name)}${p.ai?' <span class="tag">AI</span>':''}</div><div class="sub">${pSub(p)}</div></div></div>`).join('')||'<div class="empty">No match. Try another spelling, or create a custom player below.</div>';
}
$('#list').onclick=e=>{const r=e.target.closest('.row');if(!r)return;selectPlayer(PLAYERS.find(p=>p.id===r.dataset.id))};
function selectPlayer(p){
  sel=p;document.querySelectorAll('#list .row').forEach(x=>x.classList.toggle('sel',x.dataset.id===p.id));
  $('#picked').innerHTML=`<div class="ovr${p.legend?' leg':''}">${p.ovr}</div><div class="grow"><div class="nm">${esc(p.name)}${p.legend?' <span class="tag gold">Legend</span>':''}</div><div class="sub">${esc(POS_NAME[p.pos])} · ${pSub(p)}</div></div>`;
  $('#picked').hidden=false;updateInfo();
}

// custom player
$('#cNat').innerHTML=Object.entries(NATIONS).sort((a,b)=>a[1][0].localeCompare(b[1][0])).map(([k,v])=>`<option value="${k}"${k==='MAS'?' selected':''}>${esc(v[0])}</option>`).join('');
$('#cPos').innerHTML=Object.entries(POS_NAME).map(([k,v])=>`<option value="${k}"${k==='ST'?' selected':''}>${v}</option>`).join('');
$('#cAdd').onclick=()=>{
  const name=$('#cName').value.trim()||'Custom Player';const age=clamp(+$('#cAge').value||22,15,40),ovr=clamp(+$('#cOvr').value||70,40,99),pot=Math.max(ovr,clamp(+$('#cPot').value||ovr,40,99));
  const p={id:'c'+(customN++),name,nat:$('#cNat').value,pos:$('#cPos').value,birth:DATA_YEAR-age,club:$('#cClub').value.trim()||'Custom',league:'',ovr,pot,legend:false,custom:true};
  p._s=norm(p.name+' '+p.club+' '+natName(p.nat));PLAYERS.push(p);$('#q').value='';filt='ALL';renderList();selectPlayer(p);$('#customBox').open=false;
};

// destination
$('#league').innerHTML=LEAGUES.map(l=>`<option value="${l.id}">${esc(l.name)} (${esc(l.country)})</option>`).join('');
function fillClubs(){const lid=$('#league').value,y=+$('#season').value,prev=$('#club').value;
  const cl=leagueClubsFor(lid,y);
  $('#club').innerHTML=cl.length?[...cl].sort((a,b)=>b.r-a.r).map(c=>`<option value="${esc(c.name)}">${esc(c.name)} · ${Math.round(c.r)}</option>`).join(''):'<option value="">— league did not exist yet —</option>';
  if(cl.some(c=>c.name===prev))$('#club').value=prev;
  else if(prev&&cl.length){const f=FOUNDED[prev];$('#clubNote').innerHTML=`<span class="warn">${esc(prev)} ${f&&y<f?`didn’t exist in ${seasonLabel(y)} (founded ${f}).`:`wasn’t in the ${esc(leagueNameFor(LEAGUE_BY_ID[lid],y))} in ${seasonLabel(y)}.`}</span> Showing the clubs of that season instead.`;return}
  $('#clubNote').innerHTML=cl.length&&(HIST[lid]||[]).some(h=>y>=h[0]&&y<=h[1])?`<span class="sub">Clubs of the ${esc(leagueNameFor(LEAGUE_BY_ID[lid],y))} in ${seasonLabel(y)}.</span>`:'';}
const seasons=[];for(let y=1990;y<=2035;y++)seasons.push(y);
$('#season').innerHTML=seasons.map(y=>`<option value="${y}"${y===2027?' selected':''}>${seasonLabel(y)}${y===2026?' (Jan window)':y===2027?' (next summer)':''}</option>`).join('');
$('#league').onchange=()=>{$('#clubNote').innerHTML='';fillClubs();updateInfo()};
$('#club').addEventListener('change',()=>{$('#clubNote').innerHTML=''});
$('#season').onchange=()=>{fillClubs();updateInfo()};
$('#club').onchange=updateInfo;
$('#years').oninput=()=>{$('#yrsOut').textContent=$('#years').value+(+$('#years').value===1?' season':' seasons')};

function currentCfg(){
  const needP=mode!=='m',needM=mode!=='p';
  if(needP&&!sel)return{err:'Pick a player first.'};
  if(needM&&!msel)return{err:'Pick a manager first.'};
  const y=+$('#season').value;
  const league=$('#league').value,club=$('#club').value,L=LEAGUE_BY_ID[league];
  const cc=leagueClubsFor(league,y).find(c=>c.name===club);
  if(!cc)return{err:`The ${L.name} didn’t exist in ${seasonLabel(y)} (it started in ${LEAGUE_FROM[league]||'?'}). Pick a later season.`};
  const cr=cc.r;
  const cfg={p:null,m:null,league,club,start:y,years:+$('#years').value,clubRating:cr,transfers:$('#trf').checked};
  if(needP){const pr=level18(sel);cfg.p={...sel,age:pr.age,ovr:pr.ovr,pot:pr.pot};
    const ai=sample&&$('#aiCal').checked?aiCache[aiKey()]:null;
    if(ai){cfg.ai=ai;cfg.modelOvr=pr.ovr;cfg.modelClub=cr;cfg.p.ovr=ai.ovr;cfg.p.pot=Math.max(ai.ovr,ai.pot);if(ai.clubStrength)cfg.clubRating=ai.clubStrength;if(ai.leagueClubs)cfg.leagueOverride=ai.leagueClubs;cfg.roleBias=roleBiasFor(ai.expectedRole,ai.ovr-cfg.clubRating)}}
  if(needM){cfg.m={...msel,age:managerAt(msel,y)};let ml=league,mc=club,mr=cfg.clubRating;
    if(mode==='b'&&$('#mDiff').checked){ml=$('#mLeague').value;mc=$('#mClub').value;const c2=leagueClubsFor(ml,y).find(c=>c.name===mc);
      if(!c2)return{err:`Pick a club for the manager that existed in ${seasonLabel(y)}.`};mr=c2.r;if(ml===league&&mc!==club&&cfg.leagueOverride){}}
    cfg.mLeague=ml;cfg.mClub=mc;cfg.mClubRating=mr}
  return cfg;
}
function roleFor(ovr,cr,pos){const d=ovr-cr;if(pos==='GK')return d>=-2?'First-choice keeper':d>=-6?'Rotation keeper':'Backup keeper';return d>=-3?'Starter':d>=-8?'Rotation':'Bench'}
function feeInfo(cfg){
  const src=cfg.p.legend?1:(LEAGUE_BY_ID[cfg.p.league]?LEAGUE_BY_ID[cfg.p.league].coef:.8);
  const fee=marketValue(cfg.p.ovr,cfg.p.age,src)*(cfg.p.legend?1.3:1.15)*eraF(cfg.start);
  const budget=clubBudget(cfg.league,cfg.clubRating)*eraF(cfg.start);const ratio=budget/fee;
  let real=ratio>=1?['Realistic','ok']:ratio>=.5?['A stretch','mid']:ratio>=.15?['Dream move','mid']:['Pure fantasy','bad'];
  const gap=cfg.p.ovr-cfg.clubRating;
  if(gap<-12)real=['Very unlikely (level gap)','bad'];else if(gap<-7&&real[1]==='ok')real=['Unlikely (level gap)','mid'];
  if(cfg.ai&&cfg.ai.plausibility!=null)real=[`AI: ${cfg.ai.plausibility}/100 plausible`,cfg.ai.plausibility>=60?'ok':cfg.ai.plausibility>=30?'mid':'bad'];
  const fee2=cfg.ai&&cfg.ai.feeEurM>0?cfg.ai.feeEurM:fee;
  return{fee:fee2,real};
}
function updateInfo(){
  const cfg=currentCfg();const box=$('#info');
  if(cfg.err){box.innerHTML=(sel||msel)?`<span class="warn">${esc(cfg.err)}</span>`:'';return}
  if(!cfg.p){box.innerHTML=mgrInfo(cfg);return}
  const f=feeInfo(cfg);const same=!cfg.p.legend&&cfg.p.club===cfg.club&&cfg.start<=2026;
  box.innerHTML=`<div class="kpis">
   <div><span>Age (reset)</span><b>18</b></div>
   <div><span>Rating at 18</span><b>${Math.round(cfg.p.ovr)}</b></div>
   <div><span>Club strength</span><b>${Math.round(cfg.clubRating)}</b></div>
   <div><span>Expected role</span><b>${roleFor(cfg.p.ovr,cfg.clubRating,cfg.p.pos)}</b></div>
   <div><span>Est. fee</span><b>${money(f.fee)}</b></div>
   <div><span>Realism</span><b class="${f.real[1]}">${f.real[0]}</b></div></div>${same?'<div class="sub" style="margin-top:6px">He already plays here — this simply simulates his future at the club.</div>':''}`+(cfg.ai?`<div class="aibox">✨ <b>AI scout:</b> rating ${Math.round(cfg.modelOvr)} → <b>${Math.round(cfg.ai.ovr)}</b>, potential ${Math.round(cfg.ai.pot)}, expected role <b>${esc(cfg.ai.expectedRole)}</b>. ${esc(cfg.ai.reasoning||'')}${cfg.ai.clubStrength?`<br>Club strength from the real ${seasonLabel(cfg.start)} squad: ${Math.round(cfg.modelClub)} → <b>${Math.round(cfg.ai.clubStrength)}</b>.`:''}${cfg.leagueOverride?` Using the real ${seasonLabel(cfg.start)} league line-up (${cfg.leagueOverride.length} clubs).`:''}</div>`:'')+(cfg.m?mgrInfo(cfg):'');
}

// ---------- run ----------
$('#go').onclick=()=>run(Math.floor(Math.random()*1e9));
$('#again')&&($('#again').onclick=()=>run(Math.floor(Math.random()*1e9)));
let lastRun=null,lastAgg=null,running=false;
async function run(seed){
  if(running)return;
  let cfg=currentCfg();if(cfg.err){updateInfo();$('#info').scrollIntoView({behavior:'smooth',block:'center'});return}
  running=true;$('#go').disabled=true;
  try{
    if(cfg.p&&sample&&$('#aiCal').checked&&!aiCache[aiKey()]){
      $('#aiCalMsg').innerHTML='<span class="spin"></span> AI is scouting the player and the club…';
      try{await aiCalibrate(cfg);cfg=currentCfg();updateInfo()}catch(e){$('#aiCalMsg').innerHTML='<span class="warn">'+esc(aiErr(e))+' Using the built-in model.</span>'}
    }
  }finally{running=false;$('#go').disabled=false}
  lastSeed=seed;const res=simulate({...cfg,detail:true},seed,true);lastRun={cfg,res};lastAgg=null;
  renderResults(cfg,res);$('#results').hidden=false;$('#results').scrollIntoView({behavior:'smooth'});
  $('#pundit').innerHTML='';
  $('#oddsBody').innerHTML='<div class="sub">Running 150 simulations…</div>';$('#clubVerdict').innerHTML='<span class="sub">Comparing with and without him…</span>';
  setTimeout(()=>{const n=150;const a=monteCarlo(cfg,n);lastAgg={a,n};renderOdds(cfg,a,n)},30);
}

function clubCell(s){const c=s.pclub;return `${esc(c.name)}${c.loan?' <span class="tag">loan</span>':''}<div class="sub">${ord(c.pos)} · ${esc(c.league)}</div>`}
function ccell(s){return s.club.cups.map(c=>`<div class="mini${c.res==='Winner'?' win':''}">${esc(c.name)}: ${esc(c.res)}</div>`).join('')}
function tags(arr,cls=''){return arr.map(t=>`<span class="tag ${/Ballon|Champions$|World Cup|Winner|League$|Liga|Serie A|Bundesliga|Ligue 1|Golden|Player of/.test(t)?'gold':cls}">${esc(t)}</span>`).join('')}

function renderResults(cfg,res){
  const hasP=!!cfg.p,hasM=!!cfg.m;
  document.querySelectorAll('.p-only').forEach(e=>e.hidden=!hasP);document.querySelectorAll('.m-only').forEach(e=>e.hidden=!hasM);
  $('#mgrHead').innerHTML='';
  if(hasM)renderManager(cfg,res);
  renderClubTab(cfg,res);
  if(!hasP){renderMgrOnlyHeader(cfg,res);$('#squad').hidden=true;
    const S=res.seasons,E=S.filter(s=>s.mgr&&s.mgr.status==='Employed');
    $('#charts').innerHTML=`<h3>${esc(cfg.club)} league finish</h3>${lineChart(S.map(s=>s.club.pos),S.map(s=>s.label),{invert:true,min:1,max:leagueClubsFor(cfg.league,cfg.start).length,fmt:v=>ord(v)+' place'})}
     <h3>Manager win % per season (league)</h3>${barChart(E.map(s=>Math.round(s.mgr.W/Math.max(1,s.mgr.P)*100)),E.map(s=>s.label),{fmt:v=>v+'% wins'})}`;
    setTab('m');return}
  const S=res.seasons,P=S.filter(s=>s.playing),L=LEAGUE_BY_ID[cfg.league];const f=feeInfo(cfg);
  const def=['GK','CB','FB','DM'].includes(cfg.p.pos);
  const tot={apps:0,g:0,a:0,cs:0,caps:0,ig:0};P.forEach(s=>{tot.apps+=s.apps;tot.g+=s.goals;tot.a+=s.assists;tot.cs+=s.cs||0;if(s.intl){tot.caps+=s.intl.caps;tot.ig+=s.intl.goals}});
  const INTL=/World Cup|EURO|Copa|AFCON|Asian Cup|ASEAN|Gold Cup/;const ptroph=[];P.forEach(s=>ptroph.push(...s.trophies.filter(t=>INTL.test(t)||s.apps>=10)));const clubTroph=[];S.forEach(s=>clubTroph.push(...s.clubTrophies));
  const awards=[];P.forEach(s=>awards.push(...s.awards));
  const bdo=P.filter(s=>s.bdo===1).length,peak=Math.max(...P.map(s=>s.ovr),cfg.p.ovr),avgMs=P.reduce((x,s)=>x+s.ms,0)/(P.length||1);
  const avgR=P.reduce((x,s)=>x+s.rating,0)/(P.length||1);
  // career path
  const stints=[];S.forEach(s=>{if(!s.playing)return;const k=s.pclub.name+(s.pclub.loan?' (loan)':'');const last=stints[stints.length-1];if(last&&last.k===k)last.n++;else stints.push({k,lg:s.pclub.league,n:1,from:s.label})});
  $('#path').innerHTML=stints.map((t,i)=>`<div class="stint"><b>${esc(t.k)}</b><span>${esc(t.lg)} · ${t.n} season${t.n>1?'s':''}</span></div>`).join('<div class="parr">→</div>')+
   (res.moves.length?`<div class="moves">${res.moves.map(m=>`<div class="mv1"><b>${m.season}</b> · ${esc(m.type)}: ${esc(m.from)} → <b>${esc(m.to)}</b>${m.fee?' · <b>'+money(m.fee)+'</b>':m.type==='Loan'?' · loan':''}<div class="sub">${esc(m.reason)} (age ${m.age}, rating ${Math.round(m.ovr)})</div></div>`).join('')}</div>`:`<p class="sub">${cfg.transfers?'He spends his whole simulated career at '+esc(cfg.club)+'.':'Transfers during the simulation are switched off.'}</p>`);
  // header
  $('#xfer').innerHTML=`<div class="side"><div class="ovr big${cfg.p.legend?' leg':''}">${Math.round(cfg.p.ovr)}</div><div><div class="nm">${esc(cfg.p.name)}</div><div class="sub">${esc(POS_NAME[cfg.p.pos])} · ${esc(natName(cfg.p.nat))} · age ${cfg.p.age}</div><div class="sub">Age-18 version · ${cfg.p.legend?'legend ('+esc(cfg.p.club)+')':'from '+esc(cfg.p.club)}</div></div></div>
   <div class="arrow">→</div>
   <div class="side"><div class="crest">${esc(cfg.club.split(/\s+/).filter(w=>/^[A-Z0-9]/.test(w)).map(w=>w[0]).join('').slice(0,3)||cfg.club[0])}</div><div><div class="nm">${esc(cfg.club)}</div><div class="sub">${esc(L.name)}</div><div class="sub">Joins for <b>${seasonLabel(cfg.start)}</b> · ${cfg.years} season${cfg.years>1?'s':''} simulated</div></div></div>`;
  $('#xferK').innerHTML=`<div><span>Est. fee</span><b>${money(f.fee)}</b></div><div><span>Realism</span><b class="${f.real[1]}">${f.real[0]}</b></div><div><span>Club strength</span><b>${Math.round(cfg.clubRating)} → ${(cfg.clubRating+(S[0].club.impact||0)).toFixed(1)}</b></div><div><span>Sim #</span><b>${lastSeed%100000}</b></div>`;
  // tiles
  $('#tiles').innerHTML=[['Apps',tot.apps],['Goals',tot.g],['Assists',tot.a],def?['Clean sheets',tot.cs]:['G+A / game',tot.apps?((tot.g+tot.a)/tot.apps).toFixed(2):'0'],['Trophies',ptroph.length],["Ballon d'Or",bdo],['Peak rating',Math.round(peak)],['Intl caps / goals',tot.caps+' / '+tot.ig]].map(([k,v])=>`<div class="tile"><b>${v}</b><span>${k}</span></div>`).join('');
  // player verdict
  const role=avgMs>=.7?'becomes an undisputed starter':avgMs>=.4?'is mostly a rotation option':'struggles for minutes and spends a lot of time on the bench';
  const dev=peak-cfg.p.ovr>=3?` He grows into a ${Math.round(peak)}-rated player.`:P.length&&P[P.length-1].ovr<cfg.p.ovr-3?` His level drops from ${Math.round(cfg.p.ovr)} to ${Math.round(P[P.length-1].ovr)} with age.`:'';
  const domin=cfg.p.ovr>cfg.clubRating+10&&L.coef<.75?' He is far above the league’s level, so the numbers are huge — but weaker opposition slows his development and lowers his Ballon d’Or chances.':'';
  const hon=ptroph.length?` He lifts ${ptroph.length} troph${ptroph.length>1?'ies':'y'}${bdo?` and wins ${bdo} Ballon d’Or${bdo>1?'s':''}`:''}.`:' He leaves without a trophy.';
  const mvs=res.moves.filter(m=>m.type!=='Loan return');const firstOut=mvs.find(m=>m.type==='Transfer');
  const end=(mvs.length?` Career path: ${stints.map(t=>t.k).join(' → ')}.${firstOut?` He leaves ${esc(firstOut.from)} in ${firstOut.season} (${esc(firstOut.reason.toLowerCase())})${firstOut.fee?' for '+money(firstOut.fee):''}.`:''}`:'')+(res.endReason?` ${res.endReason}.`:'');
  $('#playerVerdict').innerHTML=`<b>${esc(cfg.p.name)}</b> starts at 18 and ${role}${mvs.length?'':' at '+esc(cfg.club)}: <b>${tot.g} goals and ${tot.a} assists in ${tot.apps} games</b> (avg rating ${avgR.toFixed(2)}).${dev}${hon}${domin}${end}`;
  // real squad (AI)
  const sq=$('#squad');
  if(cfg.ai&&cfg.ai.squad&&cfg.ai.squad.length){const order=['GK','CB','FB','DM','CM','AM','W','ST'];
    const rows=[...cfg.ai.squad,{name:cfg.p.name+' (new)',pos:cfg.p.pos,ovr:Math.round(cfg.p.ovr),me:true}].sort((x,y)=>order.indexOf(x.pos)-order.indexOf(y.pos)||y.ovr-x.ovr);
    sq.innerHTML=`<h2>${esc(cfg.club)} squad ${seasonLabel(cfg.start)}</h2><p class="sub" style="margin-top:-4px">Real squad of that season, rated by AI. Players in his position are highlighted.${cfg.ai.rivals?' '+esc(cfg.ai.rivals):''}</p>
    <div class="sqgrid">${rows.map(s=>`<div class="sq${s.me?' me':s.pos===cfg.p.pos?' riv':''}"><span class="ovr sm${s.me&&cfg.p.legend?' leg':''}">${s.ovr}</span><span class="grow">${esc(s.name)}</span><span class="sub">${s.pos}</span></div>`).join('')}</div>
    ${cfg.leagueOverride?`<h3>${esc(LEAGUE_BY_ID[cfg.league].name)} ${seasonLabel(cfg.start)} (real clubs)</h3><div class="lgl">${[...cfg.leagueOverride].sort((a,b)=>b.r-a.r).map(c=>`<span class="tag${c.name===cfg.club?' gold':''}">${esc(c.name)} ${Math.round(c.r)}</span>`).join('')}</div>`:''}`;sq.hidden=false}
  else sq.hidden=true;
  // player table
  $('#tP').innerHTML=`<table><thead><tr><th>Season</th><th>Age</th><th class="l">Club</th><th>OVR</th><th>Role</th><th>Apps</th><th>G</th><th>A</th>${def?'<th>CS</th>':''}<th>Rating</th><th>Value</th><th class="l">Honours & awards</th></tr></thead><tbody>${S.map(s=>s.playing?`<tr><td>${s.label}</td><td>${s.age}</td><td class="l">${clubCell(s)}</td><td>${Math.round(s.ovr)}</td><td>${s.role}</td><td>${s.apps}</td><td>${s.goals}</td><td>${s.assists}</td>${def?`<td>${s.cs}</td>`:''}<td>${s.rating.toFixed(2)}</td><td>${money(s.value)}</td><td class="l">${s.apps>=10?tags(s.trophies):tags(s.trophies.filter(t=>/World Cup|EURO|Copa|AFCON|Asian Cup|ASEAN|Gold Cup/.test(t)))+(s.trophies.some(t=>!/World Cup|EURO|Copa|AFCON|Asian Cup|ASEAN|Gold Cup/.test(t))?'<span class="tag">Club won trophies (barely played)</span>':'')}${tags(s.awards)}${s.bdo&&s.bdo>1?`<span class="tag">Ballon d’Or: ${ord(s.bdo)} place</span>`:''}${s.notes.map(n=>`<span class="tag bad">${esc(n)}</span>`).join('')}${s.move?`<span class="tag mv">➜ ${esc(s.move.type)}: ${esc(s.move.to)}${s.move.fee?' · '+money(s.move.fee):''}</span>`:''}</td></tr>`:`<tr class="dim"><td>${s.label}</td><td>${s.age}</td><td colspan="${def?10:9}" class="l">${s.notes.length?esc(s.notes.join(', ')):'Retired / no longer at the club'}</td></tr>`).join('')}</tbody><tfoot><tr><td>Total</td><td></td><td></td><td></td><td></td><td>${tot.apps}</td><td>${tot.g}</td><td>${tot.a}</td>${def?`<td>${tot.cs}</td>`:''}<td>${avgR.toFixed(2)}</td><td></td><td class="l">${ptroph.length} trophies</td></tr></tfoot></table>`;
  // intl
  $('#tI').innerHTML=`<p class="sub">${esc(natName(cfg.p.nat))} · team strength ${NATIONS[cfg.p.nat]?NATIONS[cfg.p.nat][1]:'?'} · ${esc(NATIONS[cfg.p.nat]?NATIONS[cfg.p.nat][2]:'')}</p><table><thead><tr><th>Season</th><th class="l">Status</th><th>Caps</th><th>Goals</th><th class="l">Tournament (summer)</th></tr></thead><tbody>${S.map(s=>{if(!s.playing||!s.intl)return `<tr class="dim"><td>${s.label}</td><td class="l" colspan="4">—</td></tr>`;const I=s.intl;return `<tr><td>${s.label}</td><td class="l">${esc(I.role)}${I.note?' · '+esc(I.note):''}</td><td>${I.caps}</td><td>${I.goals}</td><td class="l">${I.tourn.length?I.tourn.map(t=>`<div class="mini${t.won?' win':''}">${esc(t.name)}: <b>${esc(t.res)}</b>${t.games?` · ${t.goals} goal${t.goals===1?'':'s'}`:''}</div>`).join(''):'<span class="sub">No major tournament</span>'}</td></tr>`}).join('')}</tbody><tfoot><tr><td>Total</td><td></td><td>${tot.caps}</td><td>${tot.ig}</td><td></td></tr></tfoot></table>`;
  // charts
  const lab=S.map(s=>s.label.slice(2));
  $('#charts').innerHTML=`<h3>Overall rating</h3>${lineChart(P.map(s=>Math.round(s.ovr)),P.map(s=>s.label),{fmt:v=>'OVR '+v})}
   <h3>Goals per season (all comps)</h3>${barChart(P.map(s=>s.goals),P.map(s=>s.label),{fmt:v=>v+' goals'})}
   <h3>${esc(cfg.club)} league finish</h3>${lineChart(S.map(s=>s.club.pos),S.map(s=>s.label),{invert:true,min:1,max:leagueClubsFor(cfg.league,cfg.start).length,fmt:v=>ord(v)+' place'})}`+(hasM?`<h3>Manager win % per season (league)</h3>${barChart(S.filter(s=>s.mgr&&s.mgr.status==='Employed').map(s=>Math.round(s.mgr.W/Math.max(1,s.mgr.P)*100)),S.filter(s=>s.mgr&&s.mgr.status==='Employed').map(s=>s.label),{fmt:v=>v+'% wins'})}`:'');
  if(hasM)$('#mgrHead').innerHTML=`<div class="mgrline">📋 <b>${esc(cfg.m.name)}</b> (${esc(cfg.m.style)}, rating ${Math.round(cfg.m.ovr)}) takes over at <b>${esc(cfg.mClub)}</b>${cfg.mClub===cfg.club?' — same club as the player':''}.</div>`;
  renderDetail(cfg,res);
  setTab('p');
}
function renderClubTab(cfg,res){const S=res.seasons;const clubTroph=[];S.forEach(s=>clubTroph.push(...s.clubTrophies));
  // club table
  $('#tC').innerHTML=`<table><thead><tr><th>Season</th><th>Pos</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>Pts</th><th class="l">Domestic cups</th><th class="l">Continental</th><th class="l">Champions / notes</th></tr></thead><tbody>${S.map(s=>{const c=s.club;return `<tr><td>${s.label}</td><td><b class="${c.pos===1?'gold':''}">${ord(c.pos)}</b></td><td>${c.P}</td><td>${c.W}</td><td>${c.D}</td><td>${c.L}</td><td>${c.GF}</td><td>${c.GA}</td><td><b>${c.Pts}</b></td><td class="l">${ccell(s)}</td><td class="l">${c.cont?`<div class="mini${c.cont.res==='Winner'?' win':''}">${esc(c.cont.name)}: ${esc(c.cont.res)}</div>`:'<span class="sub">Not qualified</span>'}</td><td class="l">${(cfg.p?s.atHome:(s.mgr&&s.mgr.status==='Employed'&&s.mgr.club===cfg.club))?'':'<span class="tag">Without him</span> '}${c.pos===1?'<span class="tag gold">League champions</span>':'<span class="sub">'+esc(c.leader)+' won</span>'}${c.notes?` <span class="tag bad">${c.notes}</span>`:''}</td></tr>`}).join('')}</tbody></table>`;
  const cab={};clubTroph.forEach(t=>cab[t]=(cab[t]||0)+1);
  $('#cab').innerHTML=Object.keys(cab).length?Object.entries(cab).map(([k,v])=>`<span class="tag gold">🏆 ${esc(k)} ×${v}</span>`).join(''):'<span class="sub">No trophies in this run.</span>';
}
function renderOdds(cfg,a,n){
  const y=cfg.years,L=LEAGUE_BY_ID[cfg.league],slots=Math.max(1,L.slots[0]);
  const w=a.w,o=a.o,ns=n*y;
  const rows=[['Average league finish',ord(w.pos/ns),ord(o.pos/ns)],['League title (per season)',pct(w.titles/ns),pct(o.titles/ns)],[`Top-${slots} finish (per season)`,pct(w.top/ns),pct(o.top/ns)],['Continental title (per season)',pct(w.cont/ns),pct(o.cont/ns)],[`Club trophies over ${y} yrs (avg)`,(w.trophies/n).toFixed(1),(o.trophies/n).toFixed(1)]];
  const who=cfg.p&&cfg.m?'With them':'With him';
  $('#oddsBody').innerHTML=`<table class="odds"><thead><tr><th class="l">Club outcome</th><th>${who}</th><th>Without</th></tr></thead><tbody>${rows.map(r=>`<tr><td class="l">${r[0]}</td><td><b>${r[1]}</b></td><td>${r[2]}</td></tr>`).join('')}</tbody></table>
  ${cfg.m?`<table class="odds"><thead><tr><th class="l">Manager outcome</th><th>Average</th></tr></thead><tbody><tr><td class="l">Seasons he stays at ${esc(cfg.mClub)}</td><td><b>${(a.mStay/n).toFixed(1)}</b></td></tr><tr><td class="l">Times sacked over ${y} yrs</td><td><b>${(a.mSacked/n).toFixed(2)}</b></td></tr><tr><td class="l">League win rate</td><td><b>${a.mGames?Math.round(a.mWin/a.mGames*100):0}%</b></td></tr><tr><td class="l">Trophies over ${y} yrs</td><td><b>${(a.mTrophies/n).toFixed(1)}</b></td></tr></tbody></table>`:''}
  ${cfg.p?`<table class="odds"><thead><tr><th class="l">Player outcome</th><th>Average</th></tr></thead><tbody>
  <tr><td class="l">Seasons he stays at ${esc(cfg.club)}</td><td><b>${(a.stay/n).toFixed(1)}</b></td></tr><tr><td class="l">Transfers / loans in his career</td><td><b>${(a.moves/n).toFixed(1)}</b></td></tr>
  <tr><td class="l">Goals per season</td><td><b>${a.seasonsP?(a.goals/a.seasonsP).toFixed(1):0}</b></td></tr>
  <tr><td class="l">Assists per season</td><td><b>${a.seasonsP?(a.assists/a.seasonsP).toFixed(1):0}</b></td></tr>
  <tr><td class="l">Ballon d’Or wins over ${y} yrs</td><td><b>${(a.bdo/n).toFixed(2)}</b></td></tr>
  <tr><td class="l">Major international titles over ${y} yrs</td><td><b>${(a.intlMajor/n).toFixed(2)}</b></td></tr></tbody></table>`:''}
  <p class="sub">Based on ${n} simulated careers with the same settings — a steadier guide than any single run.</p>`;
  const dp=o.pos/ns-w.pos/ns,tw=w.titles/ns,to=o.titles/ns;
  const imp=dp>=3?'transforms':dp>=1.2?'clearly lifts':dp>=.4?'gives a modest boost to':'barely changes';
  $('#clubVerdict').innerHTML=`<b>${esc(cfg.club)}</b>: ${cfg.p&&cfg.m?(cfg.mClub===cfg.club?'the signing and the new manager together':'signing him'):cfg.p?'signing him':'appointing him'} ${imp} the team. Average finish <b>${ord(w.pos/ns)}</b> with him vs ${ord(o.pos/ns)} without; league-title chance per season ${pct(to)} → <b>${pct(tw)}</b>; club trophies over ${y} seasons ${(o.trophies/n).toFixed(1)} → <b>${(w.trophies/n).toFixed(1)}</b>.`+(cfg.p&&cfg.transfers&&a.stay/n<y-.5?` He stays only <b>${(a.stay/n).toFixed(1)} of ${y} seasons</b> on average before being sold or moving up, so the club mainly gains the transfer fee.`:'')+(!cfg.p&&a.mStay/n<y-.5?` The manager lasts <b>${(a.mStay/n).toFixed(1)} of ${y} seasons</b> on average before being sacked, poached or retiring.`:'');
}

// ---------- charts ----------
function frame(vals,labels,opt,draw){
  const W=600,H=190,pl=34,pr=24,pt=18,pb=26,n=vals.length;
  let mn=opt.min!=null?opt.min:Math.min(...vals),mx=opt.max!=null?opt.max:Math.max(...vals);
  if(opt.bar){mn=0;mx=Math.max(1,mx)}if(mx===mn){mx+=1;mn-=1}if(!opt.bar&&opt.min==null){mn=Math.floor(mn-1);mx=Math.ceil(mx+1)}
  const xs=i=>n===1?pl+(W-pl-pr)/2:pl+i*(W-pl-pr)/(n-1);
  const ys=v=>{let t=(v-mn)/(mx-mn);if(opt.invert)t=1-t;return H-pb-t*(H-pt-pb)};
  const ticks=[mn,Math.round((mn+mx)/2),mx];
  let g=ticks.map(t=>`<line x1="${pl}" x2="${W-pr}" y1="${ys(t)}" y2="${ys(t)}" class="grid"/><text x="${pl-6}" y="${ys(t)+4}" class="ax" text-anchor="end">${t}</text>`).join('');
  const step=Math.ceil(n/8);g+=labels.map((l,i)=>i%step===0||i===n-1?`<text x="${opt.bar?barX(i,n,W,pl,pr)+barW(n,W,pl,pr)/2:xs(i)}" y="${H-8}" class="ax" text-anchor="middle">${l.slice(2)}</text>`:'').join('');
  return `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img">${g}${draw(xs,ys,W,H,pl,pr,pb)}</svg></div>`;
}
const barW=(n,W,pl,pr)=>Math.min(48,(W-pl-pr)/n-6);
const barX=(i,n,W,pl,pr)=>pl+i*(W-pl-pr)/n+((W-pl-pr)/n-barW(n,W,pl,pr))/2;
function lineChart(vals,labels,opt={}){
  if(!vals.length)return '<p class="sub">No data.</p>';
  return frame(vals,labels,opt,(xs,ys)=>`<polyline points="${vals.map((v,i)=>xs(i)+','+ys(v)).join(' ')}" class="ln"/>${vals.map((v,i)=>`<circle cx="${xs(i)}" cy="${ys(v)}" r="5" class="dot"/><rect x="${xs(i)-18}" y="0" width="36" height="190" class="hit" data-tip="${esc(labels[i]+': '+opt.fmt(v))}"/>`).join('')}`);
}
function barChart(vals,labels,opt={}){
  if(!vals.length)return '<p class="sub">No data.</p>';
  return frame(vals,labels,{...opt,bar:true},(xs,ys,W,H,pl,pr,pb)=>vals.map((v,i)=>{const x=barX(i,vals.length,W,pl,pr),w=barW(vals.length,W,pl,pr),y=ys(v),h=H-pb-y;return (v>0?`<path d="M${x},${H-pb}V${y+Math.min(4,h)}q0,-4 4,-4h${w-8}q4,0 4,4V${H-pb}Z" class="bar"/>`:'')+`${vals.length<=10?`<text x="${x+w/2}" y="${y-5}" class="ax val" text-anchor="middle">${v}</text>`:''}<rect x="${x-3}" y="0" width="${w+6}" height="${H}" class="hit" data-tip="${esc(labels[i]+': '+opt.fmt(v))}"/>`}).join(''));
}
const tip=$('#tip');
document.addEventListener('pointerover',e=>{const h=e.target.closest&&e.target.closest('.hit');if(!h){tip.hidden=true;return}tip.textContent=h.dataset.tip;tip.hidden=false;const r=h.getBoundingClientRect();tip.style.left=(r.left+r.width/2+window.scrollX)+'px';tip.style.top=(r.top+window.scrollY+8)+'px'});

// tabs
function setTab(k){document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.dataset.t===k));document.querySelectorAll('.pane').forEach(p=>p.hidden=p.dataset.t!==k)}
$('#tabs').onclick=e=>{const t=e.target.closest('.tab');if(t)setTab(t.dataset.t)};

renderList();fillClubs();
selectPlayer(PLAYERS.find(p=>p.name==='Lamine Yamal'));
$('#league').value='EPL';fillClubs();$('#club').value='Arsenal';updateInfo();

// ---------- AI (Claude via the page's sample capability) ----------
function aiKey(){return sel?sel.id+'|'+$('#club').value+'|'+$('#season').value:''}
function roleBiasFor(role,d){
  if(role==='Starter')return d>=-3?0:-3-d;
  if(role==='Rotation')return d>=-3?-3.5-d:d<-8?-8-d+.5:0;
  if(role==='Bench')return d>=-8?-8.5-d:0;return 0;
}
(async()=>{
  if(!ENABLE_AI){document.querySelectorAll('.ai-only').forEach(e=>e.hidden=true);return}
  for(let i=0;i<50&&!(window.claude&&window.claude.use);i++)await new Promise(r=>setTimeout(r,100));
  try{if(window.claude&&window.claude.use)sample=await window.claude.use('sample')}catch(e){sample=null}
  document.querySelectorAll('.ai-only').forEach(e=>e.hidden=!sample);
  if(!sample)document.querySelectorAll('.ai-off').forEach(e=>e.hidden=false);
})();
function aiErr(e){
  if(e&&e.code==='not_granted'){sample=null;document.querySelectorAll('.ai-only').forEach(x=>x.hidden=true);return 'AI access was not allowed.'}
  if(e&&e.code==='rate_limited')return 'AI is busy right now — try again in a minute.';
  return 'AI could not answer'+(e&&e.message?' ('+e.message+')':'')+'.';
}
async function askJSON(prompt,tier){
  const full=prompt+'\n\nReply with ONLY one JSON object. No prose, no code fences.';
  if(typeof sample.json==='function'){
    try{const v=await sample.json(full,{modelTier:tier||'default'});if(v&&typeof v==='object')return v}
    catch(e){if(e&&(e.code==='not_granted'||e.code==='rate_limited'))throw e}
  }
  const r=await sample(full,{modelTier:tier||'default'});const m=(r.text||'').match(/\{[\s\S]*\}/);
  if(!m)throw{message:'no answer'};return JSON.parse(m[0]);
}
const SCALE='Rating scale 40-99, FIFA-like: Haaland ≈91, Mbappé ≈91, an average Premier League starter ≈78, a Championship starter ≈70, a top Malaysia Super League (JDT) starter ≈65, an average Malaysia Super League player ≈56.';

// AI scout: realistic level, role and fee for this exact transfer
async function aiCalibrate(cfg){
  const L=LEAGUE_BY_ID[cfg.league],p=cfg.p;
  const prompt=`You are a realistic football transfer analyst. Today's date is November 2026.
Hypothetical transfer: ${p.name} (${natName(p.nat)}, ${POS_NAME[p.pos]}, ${p.legend?'all-time legend, simulated at his prime ('+p.club+')':'currently at '+p.club}) joins ${cfg.club} (${L.name}, ${L.country}) for the ${seasonLabel(cfg.start)} season. Fantasy rule of this game: on transfer his age is reset to 18 and he plays at the level HE HAD (or will have) AT AGE 18 — not his prime. Judge his ability as the 18-year-old version of himself.
Our simple model estimates his age-18 rating at ${Math.round(p.ovr)} and potential ${Math.round(p.pot)} (his best-ever level). ${cfg.club}'s squad strength that season is ${Math.round(cfg.clubRating)}.
${SCALE}
Use your real knowledge of this player at 18 (his actual stats and level at that age; for young players, a realistic projection) and of ${cfg.club} (squad depth in his position, manager style, budget, ambition) to give realistic values for that season.
Also give the REAL ${cfg.club} squad of the ${seasonLabel(cfg.start)} season and the REAL clubs of the top division (${leagueNameFor(L,cfg.start)}) that season${cfg.start>=2026?' (for seasons after mid-2026 use the latest squad and league you know)':''}, rated on the same scale.
JSON fields: {"ovr":number,"pot":number,"expectedRole":"Starter"|"Rotation"|"Bench","plausibility":integer 0-100 (how likely this move could really happen: level, budget, wages, ambition, league),"feeEurM":number (realistic fee in EUR millions, 0 for a free or a legend),"reasoning":string (max 40 words, plain English),
"clubStrength":number (${cfg.club}'s overall squad strength that season),
"squad":[{"name":string,"pos":"GK"|"CB"|"FB"|"DM"|"CM"|"AM"|"W"|"ST","ovr":number}] (the 16-18 most important real players of ${cfg.club} that season, not including ${p.name}),
"rivals":string (max 25 words: who he competes with for his position),
"leagueClubs":[{"club":string,"strength":number}] (every club in the ${L.name} that season, real names, including ${cfg.club})}`;
  const a=await askJSON(prompt);
  const base=level18(sel).ovr;
  const ovr=clamp(+a.ovr||base,base-8,base+8),pot=Math.max(ovr,clamp(+a.pot||ovr,40,99));
  const okNum=x=>typeof x==='number'&&x>=35&&x<=99;
  const squad=Array.isArray(a.squad)?a.squad.filter(s=>s&&s.name&&okNum(+s.ovr)).slice(0,22).map(s=>({name:String(s.name),pos:POS_NAME[s.pos]?s.pos:'CM',ovr:Math.round(+s.ovr)})):[];
  let lc=Array.isArray(a.leagueClubs)?a.leagueClubs.filter(c=>c&&c.club&&okNum(+c.strength)).map(c=>({name:String(c.club),r:+c.strength})):[];
  const cs=okNum(+a.clubStrength)?clamp(+a.clubStrength,cfg.clubRating-10,cfg.clubRating+10):null;
  if(lc.length>=8&&lc.length<=24&&cs){const nn=norm(cfg.club);let ix=lc.findIndex(c=>norm(c.name)===nn);if(ix<0)ix=lc.findIndex(c=>norm(c.name).includes(nn)||nn.includes(norm(c.name)));
    if(ix>=0)lc.splice(ix,1);lc.push({name:cfg.club,r:cs});const seen=new Set();lc=lc.filter(c=>!seen.has(c.name)&&seen.add(c.name))}else lc=null;
  aiCache[aiKey()]={clubStrength:cs,squad,rivals:String(a.rivals||'').slice(0,200),leagueClubs:lc,ovr,pot,expectedRole:['Starter','Rotation','Bench'].includes(a.expectedRole)?a.expectedRole:'Rotation',plausibility:clamp(Math.round(+a.plausibility||0),0,100),feeEurM:Math.max(0,+a.feeEurM||0),reasoning:String(a.reasoning||'').slice(0,300)};
  $('#aiCalMsg').innerHTML='';
}

// AI player finder: any player, anywhere
$('#aiGo').onclick=async()=>{
  const q=($('#aiQ').value||$('#q').value).trim();if(!q){$('#aiQ').focus();return}
  if(!sample)return;$('#aiGo').disabled=true;$('#aiFindMsg').innerHTML='<span class="spin"></span> Searching…';
  const prompt=`You are a football player database. Today's date is November 2026. Identify the real professional footballer (active or retired) best matching this search: "${q}".
${SCALE}
JSON fields: {"found":boolean,"name":string,"nation":FIFA 3-letter code,"nationName":string,"nationStrength":number 50-90 (national team level; Spain ≈88, Japan ≈78, Malaysia ≈56),"confederation":"UEFA"|"CONMEBOL"|"CAF"|"AFC"|"CONCACAF"|"OFC","position":"GK"|"CB"|"FB"|"DM"|"CM"|"AM"|"W"|"ST","birthYear":number,"club":string (current club; for a retired player his best-known club and peak season, e.g. "Milan 2006/07"),"retired":boolean,"primeAge":number,"ovr":number (current level; for a retired player his prime level),"pot":number,"note":string (one short sentence; say clearly if unsure)}. If nobody matches, found=false.`;
  try{
    const a=await askJSON(prompt);
    if(!a.found||!a.name){$('#aiFindMsg').innerHTML='<span class="warn">AI couldn’t find that player. Try the full name.</span>';return}
    const nat=String(a.nation||'XXX').toUpperCase().slice(0,3);
    if(!NATIONS[nat])NATIONS[nat]=[a.nationName||nat,clamp(+a.nationStrength||65,45,90),['UEFA','CONMEBOL','CAF','AFC','CONCACAF','OFC'].includes(a.confederation)?a.confederation:'UEFA'];
    const pos=POS_NAME[a.position]?a.position:'CM',ovr=clamp(Math.round(+a.ovr||70),40,99),pot=Math.max(ovr,clamp(Math.round(+a.pot||ovr),40,99));
    const p=a.retired?{id:'a'+(customN++),name:a.name,nat,pos,primeAge:clamp(+a.primeAge||27,18,36),club:a.club||'',league:'',ovr,pot:ovr,legend:true,ai:true}
      :{id:'a'+(customN++),name:a.name,nat,pos,birth:clamp(+a.birthYear||2000,1975,2012),club:a.club||'Unknown',league:CLUB_LEAGUE[a.club]||'',ovr,pot,legend:false,ai:true};
    p._s=norm(p.name+' '+p.club+' '+natName(p.nat));PLAYERS.push(p);
    $('#q').value='';filt='ALL';document.querySelectorAll('#chips .chip').forEach(c=>c.classList.toggle('on',c.dataset.f==='ALL'));renderList();selectPlayer(p);
    $('#aiFindMsg').innerHTML=`Added <b>${esc(p.name)}</b> (AI estimate).${a.note?' '+esc(a.note):''}`;
  }catch(e){$('#aiFindMsg').innerHTML='<span class="warn">'+esc(aiErr(e))+'</span>'}
  finally{$('#aiGo').disabled=false}
};
$('#aiQ').onkeydown=e=>{if(e.key==='Enter')$('#aiGo').click()};

// AI pundit: reviews the simulated career for realism and tells the story
$('#punditGo').onclick=async()=>{
  if(!sample||!lastRun)return;const {cfg,res}=lastRun,L=LEAGUE_BY_ID[cfg.league];
  $('#punditGo').disabled=true;$('#pundit').innerHTML='<p class="sub"><span class="spin"></span> The pundit is watching the tapes…</p>';
  const rows=res.seasons.map(s=>{const c=s.club;let t=`${s.label}: `;
    if(s.mgr){const g=s.mgr;t+=g.status==='Employed'?`MANAGER ${cfg.m.name} at ${g.club} (${g.league}): expected ${ord(g.exp)}, finished ${ord(g.pos)}, ${g.W}-${g.D}-${g.L}, GF ${g.GF} GA ${g.GA}, trophies: ${g.trophies.join(', ')||'none'}${g.notes.length?', '+g.notes.join(', '):''}; `:`MANAGER ${g.status}; `}
    if(!cfg.p){t+=`club ${cfg.club} ${ord(c.pos)} with ${c.Pts} pts`;return t}
    t+=`player age ${s.age}; `;
    t+=s.playing?`plays for ${s.pclub.name}${s.pclub.loan?' (on loan)':''} (${s.pclub.league}, finished ${ord(s.pclub.pos)}), OVR ${Math.round(s.ovr)}, ${s.role}, ${s.apps} apps, ${s.goals}G ${s.assists}A, avg rating ${s.rating.toFixed(2)}; awards: ${s.awards.join(', ')||'none'}${s.bdo>1?`; Ballon d'Or ${ord(s.bdo)}`:''}; `:'not playing (retired/released); ';
    t+=`${s.move?'SUMMER MOVE: '+s.move.type+' to '+s.move.to+(s.move.fee?' for €'+Math.round(s.move.fee)+'m':'')+' ('+s.move.reason+'); ':''}original club ${cfg.club} ${ord(c.pos)} with ${c.Pts} pts, cups: ${c.cups.map(x=>x.name+' '+x.res).join(', ')}, continental: ${c.cont?c.cont.name+' '+c.cont.res:'none'}; trophies: ${s.trophies.join(', ')||'none'}`;
    if(s.det){const d=s.det;t+=`detail: ${d.minutes} min, xG ${d.xg.toFixed(1)}, ${d.shots} shots (${d.sot} on target), xA ${d.xa.toFixed(1)}, ${d.kp} key passes, pass acc ${d.passAtt?Math.round(d.passCmp/d.passAtt*100):0}%, ${d.tklWon} tackles won, ${d.int} interceptions, ${d.aerWon}/${d.aerAtt} aerials${d.saves!=null?`, ${d.saves} saves`:''}; `}
    if(s.intl)t+=`; international: ${s.intl.role}, ${s.intl.caps} caps ${s.intl.goals} goals${s.intl.tourn.length?', '+s.intl.tourn.map(x=>x.name+' '+x.res).join(', '):''}`;return t}).join('\n');
  const mc=lastAgg?`Across ${lastAgg.n} simulations: club average finish ${ord(lastAgg.a.w.pos/(lastAgg.n*cfg.years))} with him vs ${ord(lastAgg.a.o.pos/(lastAgg.n*cfg.years))} without.`:'';
  const prompt=`You are an expert football pundit and a strict realism auditor. Today's date is November 2026.
This is ONE simulated "what if" career from a game model:
${cfg.m?`Manager ${cfg.m.name} (${natName(cfg.m.nat)}, ${cfg.m.style} style, manager rating ${Math.round(cfg.m.ovr)}${cfg.m.legend?', legend at his peak':''}) takes over ${cfg.mClub} in ${seasonLabel(cfg.start)}.\n`:''}${!cfg.p?'':`${cfg.p.name} (${natName(cfg.p.nat)}, ${POS_NAME[cfg.p.pos]}, age reset to 18 by the game's fantasy rule, starting at his age-18 level, rating ${Math.round(cfg.p.ovr)}${cfg.p.legend?', all-time legend':', from '+cfg.p.club}) joins ${cfg.club} (${L.name}) in ${seasonLabel(cfg.start)}.`}
${SCALE}
${rows}
${mc}
Accept the age-18 reset as a given rule (do not flag it). ${cfg.ai&&cfg.ai.leagueClubs?'The league and club strengths come from the real '+seasonLabel(cfg.start)+' season. ':''}Judge everything else against real football: are the goal tallies, the transfers (timing, destination, fees), minutes, awards (especially Ballon d'Or and Player of the Season), club finishes and international results believable for a player of this level, at this club, in this league? Then tell the story.
JSON fields: {"headline":string (newspaper style, max 12 words),"realism":integer 0-100,"story":string (120-170 words, vivid but grounded),"playerImpact":string (max 45 words; about the player, or about the manager if there is no player),"clubImpact":string (max 45 words),"international":string (max 35 words; the player's international story, or the manager's reputation if there is no player),"flags":[{"season":string,"issue":string,"realistic":string}] (0-5 items: anything unrealistic, and what would more likely happen)}`;
  try{
    const a=await askJSON(prompt,'default');const sc=clamp(Math.round(+a.realism||0),0,100);
    $('#pundit').innerHTML=`<div class="pund"><div class="ph">${esc(a.headline||'')}</div>
     <div class="meter"><span>Realism score</span><div class="bar2"><i style="width:${sc}%"></i></div><b>${sc}/100</b></div>
     <p>${esc(a.story||'')}</p>
     <h3>Player</h3><p>${esc(a.playerImpact||'')}</p><h3>Club</h3><p>${esc(a.clubImpact||'')}</p><h3>International</h3><p>${esc(a.international||'')}</p>
     ${Array.isArray(a.flags)&&a.flags.length?`<h3>Reality check</h3>${a.flags.slice(0,5).map(f=>`<div class="flag"><b>${esc(f.season||'')}</b> ${esc(f.issue||'')}<div class="sub">More likely: ${esc(f.realistic||'')}</div></div>`).join('')}`:'<p class="sub">No unrealistic moments flagged.</p>'}
     <p class="sub">Written by AI from the simulation above. It can make mistakes.</p></div>`;
  }catch(e){$('#pundit').innerHTML='<p class="warn">'+esc(aiErr(e))+'</p>'}
  finally{$('#punditGo').disabled=false}
};
$('#aiCal').onchange=updateInfo;
$('#trf').onchange=updateInfo;

// ---------- detailed stats ----------
let detMode='tot',detCache=null;
const pc=(a,b)=>b?a/b*100:null;
const G_ATT=['Attacking',[['Goals',(d,s)=>s.goals,'n'],['Expected goals (xG)',d=>d.xg,'x'],['Shots',d=>d.shots,'n'],['Shots on target',d=>d.sot,'n'],['Shot accuracy',d=>pc(d.sot,d.shots),'p'],['Conversion rate',(d,s)=>pc(s.goals,d.shots),'p'],['Big chances missed',d=>d.bcm,'n'],['Penalties scored / taken',d=>d.penS+' / '+d.penT,'r'],['Headed goals',d=>d.head,'n'],['Goals from outside the box',d=>d.outG,'n'],['Hat-tricks',d=>d.hat,'r'],['Touches in opposition box',d=>d.box,'n'],['Offsides',d=>d.off,'n']]];
const G_CRE=['Creativity',[['Assists',(d,s)=>s.assists,'n'],['Expected assists (xA)',d=>d.xa,'x'],['Key passes',d=>d.kp,'n'],['Big chances created',d=>d.bcc,'n'],['Dribbles completed',d=>d.drbCmp,'n'],['Dribble success',d=>pc(d.drbCmp,d.drbAtt),'p'],['Accurate crosses',d=>d.crsCmp,'n'],['Cross accuracy',d=>pc(d.crsCmp,d.crsAtt),'p']]];
const G_PAS=['Passing',[['Passes completed',d=>d.passCmp,'n'],['Pass accuracy',d=>pc(d.passCmp,d.passAtt),'p'],['Progressive passes',d=>d.prog,'n'],['Accurate long balls',d=>d.longCmp,'n'],['Long ball accuracy',d=>pc(d.longCmp,d.longAtt),'p']]];
const G_DEF=['Defending',[['Tackles won',d=>d.tklWon,'n'],['Tackle success',d=>pc(d.tklWon,d.tklAtt),'p'],['Interceptions',d=>d.int,'n'],['Clearances',d=>d.clr,'n'],['Blocked shots',d=>d.blk,'n'],['Ball recoveries',d=>d.rec,'n'],['Dribbled past',d=>d.past,'n'],['Errors leading to goal',d=>d.err,'r'],['Own goals',d=>d.og,'r']]];
const G_DUE=['Duels',[['Duels won',d=>d.duelWon,'n'],['Duels won %',d=>pc(d.duelWon,d.duelAtt),'p'],['Aerial duels won',d=>d.aerWon,'n'],['Aerial win %',d=>pc(d.aerWon,d.aerAtt),'p']]];
const G_TEAM=['With him on the pitch',[['Clean sheets',d=>d.cs,'r'],['Goals conceded',d=>d.gaOn,'n']]];
const G_GK=['Goalkeeping',[['Clean sheets',d=>d.cs,'r'],['Goals conceded',d=>d.gaOn,'n'],['Saves',d=>d.saves,'n'],['Save %',d=>pc(d.saves,d.sotFaced),'p'],['Shots on target faced',d=>d.sotFaced,'n'],['Penalties saved / faced',d=>d.penSaved+' / '+d.penFaced,'r'],['Goals prevented (vs xG)',d=>d.xgPrev,'x'],['High claims',d=>d.claims,'n'],['Sweeper actions',d=>d.sweep,'n'],['Errors leading to goal',d=>d.err,'r']]];
const G_DIS=['Distribution',[['Passes completed',d=>d.passCmp,'n'],['Pass accuracy',d=>pc(d.passCmp,d.passAtt),'p'],['Accurate long balls',d=>d.longCmp,'n'],['Long ball accuracy',d=>pc(d.longCmp,d.longAtt),'p']]];
const G_PHY=['Physical & discipline',[['Minutes',d=>d.minutes,'r'],['Starts / sub apps',d=>d.starts+' / '+d.subs,'r'],['Man of the Match',d=>d.motm,'r'],['Distance per 90 (km)',d=>d.n90?d.km/d.n90:null,'a'],['Total distance (km)',d=>d.km,'n'],['Fouls committed',d=>d.fouls,'n'],['Fouls won',d=>d.fouled,'n'],['Yellow cards',d=>d.yc,'r'],['Red cards',d=>d.rc,'r']]];
function groupsFor(pos){
  if(pos==='GK')return[G_GK,G_DIS,G_PHY];
  if(pos==='CB')return[G_DEF,G_DUE,G_TEAM,G_PAS,G_ATT,G_PHY];
  if(pos==='FB')return[G_DEF,G_DUE,G_CRE,G_PAS,G_TEAM,G_ATT,G_PHY];
  if(pos==='DM')return[G_DEF,G_PAS,G_DUE,G_CRE,G_ATT,G_PHY];
  if(pos==='CM'||pos==='AM')return[G_PAS,G_CRE,G_ATT,G_DEF,G_DUE,G_PHY];
  return[G_ATT,G_CRE,G_PAS,G_DUE,G_DEF,G_PHY];
}
const HL={GK:[['Save %',G_GK[1][3][1],'p'],['Clean sheets',G_GK[1][0][1],'r'],['Goals prevented',G_GK[1][6][1],'x'],['Pass accuracy',G_DIS[1][1][1],'p']],
 CB:[['Tackles won',G_DEF[1][0][1],'n'],['Interceptions',G_DEF[1][2][1],'n'],['Aerial win %',G_DUE[1][3][1],'p'],['Clearances',G_DEF[1][3][1],'n']],
 FB:[['Tackles won',G_DEF[1][0][1],'n'],['Key passes',G_CRE[1][2][1],'n'],['Accurate crosses',G_CRE[1][6][1],'n'],['Duels won %',G_DUE[1][1][1],'p']],
 DM:[['Tackles won',G_DEF[1][0][1],'n'],['Interceptions',G_DEF[1][2][1],'n'],['Pass accuracy',G_PAS[1][1][1],'p'],['Progressive passes',G_PAS[1][2][1],'n']],
 CM:[['Pass accuracy',G_PAS[1][1][1],'p'],['Progressive passes',G_PAS[1][2][1],'n'],['Key passes',G_CRE[1][2][1],'n'],['Ball recoveries',G_DEF[1][5][1],'n']],
 AM:[['Key passes',G_CRE[1][2][1],'n'],['xA',G_CRE[1][1][1],'x'],['Big chances created',G_CRE[1][3][1],'n'],['Dribbles completed',G_CRE[1][4][1],'n']],
 W:[['Dribbles completed',G_CRE[1][4][1],'n'],['xG',G_ATT[1][1][1],'x'],['Key passes',G_CRE[1][2][1],'n'],['Conversion rate',G_ATT[1][5][1],'p']],
 ST:[['xG',G_ATT[1][1][1],'x'],['Shots on target',G_ATT[1][3][1],'n'],['Conversion rate',G_ATT[1][5][1],'p'],['Aerial duels won',G_DUE[1][2][1],'n']]};
function fmtStat(v,kind,d){
  if(v==null||v===''||(typeof v==='number'&&isNaN(v)))return '–';
  if(typeof v==='string')return v;
  if(detMode==='p90'&&(kind==='n'||kind==='x'))return d.n90>=1?(v/d.n90).toFixed(2):'–';
  if(kind==='p')return v.toFixed(1)+'%';if(kind==='x'||kind==='a')return v.toFixed(1);return Math.round(v).toLocaleString();
}
function sumDet(list){const t={};list.forEach(({d,s})=>{for(const k in d)if(typeof d[k]==='number')t[k]=(t[k]||0)+d[k]});
  return{d:t,s:{goals:list.reduce((a,x)=>a+x.s.goals,0),assists:list.reduce((a,x)=>a+x.s.assists,0)}}}
function renderDetail(cfg,res){detCache={cfg,res};drawDetail()}
function drawDetail(){
  if(!detCache)return;const {cfg,res}=detCache,pos=cfg.p.pos;
  const cols=res.seasons.filter(s=>s.playing&&s.det).map(s=>({lab:s.label.slice(2),d:s.det,s,club:s.pclub.name}));
  if(!cols.length){$('#tD').innerHTML='<p class="sub">No seasons played.</p>';$('#detHL').innerHTML='';return}
  const car=sumDet(cols);
  $('#detHL').innerHTML=`<p class="sub" style="margin:0 0 6px">${esc(POS_NAME[pos])} profile — career${detMode==='p90'?' per 90 minutes':' totals'}</p><div class="tiles">${HL[pos].map(([l,f,k])=>`<div class="tile"><b>${fmtStat(f(car.d,car.s),k,car.d)}</b><span>${l}</span></div>`).join('')}</div>`;
  let h=`<table class="det"><thead><tr><th>Stat</th>${cols.map(c=>`<th title="${esc(c.club)}">${c.lab}</th>`).join('')}<th>Career</th></tr></thead><tbody>`;
  for(const [g,rows] of groupsFor(pos)){
    h+=`<tr class="grp"><td colspan="${cols.length+2}">${g}</td></tr>`;
    for(const [l,f,k] of rows)h+=`<tr><td>${l}</td>${cols.map(c=>`<td>${fmtStat(f(c.d,c.s),k,c.d)}</td>`).join('')}<td><b>${fmtStat(f(car.d,car.s),k,car.d)}</b></td></tr>`;
  }
  $('#tD').innerHTML=h+'</tbody></table>';
}
$('#detMode').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;detMode=b.dataset.m;document.querySelectorAll('#detMode .chip').forEach(c=>c.classList.toggle('on',c===b));drawDetail()};

// ---------- managers: picker, info, results ----------
const crest=n=>esc(n.split(/\s+/).filter(w=>/^[A-Z0-9]/.test(w)).map(w=>w[0]).join('').slice(0,3)||n[0]);
const youthTxt=y=>y>=.75?'Excellent':y>=.55?'Good':'Average';
MANAGERS.forEach(m=>m._s=norm(m.name+' '+m.club+' '+natName(m.nat)+' '+m.style));
$('#mchips').innerHTML=[['ALL','All managers'],['MLEG','⭐ Legends'],['MCUR','Current']].map(([k,v])=>`<button class="chip${k==='ALL'?' on':''}" data-f="${k}">${v}</button>`).join('');
$('#mchips').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;mfilt=b.dataset.f;document.querySelectorAll('#mchips .chip').forEach(c=>c.classList.toggle('on',c===b));renderMList()};
$('#mq').oninput=renderMList;
function mSub(m){return `${esc(m.style)} · ${esc(natName(m.nat))} · ${m.legend?'Peak: ':'Known for '}${esc(m.club)}`}
function renderMList(){
  const q=norm($('#mq').value.trim()),ws=q?q.split(/\s+/):[];
  const arr=MANAGERS.filter(m=>(mfilt!=='MLEG'||m.legend)&&(mfilt!=='MCUR'||!m.legend)&&ws.every(w=>m._s.includes(w))).sort((a,b)=>b.ovr-a.ovr);
  $('#mlist').innerHTML=arr.map(m=>`<div class="row${msel&&msel.id===m.id?' sel':''}" data-id="${m.id}"><div class="ovr mgr${m.legend?' leg':''}">${m.ovr}</div><div class="grow"><div class="nm">${esc(m.name)}</div><div class="sub">${mSub(m)}</div></div></div>`).join('')||'<div class="empty">No manager found.</div>';
}
$('#mlist').onclick=e=>{const r=e.target.closest('.row');if(!r)return;msel=MANAGERS.find(m=>m.id===r.dataset.id);
  document.querySelectorAll('#mlist .row').forEach(x=>x.classList.toggle('sel',x.dataset.id===msel.id));
  $('#mpicked').innerHTML=`<div class="ovr mgr${msel.legend?' leg':''}">${msel.ovr}</div><div class="grow"><div class="nm">📋 ${esc(msel.name)}${msel.legend?' <span class="tag gold">Legend</span>':''}</div><div class="sub">${mSub(msel)} · youth development: ${youthTxt(msel.youth)}</div></div>`;$('#mpicked').hidden=false;updateInfo()};
$('#modeSel').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;mode=b.dataset.mode;
  document.querySelectorAll('#modeSel .chip').forEach(c=>c.classList.toggle('on',c===b));
  $('#pSec').hidden=mode==='m';$('#mSec').hidden=mode==='p';$('#mDest').hidden=mode!=='b';
  $('#destTitle').textContent=mode==='m'?"Manager's new club & season":mode==='b'?'Destination club & season':'Destination club & season';
  document.querySelectorAll('.aitog.ai-only').forEach(x=>x.hidden=!sample||mode==='m');updateInfo()};
$('#mLeague').innerHTML=LEAGUES.map(l=>`<option value="${l.id}">${esc(l.name)} (${esc(l.country)})</option>`).join('');
function fillMClubs(){const lid=$('#mLeague').value,y=+$('#season').value,prev=$('#mClub').value;const cl=leagueClubsFor(lid,y);
  $('#mClub').innerHTML=cl.length?[...cl].sort((a,b)=>b.r-a.r).map(c=>`<option value="${esc(c.name)}">${esc(c.name)} · ${Math.round(c.r)}</option>`).join(''):'<option value="">— league did not exist yet —</option>';
  if(cl.some(c=>c.name===prev))$('#mClub').value=prev}
$('#mLeague').onchange=()=>{fillMClubs();updateInfo()};$('#mClub').onchange=updateInfo;
$('#mDiff').onchange=()=>{$('#mDestSel').hidden=!$('#mDiff').checked;fillMClubs();updateInfo()};
$('#season').addEventListener('change',fillMClubs);
renderMList();fillMClubs();

function mgrInfo(cfg){const m=cfg.m,b=mgrBonus(m,cfg.mClubRating);
  return `<div class="kpis mk"><div><span>Manager</span><b>${esc(m.name)}</b></div><div><span>Rating</span><b>${Math.round(m.ovr)}</b></div><div><span>Style</span><b>${esc(m.style)}</b></div>
  <div><span>Age then</span><b>${m.age}</b></div><div><span>${esc(cfg.mClub)}</span><b>${Math.round(cfg.mClubRating)} → ${(cfg.mClubRating+b).toFixed(1)}</b></div><div><span>Youth development</span><b>${youthTxt(m.youth)}</b></div></div>
  <div class="sub" style="margin-top:6px">📋 ${esc(MSTYLE_TXT[m.style]||'')}. ${b>=1.5?'A big upgrade for this club.':b>=.3?'A small upgrade for this club.':b>-.5?'About the level this club expects.':'Below this club’s level — the job may be too big for him.'}${cfg.p&&cfg.mClub===cfg.club&&m.youth>=.6?' He trusts young players, so the 18-year-old gets more minutes and develops faster.':''}</div>`}
function renderMgrOnlyHeader(cfg){const m=cfg.m,L=LEAGUE_BY_ID[cfg.league],b=mgrBonus(m,cfg.mClubRating);
  $('#xfer').innerHTML=`<div class="side"><div class="ovr big mgr${m.legend?' leg':''}">${Math.round(m.ovr)}</div><div><div class="nm">${esc(m.name)}</div><div class="sub">Manager · ${esc(natName(m.nat))} · age ${m.age}</div><div class="sub">${m.legend?'Peak: ':'Known for '}${esc(m.club)}</div></div></div>
   <div class="arrow">→</div><div class="side"><div class="crest">${crest(cfg.club)}</div><div><div class="nm">${esc(cfg.club)}</div><div class="sub">${esc(leagueNameFor(L,cfg.start))}</div><div class="sub">Takes charge for <b>${seasonLabel(cfg.start)}</b> · ${cfg.years} season${cfg.years>1?'s':''} simulated</div></div></div>`;
  $('#xferK').innerHTML=`<div><span>Style</span><b>${esc(m.style)}</b></div><div><span>Club strength</span><b>${Math.round(cfg.mClubRating)} → ${(cfg.mClubRating+b).toFixed(1)}</b></div><div><span>Youth development</span><b>${youthTxt(m.youth)}</b></div><div><span>Sim #</span><b>${lastSeed%100000}</b></div>`}

const sgn=v=>(v>0?'+':'')+v;
const MROWS=[ // [label, value(g), career(T)]
 ['League games',g=>g.P,T=>T.P],['Wins',g=>g.W,T=>T.W],['Draws',g=>g.D,T=>T.D],['Losses',g=>g.L,T=>T.L],
 ['Win %',g=>pc(g.W,g.P),T=>pc(T.W,T.P),'p'],['Points',g=>g.Pts,T=>T.Pts],['Points per game',g=>g.P?(g.Pts/g.P).toFixed(2):'–',T=>T.P?(T.Pts/T.P).toFixed(2):'–'],
 ['Home record (W-D-L)',g=>`${g.HW}-${g.HD}-${g.HL}`,T=>`${T.HW}-${T.HD}-${T.HL}`],['Away record (W-D-L)',g=>`${g.AW}-${g.AD}-${g.AL}`,T=>`${T.AW}-${T.AD}-${T.AL}`],
 ['Home win %',g=>pc(g.HW,g.HW+g.HD+g.HL),T=>pc(T.HW,T.HW+T.HD+T.HL),'p'],['Away win %',g=>pc(g.AW,g.AW+g.AD+g.AL),T=>pc(T.AW,T.AW+T.AD+T.AL),'p'],
 ['Goals scored',g=>g.GF,T=>T.GF],['Goals conceded',g=>g.GA,T=>T.GA],['Goal difference',g=>sgn(g.GF-g.GA),T=>sgn(T.GF-T.GA)],
 ['Goals scored per game',g=>g.P?(g.GF/g.P).toFixed(2):'–',T=>T.P?(T.GF/T.P).toFixed(2):'–'],['Goals conceded per game',g=>g.P?(g.GA/g.P).toFixed(2):'–',T=>T.P?(T.GA/T.P).toFixed(2):'–'],
 ['Clean sheets',g=>g.CS,T=>T.CS],['Clean sheet %',g=>pc(g.CS,g.P),T=>pc(T.CS,T.P),'p'],['Failed to score',g=>g.FTS,T=>T.FTS],
 ['Biggest win',g=>g.bigW?`${g.bigW.s} ${g.bigW.h?'vs':'at'} ${g.bigW.opp}`:'–',T=>T.bigW?`${T.bigW.s} ${T.bigW.h?'vs':'at'} ${T.bigW.opp}`:'–'],
 ['Heaviest defeat',g=>g.bigL?`${g.bigL.s} ${g.bigL.h?'vs':'at'} ${g.bigL.opp}`:'–',T=>T.bigL?`${T.bigL.s} ${T.bigL.h?'vs':'at'} ${T.bigL.opp}`:'–'],
 ['Expected finish',g=>ord(g.exp),T=>'avg '+T.exp.toFixed(1)],['Actual finish',g=>ord(g.pos),T=>'avg '+T.pos.toFixed(1)],
 ['Places above expectation',g=>sgn(g.exp-g.pos),T=>sgn(+(T.exp-T.pos).toFixed(1))],['Squad strength',g=>Math.round(g.base),T=>T.base.toFixed(1)],
 ['Tactical boost',g=>sgn(+g.bonus.toFixed(1)),T=>sgn(+T.bonus.toFixed(1))],['Manager rating',g=>Math.round(g.ovr),T=>Math.round(T.ovr)]];
function marg(b){if(!b)return -1;const [x,y]=b.s.split('-').map(Number);return Math.abs(x-y)*100+Math.max(x,y)}
function renderManager(cfg,res){
  const m=cfg.m,S=res.seasons,E=S.filter(s=>s.mgr&&s.mgr.status==='Employed'),G=E.map(s=>s.mgr);
  const T={};['P','W','D','L','GF','GA','CS','Pts','HW','HD','HL','AW','AD','AL','FTS'].forEach(k=>T[k]=G.reduce((a,g)=>a+g[k],0));
  const avg=k=>G.length?G.reduce((a,g)=>a+g[k],0)/G.length:0;T.exp=avg('exp');T.pos=avg('pos');T.base=avg('base');T.bonus=avg('bonus');T.ovr=G.length?G[G.length-1].ovr:m.ovr;
  T.bigW=G.reduce((b,g)=>marg(g.bigW)>marg(b)?g.bigW:b,null);T.bigL=G.reduce((b,g)=>marg(g.bigL)>marg(b)?g.bigL:b,null);
  const troph=[];G.forEach(g=>troph.push(...g.trophies));const titles=G.filter(g=>g.pos===1).length;
  const awards=[];G.forEach(g=>awards.push(...g.awards));const motm=awards.filter(a=>a==='Manager of the Season').length,woty=awards.filter(a=>a==='World Coach of the Year').length;
  const sacked=res.mmoves.filter(x=>x.type==='Sacked').length,clubs=[...new Set(G.map(g=>g.club))];
  // tiles + verdict
  const tiles=[['League games',T.P],['Win %',T.P?Math.round(T.W/T.P*100)+'%':'–'],['Points / game',T.P?(T.Pts/T.P).toFixed(2):'–'],['Trophies',troph.length],['League titles',titles],['Manager of the Season',motm],['Times sacked',sacked],['Clubs managed',clubs.length]];
  const perf=T.exp-T.pos,first=G[0];
  const pathK=[];S.forEach(s=>{if(!s.mgr)return;const k=s.mgr.status==='Employed'?s.mgr.club:s.mgr.status;const last=pathK[pathK.length-1];if(last&&last.k===k)last.n++;else pathK.push({k,n:1,lg:s.mgr.league||'',emp:s.mgr.status==='Employed'})});
  const mv=res.mmoves;
  $('#mgrVerdict').innerHTML=`<b>${esc(m.name)}</b> (${esc(m.style)} — ${esc(MSTYLE_TXT[m.style]||'')}) ${first?`takes charge of ${esc(first.club)}`:'never gets going'}. In ${G.length} season${G.length===1?'':'s'} in work he wins <b>${T.W} of ${T.P} league games (${T.P?Math.round(T.W/T.P*100):0}%)</b> and <b>${troph.length} troph${troph.length===1?'y':'ies'}</b>${titles?`, including ${titles} league title${titles>1?'s':''}`:''}. His teams finish on average <b>${Math.abs(perf).toFixed(1)} places ${perf>=0?'above':'below'}</b> what their squads should achieve.${sacked?` He is sacked ${sacked} time${sacked>1?'s':''}.`:''}${woty?` ${woty}× World Coach of the Year.`:''}${pathK.length>1?` Path: ${pathK.map(t=>t.k).join(' → ')}.`:''}`;
  const seasonRows=S.map(s=>{const g=s.mgr;if(!g)return '';if(g.status!=='Employed')return `<tr class="dim"><td>${s.label}</td><td>${g.age}</td><td class="l" colspan="15">${esc(g.status)}</td></tr>`;
    const d=g.exp-g.pos;return `<tr><td>${s.label}</td><td>${g.age}</td><td class="l">${esc(g.club)}<div class="sub">${esc(g.league)}</div></td><td>${ord(g.exp)} → <b class="${g.pos===1?'gold':''}">${ord(g.pos)}</b> <span class="${d>0?'ok':d<0?'bad':''}">(${sgn(d)})</span></td><td>${g.P}</td><td>${g.W}</td><td>${g.D}</td><td>${g.L}</td><td>${Math.round(g.W/Math.max(1,g.P)*100)}%</td><td>${(g.Pts/Math.max(1,g.P)).toFixed(2)}</td><td>${g.GF}</td><td>${g.GA}</td><td>${g.CS}</td>
    <td class="l">${g.cups.map(c=>`<div class="mini${c.res==='Winner'?' win':''}">${esc(c.name)}: ${esc(c.res)}</div>`).join('')}</td><td class="l">${g.cont?`<div class="mini${g.cont.res==='Winner'?' win':''}">${esc(g.cont.name)}: ${esc(g.cont.res)}</div>`:'<span class="sub">—</span>'}</td>
    <td class="l">${tags(g.trophies)}${tags(g.awards)}${g.withPlayer&&cfg.p?`<span class="tag">with ${esc(cfg.p.name.split(' (')[0])}</span>`:''}${g.notes.map(n=>`<span class="tag ${/Sacked|Relegation/.test(n)?'bad':'mv'}">${esc(n)}</span>`).join('')}</td></tr>`}).join('');
  const cols=E.map(s=>({lab:s.label.slice(2),g:s.mgr}));
  let det=`<table class="det"><thead><tr><th>Stat</th>${cols.map(c=>`<th title="${esc(c.g.club)}">${c.lab}</th>`).join('')}<th>Career</th></tr></thead><tbody>`;
  for(const [l,f,fc,k] of MROWS){const fm=v=>v==null?'–':k==='p'?(v==null?'–':v.toFixed(1)+'%'):v;det+=`<tr><td>${l}</td>${cols.map(c=>`<td>${fm(f(c.g))}</td>`).join('')}<td><b>${fm(fc(T))}</b></td></tr>`}
  det+='</tbody></table>';
  const byClub={};G.forEach(g=>{const b=byClub[g.club]||(byClub[g.club]={n:0,P:0,W:0,D:0,L:0,Pts:0,tr:0,best:99});b.n++;b.P+=g.P;b.W+=g.W;b.D+=g.D;b.L+=g.L;b.Pts+=g.Pts;b.tr+=g.trophies.length;b.best=Math.min(b.best,g.pos)});
  const cab={};troph.forEach(t=>cab[t]=(cab[t]||0)+1);
  $('#tM').innerHTML=`<div class="tiles">${tiles.map(([k,v])=>`<div class="tile"><b>${v}</b><span>${k}</span></div>`).join('')}</div>
   <h3>Managerial path</h3><div class="path">${pathK.map(t=>`<div class="stint${t.emp?'':' off'}"><b>${esc(t.k)}</b><span>${t.emp?esc(t.lg)+' · ':''}${t.n} season${t.n>1?'s':''}</span></div>`).join('<div class="parr">→</div>')}</div>
   ${mv.length?`<div class="moves">${mv.map(x=>`<div class="mv1"><b>${x.season}</b> · ${esc(x.type)}${x.type==='Sacked'?` by ${esc(x.from)}`:x.type==='Retired'?'':`: ${x.from!=='—'?esc(x.from)+' → ':''}<b>${esc(x.to)}</b>`}<div class="sub">${esc(x.reason||'')} (age ${x.age})</div></div>`).join('')}</div>`:''}
   <h3>Season by season</h3><div class="tw"><table><thead><tr><th>Season</th><th>Age</th><th class="l">Club</th><th>Expected → finish</th><th>P</th><th>W</th><th>D</th><th>L</th><th>Win %</th><th>PPG</th><th>GF</th><th>GA</th><th>CS</th><th class="l">Cups</th><th class="l">Continental</th><th class="l">Honours & notes</th></tr></thead><tbody>${seasonRows}</tbody></table></div>
   <h3>Detailed manager stats (league)</h3><div class="tw">${cols.length?det:'<p class="sub">No seasons in work.</p>'}</div>
   <h3>Record by club</h3><div class="tw"><table><thead><tr><th>Club</th><th>Seasons</th><th>P</th><th>W</th><th>D</th><th>L</th><th>Win %</th><th>PPG</th><th>Best finish</th><th>Trophies</th></tr></thead><tbody>${Object.entries(byClub).map(([c,b])=>`<tr><td>${esc(c)}</td><td>${b.n}</td><td>${b.P}</td><td>${b.W}</td><td>${b.D}</td><td>${b.L}</td><td>${Math.round(b.W/Math.max(1,b.P)*100)}%</td><td>${(b.Pts/Math.max(1,b.P)).toFixed(2)}</td><td>${ord(b.best)}</td><td>${b.tr}</td></tr>`).join('')}</tbody></table></div>
   <h3>Trophy cabinet</h3><div>${Object.keys(cab).length?Object.entries(cab).map(([k,v])=>`<span class="tag gold">🏆 ${esc(k)} ×${v}</span>`).join(''):'<span class="sub">No trophies in this run.</span>'}${motm?`<span class="tag gold">Manager of the Season ×${motm}</span>`:''}${woty?`<span class="tag gold">World Coach of the Year ×${woty}</span>`:''}</div>`;
}
