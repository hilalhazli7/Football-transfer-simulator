// Football Transfer Simulator — simulation engine
// Pure JavaScript: random numbers + football rules. No AI, no network, no server.
// ---------- ENGINE ----------
const DATA_YEAR=2026;
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function gauss(r){let u=0;while(!u)u=r();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*r())}
function poisson(r,l){if(l<=0)return 0;if(l>30)return Math.max(0,Math.round(l+Math.sqrt(l)*gauss(r)));const L=Math.exp(-l);let k=0,p=1;do{k++;p*=r()}while(p>L);return k-1}
const sig=x=>1/(1+Math.exp(-x));
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const seasonLabel=y=>y+'/'+String((y+1)%100).padStart(2,'0');

LEAGUES.forEach(l=>{l.clubs=l.c.split(',').map(s=>{const i=s.lastIndexOf(':');return{name:s.slice(0,i),r:+s.slice(i+1)}})});
const LEAGUE_BY_ID=Object.fromEntries(LEAGUES.map(l=>[l.id,l]));
const CLUB_LEAGUE={};LEAGUES.forEach(l=>l.clubs.forEach(c=>CLUB_LEAGUE[c.name]=l.id));

const PLAYERS=[];
P_RAW.trim().split('\n').forEach((ln,i)=>{const[n,nat,pos,b,club,o,p]=ln.split('|');PLAYERS.push({id:'p'+i,name:n,nat,pos,birth:+b,club,league:CLUB_LEAGUE[club]||'',ovr:+o,pot:+p,legend:false})});
L_RAW.trim().split('\n').forEach((ln,i)=>{const[n,nat,pos,a,era,o]=ln.split('|');PLAYERS.push({id:'l'+i,name:n,nat,pos,primeAge:+a,club:era,league:'',ovr:+o,pot:+o,legend:true})});

const HIST={};for(const k in HIST_RAW)HIST[k]=HIST_RAW[k].map(([a,b,s])=>[a,b,s.split(',').map(x=>{const i=x.lastIndexOf(':');return{name:x.slice(0,i),r:+x.slice(i+1)}})]);
// clubs of a league in a given season (historical line-ups where we have them; clubs that didn't exist yet are removed)
function leagueClubsFor(lid,y){const L=LEAGUE_BY_ID[lid];if(LEAGUE_FROM[lid]&&y<LEAGUE_FROM[lid])return[];
  const h=(HIST[lid]||[]).find(h=>y>=h[0]&&y<=h[1]);
  return (h?h[2]:L.clubs).filter(c=>(!FOUNDED[c.name]||FOUNDED[c.name]<=y)&&!(DISSOLVED[c.name]&&y>DISSOLVED[c.name])).map(c=>({name:c.name,r:eraRating(c.name,c.r,y)}))}
function leagueNameFor(L,y){if(L.id==='MSL'){if(y<1994)return 'Liga Semi-Pro Divisyen 1';if(y<2004)return 'Liga Perdana'}
  if(L.id==='SAU'&&y<2008)return 'Saudi Premier League';
  if(L.id==='J1')return y<1999?'J.League':y<2015?'J.League Division 1':L.name;
  if(L.id==='KL1')return y<2013?'K League':y<2018?'K League Classic':L.name;
  if(L.id==='CSL'&&y<2004)return 'Chinese Jia-A League';if(L.id==='EPL'&&y<1992)return 'First Division';return L.name}
// competitions that existed that season (null = did not exist)
function compNameFor(n,y){
  if(n==='Champions League')return y<1992?'European Cup':n;
  if(n==='Europa League')return y<2009?'UEFA Cup':n;
  if(n==='Conference League')return y<2021?null:n;
  if(n==='AFC Champions League Elite')return y<2002?'Asian Club Championship':y<2024?'AFC Champions League':n;
  if(n==='AFC Champions League Two')return y<2004?null:y<2024?'AFC Cup':n;
  if(n==='CONCACAF Champions Cup')return y<2008?'CONCACAF Champions\' Cup':y<2024?'CONCACAF Champions League':n;
  return n}
const MANAGERS=[];
M_RAW.trim().split('\n').forEach((ln,i)=>{const[n,nat,st,b,k,o,yd]=ln.split('|');MANAGERS.push({id:'m'+i,name:n,nat,style:st,birth:+b,club:k,ovr:+o,youth:+yd,legend:false})});
ML_RAW.trim().split('\n').forEach((ln,i)=>{const[n,nat,st,a,k,o,yd]=ln.split('|');MANAGERS.push({id:'ml'+i,name:n,nat,style:st,primeAge:+a,club:k,ovr:+o,youth:+yd,legend:true})});
function managerAt(m,y){return m.legend?m.primeAge:clamp(y-m.birth,32,72)}
function eraRating(club,base,y){for(const e of ERA){if(e[0]===club&&y>=e[1]&&y<=e[2])return e[3]}return base}

const POS_NAME={GK:'Goalkeeper',CB:'Centre-back',FB:'Full-back',DM:'Defensive mid',CM:'Central mid',AM:'Attacking mid',W:'Winger',ST:'Striker'};
const W_IMP={ST:.2,W:.17,AM:.18,CM:.16,DM:.14,CB:.14,FB:.1,GK:.18};
const SH_G={ST:.3,W:.2,AM:.14,CM:.07,DM:.035,FB:.03,CB:.035,GK:0};
const SH_A={ST:.09,W:.14,AM:.17,CM:.1,DM:.055,FB:.07,CB:.02,GK:.004};
const MAXSH={ST:.42,W:.36,AM:.3,CM:.18,DM:.08,FB:.08,CB:.07,GK:.01};
const INT_G={ST:.42,W:.28,AM:.24,CM:.1,DM:.05,FB:.04,CB:.05,GK:0};

function growthDelta(age,ovr,pot){
  if(age<=21)return clamp((pot-ovr)*.28,0,5);
  if(age<=24)return clamp((pot-ovr)*.3,0,3.5);
  if(age<=27)return clamp((pot-ovr)*.35,0,2);
  if(age<=29)return 0;
  if(age<=31)return -.9;
  if(age<=33)return -1.9;
  return -3;
}
// expected rating of a current player at a given season
// Every transfer resets the player to age 23, at the level he had (or will have) at 23.
const RESET_AGE=23;
// Known real levels at age 23 for veterans/legends whose path was not a simple curve
const AT23={'Cristiano Ronaldo':91,'Lionel Messi':94,'Luka Modrić':79,'Robert Lewandowski':82,'Karim Benzema':84,'Kevin De Bruyne':82,'Mohamed Salah':80,'Virgil van Dijk':77,'Thomas Müller':85,'Manuel Neuer':84,'Son Heung-min':80,'Antoine Griezmann':84,'Luis Suárez':82,'Alisson Becker':79,'Casemiro':79,'Marco Reus':84,'Olivier Giroud':72,'Kasper Schmeichel':72,'Yann Sommer':76,'Nicolás Otamendi':78,'Iago Aspas':75,'Pierre-Emerick Aubameyang':80,"N'Golo Kanté":75,'Riyad Mahrez':74,'Sadio Mané':79,'Dani Parejo':78,'Granit Xhaka':80,'Mario Götze':86,'Paul Pogba':86,'Raúl Jiménez':73,'Kalidou Koulibaly':77,'Marcelo Brozović':79,'Ivan Perišić':80,'Kevin De Bruyne (Prime)':82,'Robert Lewandowski (Prime)':82,'Luka Modrić (Prime)':79,'Karim Benzema (Prime)':84,'Luis Suárez (Prime)':82,'Sergio Ramos (Prime)':85,'Didier Drogba':74,'Zlatan Ibrahimović':85,'Fabio Cannavaro':86,'Claude Makélélé':80,'Franck Ribéry':80,'Cafu':84,'Xavi Hernández':85,'Lothar Matthäus':87,'Oliver Kahn':80,'Lev Yashin':85,'Gheorghe Hagi':86,'George Weah':84,'Carles Puyol':80,'Clarence Seedorf':86,'Park Ji-sung':79,'Cha Bum-kun':84,'Son Heung-min (Prime)':80,'Cristiano Ronaldo (Prime)':91,'Lionel Messi (Prime)':94};
function level23(p){
  if(p.legend&&AT23[p.name]!=null)return{age:RESET_AGE,ovr:AT23[p.name],pot:p.ovr};
  if(p.legend){const pa=p.primeAge;const ovr=pa<=RESET_AGE?p.ovr:p.ovr-1.3*Math.min(5,Math.min(pa,28)-RESET_AGE);return{age:RESET_AGE,ovr:clamp(ovr,40,99),pot:p.ovr}}
  const A=DATA_YEAR-p.birth;let ovr=p.ovr;
  if(A<=RESET_AGE){for(let a=A;a<RESET_AGE;a++)ovr+=growthDelta(a,ovr,p.pot);return{age:RESET_AGE,ovr:clamp(ovr,40,99),pot:Math.max(p.pot,ovr)}}
  if(AT23[p.name]!=null){const pr=PLAYERS.find(x=>x.name===p.name+' (Prime)');return{age:RESET_AGE,ovr:AT23[p.name],pot:pr?pr.ovr:Math.max(AT23[p.name],p.ovr,Math.min(99,p.ovr+Math.min(6,(A-29)*1.2)))}}
  for(let a=A-1;a>=28;a--)ovr-=growthDelta(a,ovr,p.pot); // undo age decline -> peak level
  ovr=Math.min(ovr,p.ovr+5);const peak=ovr;ovr-=1.3*Math.min(5,Math.min(A,28)-RESET_AGE);
  return{age:RESET_AGE,ovr:clamp(ovr,40,99),pot:clamp(Math.max(p.pot,peak),40,99)};
}
function projectPlayer(p,y){
  if(p.legend)return{age:p.primeAge,ovr:p.ovr,pot:p.ovr};
  const age=y-p.birth;let ovr=p.ovr;const steps=y-DATA_YEAR;
  if(steps>0){for(let a=p.birth? DATA_YEAR-p.birth:0,i=0;i<steps;i++,a++)ovr+=growthDelta(a,ovr,p.pot)}
  else if(steps<0){for(let a=DATA_YEAR-p.birth-1,i=0;i<-steps;i++,a--){let d=growthDelta(a,ovr,p.pot);if(d>0)d=Math.max(1.5,d*1.2);ovr-=d}}
  return{age,ovr:clamp(ovr,40,99),pot:Math.max(p.pot,ovr)};
}
// transfer-fee inflation: 1995 record ≈ €18m, 2009 ≈ €94m, 2017+ ≈ €200m+
const eraF=y=>y>=2017?1:Math.exp((y-2017)*.1);
function marketValue(ovr,age,coef){
  const base=Math.exp((ovr-60)/5.5)*.5;
  const af=age<=21?1.5:age<=25?1.3:age<=28?1:age<=30?.7:age<=32?.4:age<=34?.2:.08;
  return base*af*(.55+.45*coef);
}
function clubBudget(league,rating){
  const L=LEAGUE_BY_ID[league];let b=Math.exp((rating-55)/5.5)*.45;
  if(league==='SAU')b*=3;if(league==='MLS')b*=.8;if(league==='MSL')b*=1.4;return b;
}

// ---- tournaments ----
const T_YEARS={
WC:[1990,1994,1998,2002,2006,2010,2014,2018,2022,2026,2030,2034,2038,2042],
EURO:[1992,1996,2000,2004,2008,2012,2016,2021,2024,2028,2032,2036,2040],
COPA:[1991,1993,1995,1997,1999,2001,2004,2007,2011,2015,2016,2019,2021,2024,2028,2032,2036,2040],
AFCON:[1992,1994,1996,1998,2000,2002,2004,2006,2008,2010,2012,2013,2015,2017,2019,2022,2024,2026,2027,2028,2032,2036,2040],
ASIAN:[1992,1996,2000,2004,2007,2011,2015,2019,2024,2027,2031,2035,2039],
AFF:[1996,1998,2000,2002,2005,2007,2008,2010,2012,2014,2016,2018,2021,2023,2025,2026,2028,2030,2032,2034,2036,2038,2040],
GOLD:[1991,1993,1996,1998,2000,2002,2003,2005,2007,2009,2011,2013,2015,2017,2019,2021,2023,2025,2027,2029,2031,2033,2035,2037,2039]};
const HOSTS={'WC2026':['USA','CAN','MEX'],'WC2030':['ESP','POR','MAR','ARG','URU','PAR'],'WC2034':['KSA'],'EURO2028':['ENG','SCO','WAL','IRL'],'EURO2032':['ITA','TUR'],'ASIAN2027':['KSA']};
const S6=['Group stage','Round of 16','Quarter-final','Semi-final','Final','Champions'];
function tourDef(k,T,conf){
  if(k==='WC'){const big=T>=2026;const bars={UEFA:79,CONMEBOL:77,CAF:75,AFC:72,CONCACAF:71,OFC:63};
    return{name:'World Cup '+T,bar:(bars[conf]||75)-(big?3:0),labels:big?['Group stage','Round of 32','Round of 16','Quarter-final','Semi-final','Final','Champions']:S6,opps:big?[72,78,81,83,85,86]:[75,80,83,85,86],w:20}}
  if(k==='EURO')return{name:'EURO '+T,bar:73,labels:S6,opps:[72,78,81,83,85],w:10};
  if(k==='COPA')return{name:'Copa América '+T,bar:0,labels:['Group stage','Quarter-final','Semi-final','Final','Champions'],opps:[72,78,82,84],w:10};
  if(k==='AFCON')return{name:'AFCON '+T,bar:66,labels:S6,opps:[64,69,72,74,76],w:5};
  if(k==='ASIAN')return{name:'AFC Asian Cup '+T,bar:60,labels:S6,opps:[57,63,68,71,74],w:5};
  if(k==='AFF')return{name:'ASEAN Championship '+T,bar:0,labels:['Group stage','Semi-final','Final','Champions'],opps:[53,57,59],w:1.5};
  if(k==='GOLD')return{name:'Gold Cup '+T,bar:60,labels:['Group stage','Quarter-final','Semi-final','Final','Champions'],opps:[62,68,72,74],w:2};
}
function tournamentsFor(nat,conf,T){
  const ks=[];if(T_YEARS.WC.includes(T))ks.push('WC');
  const m={UEFA:'EURO',CONMEBOL:'COPA',CAF:'AFCON',AFC:'ASIAN',CONCACAF:'GOLD'}[conf];
  if(m&&T_YEARS[m].includes(T))ks.push(m);
  if(nat==='MAS'&&T_YEARS.AFF.includes(T))ks.push('AFF');
  return ks.map(k=>({k,...tourDef(k,T,conf)}));
}
function runStages(s,opps,r,k=3.5){let i=0;for(;i<opps.length;i++){if(r()>sig((s-opps[i])/k))break}return i}

// ---- continental club comps ----
const CONT={
UEFA:[{name:'Champions League',opps:[76,78,81,83,85,86],labels:['League phase','Play-off','Round of 16','Quarter-final','Semi-final','Final','Winner'],w:10},
      {name:'Europa League',opps:[70,72,75,77,79,80],labels:['League phase','Play-off','Round of 16','Quarter-final','Semi-final','Final','Winner'],w:3},
      {name:'Conference League',opps:[64,66,69,71,73,74],labels:['League phase','Play-off','Round of 16','Quarter-final','Semi-final','Final','Winner'],w:2}],
AFC:[{name:'AFC Champions League Elite',opps:[64,67,70,73,75],labels:['League stage','Round of 16','Quarter-final','Semi-final','Final','Winner'],w:4},
     {name:'AFC Champions League Two',opps:[56,60,63,65,67],labels:['Group stage','Round of 16','Quarter-final','Semi-final','Final','Winner'],w:2}],
CONCACAF:[{name:'CONCACAF Champions Cup',opps:[62,66,69,72,74],labels:['Round one','Round of 16','Quarter-final','Semi-final','Final','Winner'],w:2.5}]};
const CUP_LABELS=['Round of 64','Round of 32','Round of 16','Quarter-final','Semi-final','Final','Winner'];

function simLeague(str,r,atk,dfn){
  const n=str.length,legs=n<=13?(n<=12?3:2):2,A_=atk||[],D_=dfn||[];
  const t=str.map((s,i)=>({i,P:0,W:0,D:0,L:0,GF:0,GA:0,Pts:0,CS:0,HW:0,HD:0,HL:0,AW:0,AD:0,AL:0,FTS:0,bigW:null,bigL:null}));
  for(let leg=0;leg<legs;leg++)for(let a=0;a<n;a++)for(let b=a+1;b<n;b++){
    let h=a,w=b;if(leg===1||(leg===2&&(a+b)%2)){h=b;w=a}
    const gh=poisson(r,1.42*Math.exp((str[h]-str[w])/21+.08+(A_[h]||0)-(D_[w]||0))),ga=poisson(r,1.12*Math.exp((str[w]-str[h])/21+(A_[w]||0)-(D_[h]||0)));
    const H=t[h],A=t[w];H.P++;A.P++;H.GF+=gh;H.GA+=ga;A.GF+=ga;A.GA+=gh;if(ga===0)H.CS++;if(gh===0)A.CS++;if(gh===0)H.FTS++;if(ga===0)A.FTS++;
    if(gh>ga){H.W++;H.Pts+=3;A.L++;H.HW++;A.AL++}else if(gh<ga){A.W++;A.Pts+=3;H.L++;A.AW++;H.HL++}else{H.D++;A.D++;H.Pts++;A.Pts++;H.HD++;A.AD++}
    const mg=gh-ga;if(mg>0){if(!H.bigW||mg>H.bigW.m)H.bigW={m:mg,s:gh+'-'+ga,o:w,h:1};if(!A.bigL||mg>A.bigL.m)A.bigL={m:mg,s:ga+'-'+gh,o:h,h:0}}
    else if(mg<0){if(!A.bigW||-mg>A.bigW.m)A.bigW={m:-mg,s:ga+'-'+gh,o:h,h:0};if(!H.bigL||-mg>H.bigL.m)H.bigL={m:-mg,s:gh+'-'+ga,o:w,h:1}}
  }
  const sorted=[...t].sort((x,y)=>y.Pts-x.Pts||(y.GF-y.GA)-(x.GF-x.GA)||y.GF-x.GF);
  sorted.forEach((row,k)=>row.pos=k+1);
  return t;
}
function simCup(sClub,str,ci,r,rounds){
  // rounds: number of ties to win the cup
  let i=0;
  for(;i<rounds;i++){
    let o;const late=i>=rounds-3;
    if(!late&&r()<.4)o=Math.min(...str)-4;else{let j;do{j=Math.floor(r()*str.length)}while(j===ci);o=str[j];if(late)o=Math.max(o,str[Math.floor(r()*str.length)])}
    if(r()>sig((sClub-o)/4+.1))break;
  }
  return i; // i===rounds -> winner
}

// ---- start-age rule: every transferred player begins at 18 ----
const START_AGE=18;
const AT18={'Pelé':90,'Diego Maradona':83,'Ronaldo Nazário':88,'Lionel Messi (Prime)':80,'Lionel Messi':80,'Cristiano Ronaldo (Prime)':76,'Cristiano Ronaldo':76,
'Kylian Mbappé':83,'Johan Cruyff':82,'Eusébio':83,'George Best':86,'Wayne Rooney':82,'Jude Bellingham':81,'Pedri':80,'Jamal Musiala':80,'Florian Wirtz':80,
'Bukayo Saka':76,'Phil Foden':74,'Arda Güler':75,'Pau Cubarsí':82,'Erling Haaland':73,'Vinícius Júnior':76,'Thierry Henry':72,'Zinedine Zidane':70,
'Zlatan Ibrahimović':71,'Robert Lewandowski':66,'Robert Lewandowski (Prime)':66,'Didier Drogba':58,'Luka Modrić':66,'Luka Modrić (Prime)':66,'Harry Kane':62,
'Kevin De Bruyne':70,'Kevin De Bruyne (Prime)':70,'Mohamed Salah':68,'Neymar (Prime)':80,'Ronaldinho':76,'Kaká':74,'Iker Casillas':78,'Gianluigi Buffon':78,
'Paolo Maldini':80,'Franz Beckenbauer':78,'Michael Owen':84,'Raúl':80,'Cesc Fàbregas':78,'Gareth Bale':72,'Luis Suárez':70,'Luis Suárez (Prime)':70,
'Son Heung-min':70,'Son Heung-min (Prime)':70,'Virgil van Dijk':60,'Mokhtar Dahari':68,'Lamine Yamal':86,'Estêvão':79,'Endrick':76};
function level18(p){
  const l23=level23(p);
  if(AT18[p.name]!=null)return{age:START_AGE,ovr:AT18[p.name],pot:Math.max(l23.pot,AT18[p.name])};
  if(!p.legend){const A=DATA_YEAR-p.birth;
    if(A<=START_AGE){let o=p.ovr;for(let a=A;a<START_AGE;a++)o+=growthDelta(a,o,p.pot);return{age:START_AGE,ovr:clamp(o,40,99),pot:Math.max(p.pot,o)}}
    if(A<23){const o=p.ovr-3*(A-START_AGE);return{age:START_AGE,ovr:clamp(o,40,99),pot:l23.pot}}}
  const k=clamp((l23.ovr-60)*.25+6,5,13);
  return{age:START_AGE,ovr:clamp(l23.ovr-k,40,99),pot:Math.max(l23.pot,l23.ovr)};
}

// ---- league state & one club's season ----
function makeState(lid,y,override){const L=LEAGUE_BY_ID[lid];const clubs=(override||leagueClubsFor(lid,y)).map(c=>({name:c.name,orig:c.r,base:c.r}));
  const st={lid,L,y,clubs,idx:Object.fromEntries(clubs.map((c,i)=>[c.name,i])),prev:{},cupPrev:{}};
  clubs.forEach(c=>st.prev[c.name]=1+clubs.filter(d=>d.base>c.base).length);return st}
function clubSeason(st,ci,sim,r,y){
  const L=st.L,c=st.clubs[ci],me=sim.tab[ci],str=sim.str,n=st.clubs.length,trophies=[];
  const lname=leagueNameFor(L,y);const view={name:c.name,league:lname,pos:me.pos,P:me.P,W:me.W,D:me.D,L:me.L,GF:me.GF,GA:me.GA,Pts:me.Pts,CS:me.CS,cups:[],cont:null,leader:st.clubs[sim.tab.find(t=>t.pos===1).i].name,notes:''};
  if(me.pos===1)trophies.push(lname);
  let cupGames=0,cupWon=false;
  L.cups.forEach(cn=>{const rounds=cn==='EFL Cup'||cn==='League Cup'||cn==='Malaysia Cup'?5:6;const reached=simCup(str[ci],str,ci,r,rounds);
    view.cups.push({name:cn,res:reached>=rounds?'Winner':CUP_LABELS[CUP_LABELS.length-1-(rounds-reached)]});cupGames+=Math.min(reached+1,rounds);if(reached>=rounds){trophies.push(cn);cupWon=true}});
  const comps=CONT[L.conf]||[],sl=L.slots,pp=st.prev[c.name];let tier=-1;
  if(pp<=sl[0])tier=0;else if(pp<=sl[0]+sl[1])tier=1;else if(pp<=sl[0]+sl[1]+sl[2])tier=2;
  if(st.cupPrev[c.name]&&(tier<0||tier>1)&&comps.length>1)tier=1;if(tier>=comps.length)tier=-1;
  let contGames=0,contWon=false,contW=0;
  if(tier>=0&&!compNameFor(comps[tier].name,y))tier=-1;
  if(tier>=0){const cc=comps[tier];const cn=compNameFor(cc.name,y);const k=runStages(str[ci],cc.opps,r,4);view.cont={name:cn,res:cc.labels[Math.min(k,cc.labels.length-1)],tier};
    contGames=(k===0?6:7)+k*2-(k>=cc.opps.length?1:0);if(k>=cc.opps.length){contWon=true;contW=cc.w;trophies.push(cn)}}
  if(L.rel&&me.pos>n-L.rel)view.notes='Relegation zone';
  st.cupPrev[c.name]=cupWon;
  return{view,me,trophies,cupGames,contGames,cupWon,contWon,contW,str:str[ci]};
}

// ---- transfer market ----
function clubBaseNow(states,lid,name,y){const st=states[lid];if(st&&st.idx[name]!=null)return st.clubs[st.idx[name]].base;const c=leagueClubsFor(lid,y).find(x=>x.name===name);return c?c.r:60}
function transferWindow(ctx,r){
  const {p,cur,S,i,y,states,cfg}=ctx,age=p.age+i;
  if(cur.loanFrom){return{type:'Loan return',to:cur.loanFrom.club,league:cur.loanFrom.league,fee:0,reason:'Loan spell over',loanFrom:null}}
  const st=states[cur.league],cb=st.clubs[st.idx[cur.club]].base,gap=p.ovr-cb,tenure=i-cur.since+1,ms=S.ms||0;
  let reason=null,prob=0,mode='sale';
  if(S.pclub&&S.pclub.notes==='Relegation zone'&&!(cur.club===cfg.club&&false)){reason='Club relegated — relegation release clause';prob=.75;mode='minutes'}
  else if(ms<.35&&age<=21){reason='Needs first-team minutes';prob=.65;mode='loan'}
  else if(ms<.4&&age>=22){reason='Not playing enough';prob=.55;mode='minutes'}
  else if(gap>=4){reason='Outgrown the club';prob=clamp(.25+(gap-4)*.12+(S.rating>=7.4?.15:0),0,.92)*(tenure>=2?1:.75);mode='up'}
  else if(S.rating>=7.5&&r()<.3){reason='Star season — bigger clubs circle';prob=.45;mode='up'}
  else if(age>=29&&gap<-6){reason='Declining — club cashes in';prob=.5;mode='down'}
  else if(age>=30&&r()<.08){reason='Big-money move to Saudi Arabia';prob=1;mode='saudi'}
  if(!reason||r()>prob)return null;
  const srcCoef=st.L.coef;let fee=mode==='loan'?0:marketValue(p.ovr,age+1,srcCoef)*(.95+r()*.35);
  if(fee>170)fee=170+(fee-170)*.25;fee=Math.min(fee,260); // fees are negotiated: even generational talents sell for ~€150–250m
  const homeNat=NATIONS[p.nat]?NATIONS[p.nat][0]:'';
  let best=null,bestScore=-1e9;
  for(const L of LEAGUES){
    if(mode==='saudi'&&L.id!=='SAU')continue;
    for(const c of (states[L.id]?states[L.id].clubs:leagueClubsFor(L.id,y+1))){
      if(c.name===cur.club)continue;
      const base=clubBaseNow(states,L.id,c.name,y+1);
      let ok;
      if(mode==='loan'||mode==='minutes')ok=base>=p.ovr-6&&base<=p.ovr+(reason.startsWith('Club relegated')?3:1);
      else if(mode==='down')ok=base>=p.ovr-6&&base<cb-1;
      else if(mode==='saudi')ok=base<=p.ovr+2;
      else ok=base>=cb+2&&base<=p.ovr+2+(age<=22?(p.pot-p.ovr)*.3:0);
      if(!ok)continue;
      if(mode!=='loan'&&clubBudget(L.id,base)*(mode==='up'?1.6:1)<fee*.7)continue; // can they afford him? (big clubs stretch for a star)
      const needP=mode==='up'?clamp(.35+(p.ovr-base)*.06,.35,.9):.35; // a player far better than their squad is wanted by everyone
      if(r()>needP)continue;
      if(srcCoef<.6&&L.conf==='UEFA'&&r()>.35)continue;                  // scouting reach / work permits from weaker leagues
      if(L.coef<srcCoef-.2&&age<28&&mode!=='loan'&&mode!=='minutes'&&r()>.2)continue; // young players rarely step down a level
      if(mode==='loan'&&L.coef<.6&&L.id!==cur.league)continue;
      const score=base+6*L.coef+(L.id===cur.league?1.5:0)+(L.country===homeNat?2:0)+gauss(r)*1.5;
      if(score>bestScore){bestScore=score;best={club:c.name,league:L.id,base}}
    }
  }
  if(!best)return{none:true,reason};
  return{type:mode==='loan'?'Loan':'Transfer',to:best.club,league:best.league,fee,reason,loanFrom:mode==='loan'?{club:cur.club,league:cur.league}:null};
}

// ---- managers ----
const MSTYLE={Possession:[.04,.05],Gegenpress:[.06,.02],Counter:[0,.06],Defensive:[-.09,.12],Attacking:[.08,-.05],Balanced:[.03,.03]};
const MSTYLE_TXT={Possession:'keeps the ball, controls games',Gegenpress:'high press, wins the ball back fast',Counter:'compact, deadly on the break',Defensive:'hard to beat, few goals either way',Attacking:'all-out attack, scores and concedes more',Balanced:'pragmatic, adapts to the opponent'};
const mgrBonus=(m,cb)=>clamp((m.ovr-(cb+2))*.15,-2.5,3.5);
function managerWindow(ctx,r){
  const {mg,mcur,S,i,y,states}=ctx,age=mg.age+i;
  if(age>=66&&r()<(age-65)*.22)return{type:'Retired'};
  if(mcur.status==='unemployed'){
    let best=null,bs=-1e9;
    for(const L of LEAGUES)for(const c of (states[L.id]?states[L.id].clubs:leagueClubsFor(L.id,y+1))){
      const base=clubBaseNow(states,L.id,c.name,y+1);if(base>mg.ovr-1||base<mg.ovr-16)continue;if(r()>.1)continue;
      const sc=base+4*L.coef+(L.country===(NATIONS[mg.nat]||[''])[0]?2:0)+gauss(r)*1.5;if(sc>bs){bs=sc;best={club:c.name,league:L.id}}}
    return best?{type:'Hired',to:best.club,league:best.league,reason:'Back in work'}:null;
  }
  const m=S.mgr,perf=m.exp-m.pos,tenure=i-mcur.since+1,trophy=m.trophies.length>0;
  let sackP=0;
  if(m.relegated)sackP=.8;else if(perf<=-4)sackP=.4+(-perf-4)*.1;else if(m.exp<=3&&m.pos>m.exp+2&&!trophy)sackP=.3;else if(perf<=-2&&!trophy)sackP=.12;
  if(tenure===1)sackP*=.6;if(mg.ovr>=90)sackP*=.5;
  if(r()<sackP)return{type:'Sacked',reason:m.relegated?'Relegation':perf<0?`Finished ${-perf} places below expectations`:'Missed the club’s targets'};
  const cb=m.base;
  if(perf>=3||trophy||mg.ovr>=cb+6){
    let prob=.15+(perf>=3?.15:0)+(trophy?.15:0)+(mg.ovr>=cb+6?.1:0);if(tenure<2)prob*=.6;
    if(r()<prob){let best=null,bs=-1e9;
      for(const L of LEAGUES)for(const c of (states[L.id]?states[L.id].clubs:leagueClubsFor(L.id,y+1))){
        if(c.name===mcur.club)continue;const base=clubBaseNow(states,L.id,c.name,y+1);
        if(base<cb+2||base>Math.min(mg.ovr+3,cb+9))continue;if(r()>.2)continue; // careers climb in steps
        if(LEAGUE_BY_ID[mcur.league].coef<.6&&L.conf==='UEFA'&&r()>.35)continue; // Europe's clubs rarely hire straight from weaker leagues
        const sc=base+5*L.coef+(L.country===(NATIONS[mg.nat]||[''])[0]?2:0)+gauss(r)*4;if(sc>bs){bs=sc;best={club:c.name,league:L.id}}}
      if(best)return{type:'Left',to:best.club,league:best.league,reason:trophy?'Trophy-winning season':'Overachieved — a bigger club calls'}}
  }
  return null;
}

// ---- one career simulation ----
function simulate(cfg,seed,withAll=true){
  const r=mulberry32(seed);const withPlayer=withAll&&!!cfg.p,withMgr=withAll&&!!cfg.m;
  const states={};const getSt=(lid,yy)=>states[lid]||(states[lid]=makeState(lid,yy||cfg.start,lid===cfg.league?cfg.leagueOverride:null));
  const home=getSt(cfg.league),hci=home.idx[cfg.club];
  const p=cfg.p?{ovr:cfg.p.ovr,pot:cfg.p.pot,age:cfg.p.age,pos:cfg.p.pos,nat:cfg.p.nat,legend:cfg.p.legend}:{ovr:50,pot:50,age:cfg.m?cfg.m.age:40,pos:'CM',nat:'ENG'};
  const mg=withMgr?{ovr:cfg.m.ovr,style:cfg.m.style,youth:cfg.m.youth,age:cfg.m.age,nat:cfg.m.nat}:null;
  let mcur=withMgr?{league:cfg.mLeague||cfg.league,club:cfg.mClub||cfg.club,since:0,status:'employed'}:null;const mmoves=[];
  const nat=NATIONS[p.nat]||['Unknown',65,'UEFA'];
  let cur={league:cfg.league,club:cfg.club,since:0,loanFrom:null};
  let active=true,endReason='',intlRetired=false;
  const seasons=[],moves=[];
  for(let i=0;i<cfg.years;i++){
    const y=cfg.start+i,age=p.age+i;
    const S={y,label:seasonLabel(y),age,awards:[],trophies:[],clubTrophies:[],notes:[]};
    if(withPlayer&&active&&i>0&&age>=34&&r()<(age-33)*.25){active=false;endReason=`Retired at age ${age}`;S.notes.push(endReason)}
    const playing=withPlayer&&active;
    const pSt=getSt(cur.league),pci=pSt.idx[cur.club],cb=pSt.clubs[pci].base;
    const mEmp=withMgr&&mcur.status==='employed',mSt=mEmp?getSt(mcur.league,y):null,mci=mEmp?mSt.idx[mcur.club]:-1,mcb=mEmp?mSt.clubs[mci].base:0;
    const mExp=mEmp?1+mSt.clubs.filter((c,j)=>j!==mci&&c.base>mcb).length:0,mB=mEmp?mgrBonus(mg,mcb):0;
    const sameClub=mEmp&&withPlayer&&active&&mcur.club===cur.club;
    let ms=0,role='—',inj=0;
    if(playing){
      const d=p.ovr-cb+(cur.club===cfg.club&&i===0?(cfg.roleBias||0):0)+(sameClub&&age<=21&&mg.youth>.6?2:0);
      if(p.pos==='GK'){if(d>=-2){ms=.88+r()*.1;role='First choice'}else if(d>=-6){ms=.3+r()*.3;role='Rotation'}else{ms=.03+r()*.1;role='Backup'}}
      else{if(d>=-3){ms=.74+r()*.2;role='Starter'}else if(d>=-8){ms=.38+r()*.27;role='Rotation'}else{ms=.08+r()*.2;role='Bench'}}
      if(age<=19&&d<2)ms*=.85;
      if(r()<.12+Math.max(0,age-30)*.03){inj=Math.round(3+r()*20);ms*=Math.max(.35,1-inj/42)}
    }
    const rawImp=playing?Math.max(0,p.ovr-cb)*W_IMP[p.pos]*ms:0,impact=4*(1-Math.exp(-rawImp/4));
    const sims={};
    const lids=new Set([cfg.league,cur.league]);if(mEmp)lids.add(mcur.league);
    for(const lid of lids){const st=getSt(lid);const atk=[],dfn=[];
      const str=st.clubs.map((c,j)=>{let v=c.base+gauss(r)*1.4+(playing&&lid===cur.league&&j===pci?impact:0);
        if(mEmp&&lid===mcur.league&&j===mci){v+=mB;const sm=MSTYLE[mg.style]||[0,0];atk[j]=sm[0];dfn[j]=sm[1]}return v});
      sims[lid]={str,tab:simLeague(str,r,atk,dfn)}}
    const hRes=clubSeason(home,hci,sims[cfg.league],r,y);
    const pRes=(cur.club===cfg.club)?hRes:clubSeason(pSt,pci,sims[cur.league],r,y);
    const mRes=!mEmp?null:mcur.club===cfg.club?hRes:mcur.club===cur.club?pRes:clubSeason(mSt,mci,sims[mcur.league],r,y);
    for(const lid in sims){const st=states[lid];sims[lid].tab.forEach(t=>st.prev[st.clubs[t.i].name]=t.pos)}
    S.club=hRes.view;S.club.impact=cur.club===cfg.club?impact:0;S.clubTrophies=hRes.trophies.slice();
    if(withMgr){const age_m=mg.age+i;
      if(!mEmp)S.mgr={status:mcur.status==='retired'?'Retired':'Out of work',age:age_m,ovr:mg.ovr,trophies:[],awards:[],notes:[]};
      else{const me=mRes.me,v=mRes.view,n=mSt.clubs.length;
        S.mgr={status:'Employed',age:age_m,ovr:mg.ovr,club:mcur.club,league:v.league,leagueId:mcur.league,base:mcb,bonus:mB,exp:mExp,pos:me.pos,n,
          P:me.P,W:me.W,D:me.D,L:me.L,GF:me.GF,GA:me.GA,Pts:me.Pts,CS:me.CS,HW:me.HW,HD:me.HD,HL:me.HL,AW:me.AW,AD:me.AD,AL:me.AL,FTS:me.FTS,
          bigW:me.bigW?{s:me.bigW.s,opp:mSt.clubs[me.bigW.o].name,h:me.bigW.h}:null,bigL:me.bigL?{s:me.bigL.s,opp:mSt.clubs[me.bigL.o].name,h:me.bigL.h}:null,
          cups:v.cups,cont:v.cont,trophies:mRes.trophies.slice(),awards:[],notes:[],relegated:!!v.notes,withPlayer:sameClub};
        const perf=mExp-me.pos;
        if((me.pos===1&&perf>=0)||perf>=6)S.mgr.awards.push('Manager of the Season');
        if(me.pos===1&&mRes.contWon&&mSt.L.conf==='UEFA'&&v.cont&&v.cont.tier===0)S.mgr.awards.push('World Coach of the Year');
        if(v.notes)S.mgr.notes.push('Relegation zone')}}
    S.atHome=cur.club===cfg.club;S.pclub={...pRes.view,leagueId:cur.league,loan:!!cur.loanFrom};
    if(playing){
      const L=pSt.L,me=pRes.me;
      S.trophies.push(...pRes.trophies);
      const q=clamp(Math.exp((p.ovr-cb)/14),.55,2.2);
      const lgAvg=pSt.clubs.reduce((s,c)=>s+c.base,0)/pSt.clubs.length;
      const team=clamp(.9+(cb-lgAvg)*.025,.7,1.05); // weak sides create fewer chances & the star gets double-marked
      const lApps=Math.max(0,Math.round(me.P*ms));
      const cApps=Math.round(pRes.cupGames*Math.min(1,ms*.9)),eApps=Math.round(pRes.contGames*Math.min(1,ms*1.02));
      const expG=me.GF*Math.min(SH_G[p.pos]*q,MAXSH[p.pos]*team)*ms,expA=me.GF*.72*Math.min(SH_A[p.pos]*q,MAXSH[p.pos]*.8*team)*ms*clamp(team+.1,.7,1.1);
      const soft=x=>x>28?28+(x-28)*.45:x; // even the greats rarely pass ~35-40 league goals
      const lg=poisson(r,soft(expG)),la=poisson(r,expA),pg=lApps?expG/lApps:0,pa=lApps?expA/lApps:0;
      const goals=lg+poisson(r,pg*cApps*.95)+poisson(r,pg*eApps*.8),assists=la+poisson(r,pa*cApps*.95)+poisson(r,pa*eApps*.8);
      const apps=lApps+cApps+eApps,cs=['GK','CB','FB','DM'].includes(p.pos)?Math.round(me.CS*ms):null;
      let rating=6.35+(p.ovr-cb)*.03+Math.min(1.2,(apps?(goals+.6*assists)/apps:0)*1.1)+(cs!==null&&me.P?(me.CS/me.P)*.6:0)+(me.pos===1?.15:0)+gauss(r)*.08;
      rating=clamp(rating,5.9,8.9);
      Object.assign(S,{playing:true,role,ms,inj,ovr:p.ovr,apps,lApps,goals,lg,assists,cs,rating,value:marketValue(p.ovr,age,L.coef)*eraF(y)});
      const gbTarget=Math.max(8,Math.round((24+gauss(r)*4)*me.P/38));
      if(lg>gbTarget)S.awards.push('Golden Boot');else if(lg===gbTarget&&lg>0)S.awards.push('Joint Golden Boot');
      if(rating>=7.6||(rating>=7.4&&me.pos===1&&r()<.5))S.awards.push('Player of the Season');
      else if(rating>=7.25&&ms>.5)S.awards.push('Team of the Season');
      if(age<=21&&rating>=7.2&&ms>.5&&L.coef>=.75)S.awards.push('Young Player of the Year');
      if(inj)S.notes.push(`Injured ~${inj} weeks`);
      if(cfg.detail)S.det=detailedStats(seed*31+i*7+1,S,p.pos,p.ovr,me,clamp(50+(cb-lgAvg)*1.6,34,70),p.pos==='ST'||(p.pos!=='GK'&&p.ovr>=cb+3));
      S.bdoClub=(p.ovr-80)*2+Math.min(goals+.6*assists,80)*.3+(rating-7)*8+(me.pos===1?5:0)+pRes.contW+(pRes.cupWon?1.5:0);S.bdoIntl=0;
      // international
      const I={caps:0,goals:0,tourn:[],role:''};
      if(intlRetired)I.role='Retired from intl.';
      else if(age>=33&&r()<(age-32)*.18){intlRetired=true;I.role='Retires from intl. duty'}
      else{
        const d=p.ovr-nat[1];
        I.role=d>=-2?'Key player':d>=-7?'Squad player':'Not selected';
        if(age<17)I.role='Too young';
        const called=I.role==='Key player'||I.role==='Squad player';
        I.caps=I.role==='Key player'?7+Math.floor(r()*4):I.role==='Squad player'?2+Math.floor(r()*5):(r()<.2?1:0);
        if(I.caps&&inj)I.caps=Math.max(0,I.caps-Math.round(inj/8));
        const suspended=p.nat==='RUS'&&y+1>=2022;
        if(called&&!suspended){
          for(const t of tournamentsFor(p.nat,nat[2],y+1)){
            const host=(HOSTS[t.k+(y+1)]||[]).includes(p.nat);
            const eff=nat[1]+(I.role==='Key player'?Math.max(0,d)*.3+.5:0)+gauss(r)*1.2;
            if(!host&&t.bar&&r()>sig((eff-t.bar)/2.5)){t.res='Did not qualify';t.games=0;t.goals=0}
            else{const k=runStages(eff,t.opps,r);t.res=t.labels[Math.min(k,t.labels.length-1)];t.games=Math.min(3+k,3+t.opps.length-1);t.won=k>=t.opps.length;
              if(t.won)S.trophies.push(t.name);if(k===t.opps.length-1)t.final=true}
            I.tourn.push(t);if(t.games)I.caps+=I.role==='Key player'?t.games:Math.round(t.games*.5);
          }
        }else if(suspended&&called)I.note='Nation suspended from competitions';
        const rate=INT_G[p.pos]*clamp(Math.exp(d/10),.5,2)*(nat[1]<62?.8:1);
        I.goals=poisson(r,rate*I.caps);
        I.tourn.forEach(t=>{if(t.games)t.goals=Math.min(I.goals,poisson(r,rate*t.games*(I.role==='Key player'?1:.5)))});
        if(I.tourn.find(t=>t.won)&&I.role==='Key player'&&d>=3&&p.ovr>=75&&r()<.45){S.awards.push('Player of the Tournament');S.bdoIntl+=6}
        S.bdoIntl+=I.role==='Key player'?I.tourn.reduce((s,t)=>s+(t.won?t.w:t.final?4:0),0):0;
      }
      S.intl=I;
      S.bdoBase=S.bdoClub*Math.pow(L.coef,1.5)+S.bdoIntl;const bar=44+r()*12;
      const elig=S.apps>=25&&ms>=.55&&p.ovr>=82&&(S.goals+S.assists>=12||['GK','CB','FB','DM'].includes(p.pos));
      if(elig&&S.bdoBase>=bar){S.bdo=1;S.awards.unshift("Ballon d'Or")}
      else if(elig&&S.bdoBase>=bar-20){S.bdo=Math.min(30,2+Math.floor((bar-S.bdoBase)/.7))}else S.bdo=null;
      // development (playing time and level of the club matter)
      let g=growthDelta(age,p.ovr,p.pot);
      if(age<=26){if(cb>=p.ovr-1)g+=.5;if(ms<.3)g-=1;else if(ms>.7&&age<=21)g+=.4;if(L.coef<.7)g-=.8}
      if(sameClub&&age<=23)g+=mg.youth*.6;
      g+=gauss(r)*.8;
      p.ovr=g>0?Math.min(p.ovr+g,Math.max(p.pot+2,p.ovr)):Math.max(40,p.ovr+g);
    }else{Object.assign(S,{playing:false,role:withPlayer?'Retired':'—'})}
    // club evolution
    for(const lid in sims){const st=states[lid];st.clubs.forEach(c=>{c.base+=gauss(r)*.9+.25*(c.orig-c.base)})}
    const bump=(st,name,res,imp)=>{const c=st.clubs[st.idx[name]];c.base+=(res.view.pos===1?.3:res.view.pos<=4?.1:0)+(res.contWon?.3:0)+(imp>2?.2:0);if(res.view.notes)c.base-=1.5};
    bump(home,cfg.club,hRes,S.club.impact);if(cur.club!==cfg.club)bump(pSt,cur.club,pRes,impact);
    if(mEmp&&mcur.club!==cfg.club&&mcur.club!==cur.club)bump(mSt,mcur.club,mRes,0);
    // manager: development of his rating, then sacking / job offers / retirement
    let followed=false;
    if(withMgr&&mcur.status!=='retired'){
      const am=mg.age+i;mg.ovr=clamp(mg.ovr+(am<45?.3:am>62?-.5:0)+(S.mgr.trophies&&S.mgr.trophies.length?.4:0)+gauss(r)*.4,50,99);
      if(i<cfg.years-1){const prevClub=mcur.club,wasWith=sameClub;
        const mv=managerWindow({mg,mcur,S,i,y,states},r);
        if(mv){const rec={season:seasonLabel(y+1),type:mv.type,from:mcur.status==='employed'?prevClub:'—',to:mv.to||'',reason:mv.reason||'',age:mg.age+i+1};
          if(mv.type==='Sacked'){mcur.status='unemployed';mg.ovr-=.6;S.mgr.notes.push('Sacked: '+mv.reason)}
          else if(mv.type==='Retired'){mcur.status='retired';S.mgr.notes.push('Retires from management')}
          else{getSt(mv.league,y+1);mcur={league:mv.league,club:mv.to,since:i+1,status:'employed'};S.mgr.notes.push((mv.type==='Hired'?'Hired by ':'Leaves for ')+mv.to);
            // his star player may follow him
            if(wasWith&&playing&&!cur.loanFrom&&cfg.transfers!==false&&p.ovr>=clubBaseNow(states,mv.league,mv.to,y+1)-3&&r()<.3){
              const fee=Math.min(260,marketValue(p.ovr,age+1,pSt.L.coef))*eraF(y+1);
              const m={season:seasonLabel(y+1),age:age+1,from:cur.club,to:mv.to,toLeague:LEAGUE_BY_ID[mv.league].name,fee,type:'Transfer',reason:'Follows his manager',ovr:p.ovr};
              moves.push(m);S.move=m;cur={league:mv.league,club:mv.to,since:i+1,loanFrom:null};followed=true}}
          mmoves.push(rec);S.mmove=rec}}
    }
    // summer transfer window
    if(playing&&!followed&&cfg.transfers!==false&&i<cfg.years-1){
      const mv=transferWindow({p,cur,S,i,y,states,cfg},r);
      if(mv&&mv.none){if(/minutes|playing|relegated/i.test(mv.reason))S.notes.push(`${mv.reason} — no suitable offer`)}
      else if(mv){
        getSt(mv.league,y+1);
        const m={season:seasonLabel(y+1),age:age+1,from:cur.club,to:mv.to,toLeague:LEAGUE_BY_ID[mv.league].name,fee:mv.fee*eraF(y+1),type:mv.type,reason:mv.reason,ovr:p.ovr};
        moves.push(m);S.move=m;
        if(cur.club===cfg.club&&mv.type==='Transfer'&&mv.fee>30)home.clubs[hci].base+=.4; // fee reinvested
        cur={league:mv.league,club:mv.to,since:i+1,loanFrom:mv.loanFrom};
      }
    }
    seasons.push(S);
  }
  return{seasons,moves,mmoves,endReason};
}

// ---- Monte Carlo ----
function monteCarlo(cfg,n){
  const agg={w:{pos:0,titles:0,cont:0,top:0,trophies:0},o:{pos:0,titles:0,cont:0,top:0,trophies:0},goals:0,assists:0,seasonsP:0,bdo:0,intlMajor:0,moves:0,stay:0,mStay:0,mSacked:0,mTrophies:0,mWin:0,mGames:0,runs:n,yrs:cfg.years};
  const L=LEAGUE_BY_ID[cfg.league];const topN=Math.max(1,L.slots[0]);
  for(let k=0;k<n;k++){
    const seed=1000+k*7919;
    for(const [key,wp] of [['w',true],['o',false]]){
      const res=simulate(cfg,seed,wp);const A=agg[key];
      if(wp){agg.moves+=res.moves.filter(m=>m.type!=='Loan return').length;agg.stay+=res.seasons.filter(s=>s.playing&&s.atHome).length;
        if(cfg.m){const first=cfg.mClub||cfg.club;agg.mStay+=res.seasons.filter(s=>s.mgr&&s.mgr.club===first&&s.mgr.status==='Employed').length;agg.mSacked+=res.mmoves.filter(m=>m.type==='Sacked').length;
          res.seasons.forEach(s=>{if(s.mgr&&s.mgr.status==='Employed'){agg.mTrophies+=s.mgr.trophies.length;agg.mWin+=s.mgr.W;agg.mGames+=s.mgr.P}})}}
      res.seasons.forEach(s=>{A.pos+=s.club.pos;if(s.club.pos===1)A.titles++;if(s.club.pos<=topN)A.top++;if(s.club.cont&&s.club.cont.res==='Winner')A.cont++;
        A.trophies+=s.clubTrophies.length;
        if(wp&&s.playing){agg.goals+=s.goals;agg.assists+=s.assists;agg.seasonsP++;if(s.bdo===1)agg.bdo++;if(s.intl&&s.intl.tourn.some(t=>t.won&&t.w>=5))agg.intlMajor++}});
    }
  }
  return agg;
}

// ---- detailed per-season stats (consistent with goals, assists, minutes, rating and team style) ----
const R90={ // per-90 base rates by position
 pass:{GK:28,CB:55,FB:45,DM:62,CM:58,AM:45,W:30,ST:20}, pacc:{GK:74,CB:88,FB:80,DM:89,CM:87,AM:82,W:78,ST:71},
 prog:{GK:.5,CB:4,FB:4.5,DM:6,CM:6,AM:5,W:2.5,ST:1.2}, lng:{GK:6,CB:3,FB:1.5,DM:3,CM:2.5,AM:1,W:.5,ST:.3},
 crs:{GK:0,CB:.05,FB:1.2,DM:.2,CM:.3,AM:.5,W:1,ST:.2}, kp:{GK:0,CB:.25,FB:.7,DM:.6,CM:1,AM:1.7,W:1.3,ST:.8},
 drb:{GK:0,CB:.2,FB:.8,DM:.5,CM:.9,AM:1.8,W:2.3,ST:.9}, tkl:{GK:0,CB:1.8,FB:2.2,DM:2.6,CM:1.8,AM:.9,W:.8,ST:.4},
 int:{GK:.1,CB:1.4,FB:1.1,DM:1.5,CM:.9,AM:.4,W:.3,ST:.2}, clr:{GK:.6,CB:4.5,FB:1.8,DM:1.2,CM:.6,AM:.3,W:.3,ST:.4},
 blk:{GK:0,CB:.8,FB:.5,DM:.5,CM:.3,AM:.15,W:.1,ST:.1}, aer:{GK:.3,CB:4.8,FB:1.7,DM:2.4,CM:1.5,AM:.8,W:.8,ST:4.5},
 aerW:{GK:90,CB:62,FB:50,DM:52,CM:48,AM:40,W:38,ST:44}, rec:{GK:1,CB:5,FB:5,DM:6.5,CM:5.5,AM:4,W:3.5,ST:2.5},
 past:{GK:0,CB:.6,FB:1,DM:.9,CM:.9,AM:.6,W:.5,ST:.3}, box:{GK:0,CB:.6,FB:1.2,DM:.8,CM:1.5,AM:3.5,W:4.5,ST:5.5},
 off:{GK:0,CB:0,FB:.05,DM:0,CM:.05,AM:.15,W:.3,ST:.6}, foul:{GK:.05,CB:1,FB:.9,DM:1.4,CM:1.1,AM:.9,W:.8,ST:1.2},
 won:{GK:.1,CB:.6,FB:.9,DM:1.2,CM:1.3,AM:1.8,W:1.9,ST:1.6}, yc:{GK:.03,CB:.2,FB:.17,DM:.25,CM:.18,AM:.12,W:.1,ST:.1},
 km:{GK:5.5,CB:9.8,FB:10.5,DM:11,CM:11.3,AM:10.8,W:10.3,ST:9.8}, head:{GK:0,CB:.45,FB:.1,DM:.2,CM:.12,AM:.06,W:.08,ST:.2},
 out:{GK:0,CB:.05,FB:.15,DM:.3,CM:.25,AM:.2,W:.14,ST:.06}};
function detailedStats(seed,S,pos,ovr,me,poss,penTaker){
  const r=mulberry32(seed),P=(l)=>poisson(r,Math.max(0,l)),N=(m,s)=>m+gauss(r)*s;
  const q=clamp((ovr-62)/30,0,1.25),ms=S.ms,apps=S.apps;
  const minPer=ms>.7?84:ms>.4?66:38,minutes=Math.max(0,Math.round(apps*N(minPer,3))),n90=minutes/90;
  const starts=Math.min(apps,Math.round(apps*clamp(ms*1.08,.08,.98))),def=1+(50-poss)/55,att=.8+q*.45;
  const d={minutes,starts,subs:apps-starts,n90};
  d.motm=P(apps*clamp((S.rating-6.65)*.22,0,.55));
  // shooting
  const fin=1+(ovr-80)*.012,xg=S.goals/fin*N(1,.08);d.xg=Math.max(0,xg);
  const xgPerShot=pos==='ST'?.21:pos==='W'||pos==='AM'?.13:.09;
  d.shots=Math.max(S.goals,Math.round(d.xg/xgPerShot+P(n90*.2)));d.sot=Math.max(S.goals,Math.round(d.shots*clamp(N(.37+.12*q,.03),.2,.65)));
  d.bcm=P(d.xg*.33);d.penT=penTaker?P(n90*.13):0;d.penS=Math.min(d.penT,Math.round(d.penT*clamp(N(.78+.08*q,.05),.5,.97)),S.goals);
  const rest=S.goals-d.penS;d.head=Math.min(rest,P(rest*R90.head[pos]));d.outG=Math.min(rest-d.head,P(rest*R90.out[pos]*(.8+q*.4)));
  d.hat=S.goals>=12?P(Math.pow(S.goals/Math.max(apps,1),2)*apps*.05):0;
  // creativity & passing
  d.xa=Math.max(0,S.assists*N(.92,.12));d.kp=Math.max(S.assists,P(n90*R90.kp[pos]*att));d.bcc=Math.max(Math.round(S.assists*.6),P(S.assists*.9+d.kp*.06));
  d.passAtt=Math.round(n90*R90.pass[pos]*Math.pow(poss/50,.7)*N(1,.06));d.passCmp=Math.round(d.passAtt*clamp((R90.pacc[pos]+(q-.5)*6+(poss-50)*.1+gauss(r)*1.2)/100,.55,.94));
  d.prog=P(n90*R90.prog[pos]*(.7+.5*q));d.longAtt=P(n90*R90.lng[pos]*1.6);d.longCmp=Math.round(d.longAtt*clamp(N(.55+.12*q,.04),.3,.85));
  d.crsAtt=P(n90*R90.crs[pos]*4);d.crsCmp=Math.round(d.crsAtt*clamp(N(.24+.08*q,.03),.1,.45));
  d.drbAtt=P(n90*R90.drb[pos]*att*1.8);d.drbCmp=Math.round(d.drbAtt*clamp(N(.46+.15*q,.04),.25,.8));d.box=P(n90*R90.box[pos]*att*(poss/50));d.off=P(n90*R90.off[pos]);
  // defending
  d.tklAtt=P(n90*R90.tkl[pos]*def*1.4);d.tklWon=Math.round(d.tklAtt*clamp(N(.55+.15*q,.04),.35,.85));d.int=P(n90*R90.int[pos]*def*(.85+.3*q));
  d.clr=P(n90*R90.clr[pos]*def);d.blk=P(n90*R90.blk[pos]*def);d.aerAtt=P(n90*R90.aer[pos]);d.aerWon=Math.round(d.aerAtt*clamp(N((R90.aerW[pos]+8*q)/100,.04),.2,.95));
  const duels=d.tklAtt+d.aerAtt+d.drbAtt+P(n90*2.5);d.duelAtt=duels;d.duelWon=Math.min(duels,d.tklWon+d.aerWon+d.drbCmp+Math.round(P(n90*2.5)*(.45+.1*q)));
  d.rec=P(n90*R90.rec[pos]*(.9+.2*q));d.past=P(n90*R90.past[pos]*(1.25-.45*q));
  d.err=['GK','CB','FB','DM'].includes(pos)?P(n90*.035*(1.3-q)):0;d.og=['CB','FB','GK'].includes(pos)?P(n90*.012):0;
  // physical & discipline
  d.km=Math.round(minutes/90*N(R90.km[pos],.4));d.fouls=P(n90*R90.foul[pos]);d.fouled=P(n90*R90.won[pos]*att);d.yc=P(n90*R90.yc[pos]);d.rc=P(n90*.008);
  // goals conceded with him on the pitch
  const gaPg=me.P?me.GA/me.P:1.2;d.gaOn=Math.round(gaPg*minutes/90*N(1,.05));d.cs=S.cs!=null?S.cs:Math.round(me.CS*ms);
  if(pos==='GK'){const sv=clamp(N(.66+.12*q-(50-poss)*.001,.025),.55,.85);d.sotFaced=Math.round(d.gaOn/(1-sv));d.saves=d.sotFaced-d.gaOn;
    d.penFaced=P(n90*.15);d.penSaved=Math.min(d.penFaced,P(d.penFaced*(.15+.1*q)));d.claims=P(n90*1.2);d.sweep=P(n90*(.5+.6*q));d.xgPrev=(sv-.70)*d.sotFaced*.9+gauss(r)*1.2}
  return d;
}

if(typeof module!=='undefined')module.exports={MANAGERS,managerAt,level18,level23,simulate,monteCarlo,PLAYERS,LEAGUES,projectPlayer,marketValue,clubBudget,LEAGUE_BY_ID};
